// ==========================================
// SCENES — Loading / Editor / Simulation / Menu
// ==========================================
// Semua scene pakai virtual coordinate CFG.APP.W × CFG.APP.H (800×600).
// Auto-scale via gameContainer dari engine.js.
//
// Scene list:
//   - LoadingScene        : boot, bake assets, spawn floaters
//   - LoadingOverlayScene : transisi async (load progress, etc.)
//   - MenuScene           : main menu (title, VS mode, Minits Manager, Settings)
//   - EditorScene         : pilih 2 minit untuk VS mode
//   - SimulationScene     : VS mode duel
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[scenes.js] namespace.js not loaded');
    if (!MD.CFG || !MD.PALETTE) throw new Error('[scenes.js] config.js must load before scenes.js');
    if (!MD.Arena) throw new Error('[scenes.js] arena.js must load before scenes.js');

    const { CFG, PALETTE, FastMath, AudioSys, Textures, MINIT_DB, UI_STYLE } = MD;

    // ══════════════════════════════════════════════════════════
    // LOADING SCENE
    // ══════════════════════════════════════════════════════════
    class LoadingScene extends PIXI.Container {
        constructor(cb) {
            super();
            const t = new PIXI.Text("BOOTING SYSTEM...", UI_STYLE.H2);
            t.anchor.set(0.5);
            t.position.set(CFG.APP.W / 2, CFG.APP.H / 2);
            this.addChild(t);

            Promise.race([
                document.fonts.ready,
                new Promise(res => setTimeout(res, 2000))
            ]).then(() => {
                MD.AssetBaker.bake();
                MD.globalBg.texture = Textures['bg_grid'];

                console.assert(MD.AssetBaker.ROCK_TEXTURES &&
                    MD.AssetBaker.ROCK_TEXTURES.length === PALETTE.ROCKS.length,
                    'Rock textures not baked');
                console.assert(Object.keys(MD.MINIT_DB).length > 0, 'MINIT_DB is empty');

                const keys = Object.keys(MD.MINIT_DB);
                for (let i = 0; i < 25; i++) {
                    const id = keys[(FastMath.rand() * keys.length) | 0];
                    const f = new PIXI.Sprite(Textures[`minit_${id}_base`]);
                    f.anchor.set(0.5);
                    f.scale.set(FastMath.randRange(1.5, 4));
                    f.x = FastMath.rand() * window.innerWidth;
                    f.y = FastMath.rand() * window.innerHeight;
                    f.vx = FastMath.randRange(-1, 1);
                    f.vy = FastMath.randRange(-1, 1);
                    f.alpha = FastMath.randRange(0.15, 0.55);
                    f.tint = 0x00aaff;
                    MD.bgContainer.addChild(f);
                    MD.bgFloaters.push(f);
                }

                MD.app.ticker.add((d) => {
                    for (const f of MD.bgFloaters) {
                        f.x += f.vx * d;
                        f.y += f.vy * d;
                        f.rotation += f.vx * 0.02 * d;
                        if (f.x < -100) f.x = window.innerWidth + 100;
                        else if (f.x > window.innerWidth + 100) f.x = -100;
                        if (f.y < -100) f.y = window.innerHeight + 100;
                        else if (f.y > window.innerHeight + 100) f.y = -100;
                    }
                });

                window.dispatchEvent(new Event('resize'));
                setTimeout(cb, 300);
            });
        }
    }

    // ══════════════════════════════════════════════════════════
    // LOADING OVERLAY SCENE
    // ══════════════════════════════════════════════════════════
    // Scene transisi sebelum masuk ke mode yang butuh async load.
    // Menampilkan loading indicator + run task, lalu ganti scene.
    // ══════════════════════════════════════════════════════════
    class LoadingOverlayScene extends PIXI.Container {
        constructor(label, taskFn, nextSceneFn) {
            super();
            this._taskFn = taskFn;
            this._nextSceneFn = nextSceneFn;
            this._dots = 0;
            this._time = 0;

            const bg = new PIXI.Graphics()
                .beginFill(0x020205)
                .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
            this.addChild(bg);

            this.title = new PIXI.Text(label || "LOADING...",
                UI_STYLE.MM_TITLE || UI_STYLE.H2);
            this.title.anchor.set(0.5);
            this.title.position.set(CFG.APP.W / 2, CFG.APP.H / 2 - 20);
            this.addChild(this.title);

            this.dotsText = new PIXI.Text("...",
                UI_STYLE.MM_INFO || UI_STYLE.STATS_LARGE);
            this.dotsText.anchor.set(0.5);
            this.dotsText.position.set(CFG.APP.W / 2, CFG.APP.H / 2 + 20);
            this.addChild(this.dotsText);

            // Start task
            this._run();
        }

        async _run() {
            try {
                if (this._taskFn) await this._taskFn();
            } catch (e) {
                console.error('[LoadingOverlay] Task failed:', e);
                this.title.text = "LOAD FAILED";
                this.dotsText.text = (e && e.message) || 'Unknown error';
                return;
            }
            const next = this._nextSceneFn ? this._nextSceneFn() : null;
            if (next) MD.setScene(next);
        }

        update(delta) {
            this._time += delta;
            if (this._time > 20) {
                this._time = 0;
                this._dots = (this._dots + 1) % 4;
                this.dotsText.text = '.'.repeat(this._dots);
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    // SETTINGS MODAL
    // ══════════════════════════════════════════════════════════
    class SettingsModal extends PIXI.Container {
        constructor(onClose) {
            super();
            this.onClose = onClose;
            this.interactive = true;

            // Backdrop: translucent, pakai virtual coords
            const backdrop = new PIXI.Graphics()
                .beginFill(0x000000, 0.75)
                .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
            backdrop.interactive = true;
            this.addChild(backdrop);

            const panelW = 420;
            const panelH = 340;
            const panelX = (CFG.APP.W - panelW) / 2;
            const panelY = (CFG.APP.H - panelH) / 2;

            const panel = new PIXI.Graphics()
                .beginFill(0x0a0a14)
                .lineStyle(2, PALETTE.NEON)
                .drawRect(panelX, panelY, panelW, panelH).endFill();
            this.addChild(panel);

            const title = new PIXI.Text("SETTINGS",
                { ...UI_STYLE.H2, fontSize: 16 });
            title.anchor.set(0.5, 0);
            title.position.set(CFG.APP.W / 2, panelY + 20);
            this.addChild(title);

            const settings = MD.Settings.load();
            this.settings = settings;

            let rowY = panelY + 70;
            const rowH = 48;
            const rowX = panelX + 30;
            const rowW = panelW - 60;

            this._buildToggleRow("SHADERS (CRT)", rowX, rowY, rowW,
                settings.shaders, (v) => {
                    settings.shaders = v;
                    MD.Settings.save(settings);
                    MD.Settings.apply(settings);
                });
            rowY += rowH;

            this._buildToggleRow("SFX", rowX, rowY, rowW,
                settings.sfx, (v) => {
                    settings.sfx = v;
                    MD.Settings.save(settings);
                    MD.Settings.apply(settings);
                });
            rowY += rowH;

            this._buildSliderRow("SFX VOL", rowX, rowY, rowW,
                settings.sfxVol, (v) => {
                    settings.sfxVol = v;
                    MD.Settings.save(settings);
                    MD.Settings.apply(settings);
                });
            rowY += rowH;

            this._buildSliderRow("MUSIC VOL", rowX, rowY, rowW,
                settings.musicVol, (v) => {
                    settings.musicVol = v;
                    MD.Settings.save(settings);
                    MD.Settings.apply(settings);
                });
            rowY += rowH;

            const closeBtn = this._buildBtn("CLOSE",
                CFG.APP.W / 2 - 60, panelY + panelH - 50, 120, 32,
                () => {
                    AudioSys.play('click');
                    if (this.onClose) this.onClose();
                    this.destroy({ children: true });
                });
            this.addChild(closeBtn);
        }

        _buildToggleRow(label, x, y, w, initial, onChange) {
            const row = new PIXI.Container();
            row.position.set(x, y);

            const lbl = new PIXI.Text(label, {
                ...UI_STYLE.STATS_LARGE, fontSize: 9, fill: PALETTE.TEXT
            });
            lbl.position.set(0, 12);
            row.addChild(lbl);

            let value = initial;
            const btn = new PIXI.Container();
            btn.position.set(w - 100, 0);
            btn.interactive = btn.buttonMode = true;
            btn.hitArea = new PIXI.Rectangle(0, 0, 100, 36);

            const bg = new PIXI.Graphics();
            const updateBg = () => {
                bg.clear()
                    .beginFill(value ? 0x1a3a1a : 0x3a1a1a)
                    .lineStyle(1, value ? 0x44ff88 : 0xff4444)
                    .drawRect(0, 0, 100, 36).endFill();
            };
            updateBg();
            btn.addChild(bg);

            const txt = new PIXI.Text(value ? "ON" : "OFF", {
                ...UI_STYLE.H2, fontSize: 10,
                fill: value ? '#44ff88' : '#ff4444'
            });
            txt.anchor.set(0.5);
            txt.position.set(50, 18);
            btn.addChild(txt);

            btn.on('pointerdown', () => {
                value = !value;
                updateBg();
                txt.text = value ? "ON" : "OFF";
                txt.style.fill = value ? '#44ff88' : '#ff4444';
                AudioSys.play('click');
                onChange(value);
            });

            row.addChild(btn);
            this.addChild(row);
        }

        _buildSliderRow(label, x, y, w, initial, onChange) {
            const row = new PIXI.Container();
            row.position.set(x, y);

            const lbl = new PIXI.Text(label, {
                ...UI_STYLE.STATS_LARGE, fontSize: 9, fill: PALETTE.TEXT
            });
            lbl.position.set(0, 4);
            row.addChild(lbl);

            const valText = new PIXI.Text(Math.round(initial * 100) + "%", {
                ...UI_STYLE.STATS_LARGE, fontSize: 8, fill: PALETTE.NEON
            });
            valText.anchor.set(1, 0);
            valText.position.set(w - 8, 4);
            row.addChild(valText);

            const sliderW = w - 60;
            const sliderH = 12;
            const sliderY = 22;

            let value = initial;

            const track = new PIXI.Graphics()
                .beginFill(0x1a1a2a)
                .drawRect(0, sliderY, sliderW, sliderH).endFill();
            row.addChild(track);

            const fill = new PIXI.Graphics();
            row.addChild(fill);

            const knob = new PIXI.Graphics()
                .beginFill(0xffcc00)
                .drawRect(-4, sliderY - 2, 8, sliderH + 4).endFill();
            row.addChild(knob);

            const updateVisual = () => {
                fill.clear()
                    .beginFill(PALETTE.NEON)
                    .drawRect(0, sliderY, sliderW * value, sliderH).endFill();
                knob.x = sliderW * value;
                valText.text = Math.round(value * 100) + "%";
            };
            updateVisual();

            const hitArea = new PIXI.Graphics()
                .beginFill(0x000000, 0.001)
                .drawRect(0, sliderY - 8, sliderW, sliderH + 16).endFill();
            hitArea.interactive = true;
            hitArea.buttonMode = true;
            hitArea.hitArea = new PIXI.Rectangle(0, sliderY - 8, sliderW, sliderH + 16);
            row.addChild(hitArea);

            let dragging = false;
            const handleMove = (globalX) => {
                const local = hitArea.toLocal({ x: globalX, y: 0 });
                value = Math.max(0, Math.min(1, local.x / sliderW));
                updateVisual();
                onChange(value);
            };
            hitArea.on('pointerdown', (e) => {
                dragging = true;
                handleMove(e.data.global.x);
            });
            hitArea.on('pointermove', (e) => {
                if (dragging) handleMove(e.data.global.x);
            });
            hitArea.on('pointerup', () => { dragging = false; });
            hitArea.on('pointerupoutside', () => { dragging = false; });

            this.addChild(row);
        }

        _buildBtn(text, x, y, w, h, onClick) {
            const btn = new PIXI.Container();
            btn.position.set(x, y);
            btn.interactive = btn.buttonMode = true;
            btn.hitArea = new PIXI.Rectangle(0, 0, w, h);

            const bg = new PIXI.Graphics()
                .beginFill(0x1a1a22)
                .lineStyle(1, PALETTE.NEON)
                .drawRect(0, 0, w, h).endFill();
            btn.addChild(bg);

            const t = new PIXI.Text(text, { ...UI_STYLE.H2, fontSize: 11 });
            t.anchor.set(0.5);
            t.position.set(w / 2, h / 2);
            btn.addChild(t);

            btn.on('pointerover', () => bg.tint = 0x555566);
            btn.on('pointerout', () => bg.tint = 0xffffff);
            btn.on('pointerdown', onClick);
            return btn;
        }
    }

    // ══════════════════════════════════════════════════════════
    // SETTINGS PERSIST + APPLY
    // ══════════════════════════════════════════════════════════
    MD.Settings = {
        DEFAULTS: {
            shaders: true,
            sfx: true,
            music: true,
            sfxVol: 0.8,
            musicVol: 0.6
        },
        _cache: null,

        load() {
            if (this._cache) return this._cache;
            try {
                const raw = localStorage.getItem('md_settings');
                this._cache = raw
                    ? { ...this.DEFAULTS, ...JSON.parse(raw) }
                    : { ...this.DEFAULTS };
            } catch (e) {
                this._cache = { ...this.DEFAULTS };
            }
            return this._cache;
        },

        save(settings) {
            this._cache = settings;
            try {
                localStorage.setItem('md_settings', JSON.stringify(settings));
            } catch (e) {
                console.warn('[Settings] Save failed:', e);
            }
        },

        apply(settings) {
            if (MD.app && MD.app.stage) {
                MD.app.stage.filters = settings.shaders && MD.crtFilter
                    ? [MD.crtFilter]
                    : [];
            }
            if (MD.AudioSys && MD.AudioSys.masterGain) {
                const v = settings.sfx
                    ? CFG.AUDIO.MASTER_GAIN * settings.sfxVol
                    : 0;
                MD.AudioSys.masterGain.gain.value = v;
            }
        }
    };

    // ══════════════════════════════════════════════════════════
    // MENU SCENE
    // ══════════════════════════════════════════════════════════
    // Composition FIXED (structure sama untuk semua orientasi).
    // Values per orientasi (dari CFG.LAYOUT.menu[orientation]).
    // Layout di-apply ulang saat resize/orientasi berubah.
    // Hitbox + bg di-update konsisten dengan visual.
    // ══════════════════════════════════════════════════════════
    class MenuScene extends PIXI.Container {
        constructor() {
            super();
            this.settingsModal = null;

            // Build structure ONCE
            this._buildComposition();
            // Apply layout values based on current orientation
            this._applyLayout();

            // Listen to resize (fires on orientation change)
            this._onResize = () => this._applyLayout();
            window.addEventListener('resize', this._onResize);

            // Optional: listener via Orientation (faster)
            if (MD.Orientation && MD.Orientation.onChange) {
                this._onOrientation = () => this._applyLayout();
                MD.Orientation.onChange(this._onOrientation);
            }
        }

        // ═══════════════════════════════════════════
        // COMPOSITION — build structure once
        // ═══════════════════════════════════════════
        _buildComposition() {
            // Title
            this.title = new PIXI.Text("MINING DUELS", {
                ...UI_STYLE.H1, fontSize: 32, fill: PALETTE.NEON
            });
            this.title.anchor.set(0.5, 0.5);
            this.addChild(this.title);

            // Subtitle
            this.subtitle = new PIXI.Text("COMPANY EDITION", {
                ...UI_STYLE.H3, fontSize: 12, fill: PALETTE.MUTED
            });
            this.subtitle.anchor.set(0.5, 0.5);
            this.addChild(this.subtitle);

            // Buttons
            this.buttons = [
                this._buildMainBtn("VS MODE", () => {
                    AudioSys.init();
                    AudioSys.play('start');
                    MD.setScene(new EditorScene(sel =>
                        MD.setScene(new SimulationScene(sel))
                    ));
                }),

                this._buildMainBtn("MINITS MANAGER", () => {
                    AudioSys.init();
                    AudioSys.play('start');
                    if (!MD.MinitsManagerScene) {
                        console.warn('[Menu] MinitsManagerScene not loaded');
                        return;
                    }
                    MD.setScene(new MD.LoadingOverlayScene(
                        "LOADING PROGRESS",
                        async () => {
                            await MD.MM.ProgressService.load();
                        },
                        () => new MD.MinitsManagerScene()
                    ));
                }),

                this._buildMainBtn("SETTINGS", () => {
                    AudioSys.play('click');
                    this._openSettings();
                })
            ];
            this.buttons.forEach(b => this.addChild(b));

            // Footer
            this.footer = new PIXI.Text("v0.1", {
                ...UI_STYLE.STATS_LARGE, fontSize: 7, fill: PALETTE.MUTED
            });
            this.footer.anchor.set(0.5, 0.5);
            this.addChild(this.footer);
        }

        // ═══════════════════════════════════════════
        // BUILD BUTTON — tanpa position/size hardcoded
        // ═══════════════════════════════════════════
        _buildMainBtn(text, onClick) {
            const btn = new PIXI.Container();
            btn.interactive = btn.buttonMode = true;

            const bg = new PIXI.Graphics();
            const label = new PIXI.Text(text, {
                ...UI_STYLE.H2, fontSize: 14
            });
            label.anchor.set(0.5, 0.5);

            btn.addChild(bg);
            btn.addChild(label);
            btn._bg = bg;
            btn._label = label;
            btn._onClick = onClick;

            btn.on('pointerover', () => bg.tint = 0x555566);
            btn.on('pointerout', () => bg.tint = 0xffffff);
            btn.on('pointerdown', () => btn._onClick());

            return btn;
        }

        // ═══════════════════════════════════════════
        // APPLY LAYOUT — update position + size dari config
        // FIX: hitArea + bg + label juga di-update
        // ═══════════════════════════════════════════
        _applyLayout() {
            const orientation = (MD.Orientation && MD.Orientation.current) || 'landscape';
            const menuLayouts = (CFG.LAYOUT && CFG.LAYOUT.menu) || {};
            const L = menuLayouts[orientation] || menuLayouts.landscape;
            if (!L) {
                console.warn('[MenuScene] No menu layout for orientation:', orientation);
                return;
            }

            // Title
            this.title.position.set(L.title.x, L.title.y);
            this.title.scale.set(L.title.scale || 1);

            // Subtitle
            this.subtitle.position.set(L.subtitle.x, L.subtitle.y);

            // Buttons
            this.buttons.forEach((btn, i) => {
                const bw = L.buttons.width;
                const bh = L.buttons.height;
                const bx = L.buttons.x;
                const by = L.buttons.startY + i * L.buttons.gap;

                // Position: top-left corner at (bx - bw/2, by)
                btn.position.set(bx - bw / 2, by);

                // FIX: update hitArea setiap layout berubah
                btn.hitArea = new PIXI.Rectangle(0, 0, bw, bh);

                // FIX: redraw bg match hitArea
                btn._bg.clear()
                    .beginFill(0x111118)
                    .lineStyle(2, PALETTE.NEON)
                    .drawRect(0, 0, bw, bh).endFill();

                // FIX: recenter label
                btn._label.position.set(bw / 2, bh / 2);
            });

            // Footer
            this.footer.position.set(L.footer.x, L.footer.y);
        }

        // ═══════════════════════════════════════════
        // SETTINGS
        // ═══════════════════════════════════════════
        _openSettings() {
            if (this.settingsModal) return;
            this.settingsModal = new SettingsModal(() => {
                this.settingsModal = null;
            });
            this.addChild(this.settingsModal);
        }

        // ═══════════════════════════════════════════
        // CLEANUP
        // ═══════════════════════════════════════════
        destroy(options) {
            window.removeEventListener('resize', this._onResize);
            super.destroy(options);
        }
    }

    // ══════════════════════════════════════════════════════════
    // EDITOR SCENE — Pilih 2 minit
    // ══════════════════════════════════════════════════════════
    class EditorScene extends PIXI.Container {
        constructor(cb) {
            super();
            this.sel = [];
            this.cb = cb;

            const title = new PIXI.Text("MINING DUELS", UI_STYLE.H1);
            title.anchor.set(0.5, 0);
            title.position.set(CFG.APP.W / 2, 40);
            this.addChild(title);

            const sub = new PIXI.Text("SELECT 2 MINITS", UI_STYLE.STATS_LARGE);
            sub.anchor.set(0.5, 0);
            sub.position.set(CFG.APP.W / 2, 75);
            this.addChild(sub);

            this.scrollMask = new PIXI.Graphics().beginFill(0xffffff)
                .drawRect(0, CFG.UI.SCROLL.Y, CFG.APP.W, CFG.UI.SCROLL.H).endFill();
            this.addChild(this.scrollMask);

            this.scrollCont = new PIXI.Container();
            this.scrollCont.mask = this.scrollMask;
            this.scrollCont.interactive = true;
            this.scrollCont.hitArea = new PIXI.Rectangle(0, CFG.UI.SCROLL.Y,
                CFG.APP.W, CFG.UI.SCROLL.H);
            this.addChild(this.scrollCont);

            const cW = CFG.UI.CARD.W * CFG.UI.CARD.SCALE;
            const cH = CFG.UI.CARD.H * CFG.UI.CARD.SCALE;
            const totalW = (cW * CFG.UI.CARD.COLS) +
                (CFG.UI.CARD.GAP_X * (CFG.UI.CARD.COLS - 1));
            const startX = (CFG.APP.W - totalW) / 2;

            const minitArr = Object.values(MINIT_DB);
            const maxRows = Math.ceil(minitArr.length / CFG.UI.CARD.COLS);
            this.maxScrollY = Math.min(0,
                CFG.UI.SCROLL.H - (maxRows * (cH + CFG.UI.CARD.GAP_Y)));

            minitArr.forEach((m, i) => {
                const col = i % CFG.UI.CARD.COLS;
                const row = Math.floor(i / CFG.UI.CARD.COLS);
                const c = this.card(0, 0, CFG.UI.CARD.W, CFG.UI.CARD.H, m);
                c.scale.set(CFG.UI.CARD.SCALE);
                c.position.set(
                    startX + col * (cW + CFG.UI.CARD.GAP_X),
                    CFG.UI.CARD.START_Y + row * (cH + CFG.UI.CARD.GAP_Y)
                );
                this.scrollCont.addChild(c);
            });

            let dragY = 0;
            let baseCamY = 0;
            this.scrollCont.on('pointerdown', (e) => {
                dragY = e.data.global.y;
                baseCamY = this.scrollCont.y;
            });
            this.scrollCont.on('pointermove', (e) => {
                if (dragY !== 0) {
                    this.scrollCont.y = baseCamY + (e.data.global.y - dragY);
                    this.scrollCont.y = Math.min(0,
                        Math.max(this.maxScrollY, this.scrollCont.y));
                }
            });
            const releaseDrag = () => { dragY = 0; };
            this.scrollCont.on('pointerup', releaseDrag);
            this.scrollCont.on('pointerupoutside', releaseDrag);

            const stTxt = new PIXI.Text("SELECTED:",
                { ...UI_STYLE.H2, fill: PALETTE.TEXT });
            stTxt.anchor.set(0.5, 0);
            stTxt.position.set(CFG.APP.W / 2, 480);
            this.addChild(stTxt);

            this.indCont = new PIXI.Container();
            this.indCont.position.set(CFG.APP.W / 2, 510);
            this.addChild(this.indCont);

            this.startBtn = this.createBtn("START", CFG.APP.W / 2, 560,
                () => this.cb(this.sel.slice(0, 2)));
            this.startBtn.visible = false;
            this.addChild(this.startBtn);
        }

        createBtn(txt, x, y, act) {
            const b = new PIXI.Container();
            b.position.set(x, y);
            b.interactive = b.buttonMode = true;

            const bg = new PIXI.Graphics()
                .beginFill(0x222222)
                .lineStyle(2, PALETTE.NEON)
                .drawRect(-75, -20, 150, 40).endFill();

            const t = new PIXI.Text(txt, { ...UI_STYLE.H2, fill: PALETTE.TEXT });
            t.anchor.set(0.5);
            b.addChild(bg, t);

            b.on('pointerover', () => bg.tint = 0x555555);
            b.on('pointerout', () => bg.tint = 0xffffff);
            b.on('pointerdown', () => {
                AudioSys.init();
                AudioSys.play('start');
                act();
            });
            return b;
        }

        card(x, y, w, h, d) {
            const c = new PIXI.Container();
            c.position.set(x, y);
            c.interactive = c.buttonMode = true;

            const bg = new PIXI.Graphics()
                .beginFill(PALETTE.CARD_BG)
                .lineStyle(1, PALETTE.BORDER)
                .drawRect(0, 0, w, h).endFill();

            const border = new PIXI.Graphics()
                .beginFill(d.color)
                .drawRect(0, 0, 4, h).endFill();
            c.addChild(bg, border);

            const ic = new PIXI.Sprite(Textures[`minit_${d.id}_base`]);
            ic.anchor.set(0.5);
            ic.scale.set(2.5);
            ic.position.set(30, 30);
            c.addChild(ic);

            const cor = new PIXI.Graphics().lineStyle(4, PALETTE.NEON);
            const s = 14;
            cor.moveTo(0, s).lineTo(0, 0).lineTo(s, 0);
            cor.moveTo(w - s, 0).lineTo(w, 0).lineTo(w, s);
            cor.moveTo(0, h - s).lineTo(0, h).lineTo(s, h);
            cor.moveTo(w - s, h).lineTo(w, h).lineTo(w, h - s);
            cor.visible = false;
            c.addChild(cor);

            const nm = new PIXI.Text(d.name, { ...UI_STYLE.H3, fill: d.color });
            nm.position.set(65, 10);
            c.addChild(nm);

            const stStr = d.getStatsStr
                ? d.getStatsStr(d.ability)
                : `DMG:${d.ability.dmg}`;
            const st = new PIXI.Text(`CD:${d.cd}f\n${stStr}`, UI_STYLE.STATS_LARGE);
            st.position.set(65, 28);
            c.addChild(st);

            const ds = new PIXI.Text(d.desc, UI_STYLE.DESC_LARGE);
            ds.position.set(12, 62);
            c.addChild(ds);

            c.on('pointerdown', (e) => {
                c.pointerDown = true;
                c.clickStartY = e.data.global.y;
            });
            c.on('pointerup', (e) => {
                if (c.pointerDown &&
                    Math.abs(e.data.global.y - c.clickStartY) < 5) {
                    AudioSys.init();
                    AudioSys.play('click');
                    if (c.isSelected) {
                        c.isSelected = false;
                        cor.visible = false;
                        this.sel = this.sel.filter(id => id !== d.id);
                    } else if (this.sel.length < 2) {
                        c.isSelected = true;
                        cor.visible = true;
                        this.sel.push(d.id);
                    }
                    this.indCont.removeChildren();
                    this.sel.forEach((id, idx) => {
                        const sp = new PIXI.Sprite(Textures[`minit_${id}_base`]);
                        sp.anchor.set(0.5);
                        sp.scale.set(2);
                        sp.x = (idx * 45) - ((this.sel.length - 1) * 22.5);
                        this.indCont.addChild(sp);
                    });
                    this.startBtn.visible = this.sel.length === 2;
                }
                c.pointerDown = false;
            });
            c.on('pointerupoutside', () => c.pointerDown = false);
            return c;
        }
    }

    // ══════════════════════════════════════════════════════════
    // SIMULATION SCENE — 2P duel
    // ══════════════════════════════════════════════════════════
    class SimulationScene extends PIXI.Container {
        constructor(tps) {
            super();
            if (!Array.isArray(tps) || tps.length !== 2) {
                console.warn(`[SimulationScene] Expected 2 minits, got ${tps.length}`);
                tps = tps.slice(0, 2);
            }
            this.tps = tps;
            this.finish = false;
            this.inOvertime = false;
            this.isSlowmo = false;
            this.tl = CFG.SIM.DUR;
            this.arenas = [];
            this.frameCounter = 0;

            const layout = MD.Orientation.getLayout(2);

            const tt = new PIXI.Text("MINING DUELS!", UI_STYLE.H1);
            tt.anchor.set(0.5, 0);
            tt.position.set(layout.title.x, layout.title.y);
            this.addChild(tt);

            this.tUI = new PIXI.Text("15", {
                ...UI_STYLE.H1,
                fontSize: layout.timer.size,
                fill: PALETTE.ALERT
            });
            this.tUI.anchor.set(0.5, 0);
            this.tUI.position.set(layout.timer.x, layout.timer.y);
            this.addChild(this.tUI);

            tps.forEach((id, idx) => {
                const slot = layout.slots[idx];
                const slotGroup = new PIXI.Container();
                slotGroup.pivot.set(120, 220);
                slotGroup.position.set(slot.x, slot.y);
                slotGroup.scale.set(slot.scale);

                const a = new MD.Arena(id, 2);
                slotGroup.addChild(a);
                this.arenas.push(a);

                const md = MINIT_DB[id];
                const c = new PIXI.Container();
                c.position.set(0, (CFG.GRID.ROWS * CFG.GRID.TS) + 10);
                c.addChild(
                    new PIXI.Graphics()
                        .beginFill(PALETTE.CARD_BG)
                        .lineStyle(1, PALETTE.BORDER)
                        .drawRect(0, 0, CFG.UI.CARD.W, CFG.UI.CARD.H).endFill(),
                    new PIXI.Graphics()
                        .beginFill(md.color)
                        .drawRect(0, 0, CFG.UI.CARD.W, 3).endFill()
                );

                const ic = new PIXI.Sprite(Textures[`minit_${md.id}_base`]);
                ic.anchor.set(0.5);
                ic.scale.set(2.5);
                ic.position.set(30, 30);
                c.addChild(ic);

                const nm = new PIXI.Text(md.name, {
                    ...UI_STYLE.H3, fill: md.color
                });
                nm.position.set(65, 10);
                c.addChild(nm);

                const ptsUI = new PIXI.Text("PTS: 0", {
                    ...UI_STYLE.DESC_LARGE, fill: PALETTE.TEXT
                });
                ptsUI.anchor.set(1, 0);
                ptsUI.position.set(230, 10);
                c.addChild(ptsUI);
                a.ptsUI = ptsUI;
                a._lastPts = -1;

                const stStr = md.getStatsStr
                    ? md.getStatsStr(md.ability)
                    : `DMG:${md.ability.dmg}`;
                const st = new PIXI.Text(`CD:${md.cd}f\n${stStr}`,
                    UI_STYLE.STATS_LARGE);
                st.position.set(65, 28);
                c.addChild(st);

                const ds = new PIXI.Text(md.desc, UI_STYLE.DESC_LARGE);
                ds.position.set(12, 62);
                c.addChild(ds);

                slotGroup.addChild(c);
                this.addChild(slotGroup);
            });

            AudioSys.play('start');
            MD.app.ticker.add(this.loop, this);
        }

        loop(dl) {
            if (this.finish) {
                if (this.winPanel && this.showPopup) {
                    this.winScaleVel += (1 - this.winPanel.scale.x) * 0.1;
                    this.winScaleVel *= 0.8;
                    this.winPanel.scale.set(
                        this.winPanel.scale.x + this.winScaleVel);
                }
                return;
            }

            this.frameCounter++;
            const clampedDl = Math.min(dl, CFG.SIM.MAX_DT);
            let currentScale = 1.0 * clampedDl;

            if (this.isSlowmo) {
                currentScale = CFG.SIM.SLOWMO_SPEED * clampedDl;
                this.slowmoTimer -= clampedDl;
                if (this.slowmoTimer <= 0) { this.end(); return; }
            } else if (!this.inOvertime) {
                this.tl -= clampedDl / 60;
                if (this.tl <= 0) {
                    this.tl = 0;
                    this.inOvertime = true;
                    let tot = 0;
                    this.arenas.forEach(a => tot += a.stats.d);
                    this.overtimeTarget = tot + CFG.SIM.OVERTIME_HITS;
                    this.tUI.text = "FINAL STRIKE!";
                    this.tUI.style.fontSize = 16;
                    this.tUI.style.fill = PALETTE.ALERT;
                }
            } else {
                let tot = 0;
                this.arenas.forEach(a => tot += a.stats.d);
                if (tot >= this.overtimeTarget && !this.isSlowmo) {
                    this.isSlowmo = true;
                    this.slowmoTimer = CFG.SIM.SLOWMO_DUR;
                    this.tUI.text = "FINISHED!";
                    this.tUI.style.fontSize = 20;
                    this.tUI.style.fill = PALETTE.ALERT;
                }
            }

            if (!this.inOvertime) {
                const sc = Math.ceil(this.tl);
                this.tUI.text = sc < 10 ? `0${sc}` : sc;
                if (sc <= 5) {
                    this.tUI.scale.set(1 +
                        FastMath.sin(MD.app.ticker.lastTime / 100) * 0.15);
                    this.tUI.style.fill = (MD.app.ticker.lastTime % 500 < 250)
                        ? '#ffffff'
                        : PALETTE.ALERT;
                }
            }

            this.arenas.forEach((a) => {
                a.update(currentScale, true, currentScale);
                const sc = Math.floor(a.stats.d * CFG.SIM.MULT) + a.stats.maxDp;
                if (sc !== a._lastPts) {
                    a.ptsUI.text = `PTS: ${sc}`;
                    a._lastPts = sc;
                }
            });
        }

        end() {
            this.finish = true;
            this.tUI.scale.set(1);
            AudioSys.play('win');

            let highestId = null;
            let highestScore = -1;
            this.arenas.forEach(a => {
                const sc = Math.floor(a.stats.d * CFG.SIM.MULT) + a.stats.maxDp;
                if (sc > highestScore) {
                    highestScore = sc;
                    highestId = a.slots[0] && a.slots[0].id;
                }
            });

            const bg = new PIXI.Graphics()
                .beginFill(0x000000, 0.9)
                .drawRect(-800, -600, 2400, 1800).endFill();
            bg.interactive = bg.buttonMode = true;
            bg.on('pointerdown', () => {
                AudioSys.play('click');
                MD.app.ticker.remove(this.loop, this);
                MD.setScene(new EditorScene(sel =>
                    MD.setScene(new SimulationScene(sel))
                ));
            });

            this.winPanel = new PIXI.Container();
            this.winPanel.position.set(CFG.APP.W / 2, CFG.APP.H / 2);
            this.winPanel.scale.set(0.1);
            this.winScaleVel = 0;

            if (highestId) {
                const md = MINIT_DB[highestId];
                const icon = new PIXI.Sprite(Textures[`minit_${md.id}_base`]);
                icon.anchor.set(0.5);
                icon.scale.set(6);
                icon.position.set(0, -60);
                this.winPanel.addChild(icon);

                const nm = new PIXI.Text(`${md.name} WINS!`,
                    { ...UI_STYLE.H1, fill: md.color });
                nm.anchor.set(0.5);
                nm.position.set(0, 40);
                this.winPanel.addChild(nm);

                const sc = new PIXI.Text(`SCORE : ${highestScore}PTS`,
                    UI_STYLE.H2);
                sc.anchor.set(0.5);
                sc.position.set(0, 90);
                this.winPanel.addChild(sc);
            }

            this.showPopup = false;
            setTimeout(() => {
                this.addChild(bg);
                this.addChild(this.winPanel);
                this.showPopup = true;
            }, 300);
        }
    }

    // ══════════════════════════════════════════════════════════
    // SCENE MANAGER + BOOT
    // ══════════════════════════════════════════════════════════
    let actScene = null;
    let actSceneUpdater = null;

    MD.setScene = function (sc) {
        if (actScene) {
            if (actSceneUpdater) {
                MD.app.ticker.remove(actSceneUpdater);
                actSceneUpdater = null;
            }
            MD.gameContainer.removeChild(actScene);
            actScene.destroy({ children: true });
        }
        actScene = sc;
        MD.gameContainer.addChild(actScene);

        // Auto-update kalau scene punya update()
        if (sc.update) {
            actSceneUpdater = (d) => {
                if (actScene === sc && sc.update) {
                    try { sc.update(d); }
                    catch (e) { console.warn('[Scene update error]', e); }
                }
            };
            MD.app.ticker.add(actSceneUpdater);
        }
    };

    MD.Boot = {
        init() {
            FastMath.init();
            MD.Orientation.init();
            const settings = MD.Settings.load();
            MD.Settings.apply(settings);

            MD.setScene(new LoadingScene(() =>
                MD.setScene(new MenuScene())
            ));
        }
    };

    MD.LoadingScene = LoadingScene;
    MD.LoadingOverlayScene = LoadingOverlayScene;
    MD.SettingsModal = SettingsModal;
    MD.MenuScene = MenuScene;
    MD.EditorScene = EditorScene;
    MD.SimulationScene = SimulationScene;
})();