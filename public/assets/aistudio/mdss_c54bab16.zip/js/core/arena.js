// ==========================================
// ARENA — orchestrator 1..N minit + sparse set
// ==========================================
// Grid config dapat di-inject via options (untuk mode manager).
// Default: pakai CFG.GRID (VS mode behavior).
//
// API:
//   new Arena(minitIds, playerCount, options)
//   options.gridCols, gridRows, tileSize, maxDepth
//   options.cameraMode: 'slot0' (default) | 'active'
//   options.showHUD: true (default)
//   options.areaId: string (untuk rock texture per area)
//   options.slotOptions: { minitScale, createSprite, createEffectsUI }
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG || !MD.MinitSlot || !MD.VFXPool || !MD.SparseSet || !MD.TRAITS || !MD.AssetBaker)
        throw new Error('[arena.js] deps not met');

    const { CFG, FastMath, AudioSys, TRAITS, VFXPool, SparseSet } = MD;

    // Helper: resolve rock texture untuk (areaId, gy).
    // Fallback ke default rock_<idx> kalau area tidak punya custom.
    function resolveRockTexture(areaId, gy) {
        const idx = Math.min(4, Math.floor(gy / 20));
        if (areaId) {
            const key = `rock_${areaId}_${idx}`;
            if (MD.Textures[key]) return MD.Textures[key];
        }
        return MD.AssetBaker.ROCK_TEXTURES[idx];
    }

    MD.Arena = class Arena extends PIXI.Container {
        constructor(minitIds, playerCount, options = {}) {
            super();
            if (typeof minitIds === 'string') minitIds = [minitIds];
            MD.assert(Array.isArray(minitIds) && minitIds.length > 0, '[Arena] invalid minitIds');
            this.minitIds = minitIds;

            // ── Grid config (injectable) ──
            this.cols = options.gridCols ?? CFG.GRID.COLS;
            this.rows = options.gridRows ?? CFG.GRID.ROWS;
            this.ts = options.tileSize ?? CFG.GRID.TS;
            this.halfTs = this.ts / 2;
            this.maxDepth = options.maxDepth ?? CFG.GRID.MAX_DEPTH;

            // ── Area id (untuk rock texture per area) ──
            this.areaId = options.areaId || null;

            // ── Camera mode ──
            this.cameraMode = options.cameraMode ?? 'slot0';
            this.activeSlotIdx = 0;

            this.camY = this.logCamY = this.shake = 0;
            this.simTicks = 0;
            this.vfxLod = CFG.SIM.VFX_LOD[playerCount] || 1.0;

            const AW = this.cols * this.ts;
            const AH = this.rows * this.ts;

            // ── Visual hierarchy ──
            this.view = new PIXI.Container();
            this.addChild(this.view);
            this.view.addChild(new PIXI.Graphics()
                .beginFill(0x000000, 0.75).lineStyle(1, 0x555555)
                .drawRect(-1, -1, AW + 2, AH + 2).endFill());

            const mask = new PIXI.Graphics().beginFill(0xffffff).drawRect(0, 0, AW, AH).endFill();
            this.view.addChild(mask);

            this.layer = new PIXI.Container();
            this.layer.mask = mask;
            this.view.addChild(this.layer);

            this.sprLayer = new PIXI.Container();
            this.layer.addChild(this.sprLayer);
            this.fxLayer = new PIXI.Container();
            this.layer.addChild(this.fxLayer);
            this.fxPool = new VFXPool(this.fxLayer);

            this.toastLayer = new PIXI.Container();
            this.layer.addChild(this.toastLayer);
            this.toasts = [];

            // ── HUD (optional) ──
            if (options.showHUD !== false) {
                this.view.addChild(new PIXI.Graphics()
                    .beginFill(0x000000, 0.65).lineStyle(1, 0x333333)
                    .drawRect(0, 0, 85, 42).endFill());
                this.igUI = new PIXI.Text("Depth:0\nMined:0", MD.UI_STYLE.STATS_LARGE);
                this.igUI.position.set(6, 4);
                this.view.addChild(this.igUI);
            }

            // ── Grid state ──
            this.gridHP = new Int16Array(this.cols * (this.maxDepth + 1));
            this.RENDER_ROWS = this.rows + 2;
            this.textCooldowns = new Uint32Array(this.cols * (this.maxDepth + 1));

            // Viewport blocks
            const COLS = this.cols;
            const N = this.RENDER_ROWS;
            this.vpBlocks = new Array(COLS * N);
            for (let vy = 0; vy < N; vy++) {
                for (let vx = 0; vx < COLS; vx++) {
                    const c = new PIXI.Container();
                    const b = new PIXI.Sprite();
                    const cr = new PIXI.Sprite();
                    cr.visible = false;
                    c.addChild(b, cr);
                    this.sprLayer.addChild(c);
                    this.vpBlocks[vy * COLS + vx] = {
                        c, b, cr,
                        vy,
                        lastGy: -1,
                        dirty: true,
                        lastRockKey: -1
                    };
                }
            }
            this.lastRenderCamYInt = -1;

            this.genGrid((COLS / 2) | 0);

            // ── Entity pool ──
            this.ents = Array.from({ length: 1000 }, () => ({
                active: false, dead: false,
                x: 0, y: 0, curX: 0, curY: 0, dx: 0, dy: 0,
                startX: 0, startY: 0, tx: 0, ty: 0,
                l: 0, maxL: 0, f: 0, step: 0, ang: 0,
                hitGround: false, spinning: false, fallTimer: 0,
                traits: [], p: {}, _ts: {}, owner: null
            }));
            this.entIdx = 0;
            this.activeEnts = new SparseSet();
            this._deadScratch = [];

            // Screen flash
            this.flashAlpha = 0;
            this.screenFlash = new PIXI.Graphics().beginFill(0xffffff).drawRect(0, 0, AW, AH).endFill();
            this.screenFlash.alpha = 0;
            this.view.addChild(this.screenFlash);

            // ── Slots ──
            this.slots = [];
            const slotOpts = options.slotOptions || {};
            for (let i = 0; i < minitIds.length; i++) {
                const minitData = MD.MINIT_DB[minitIds[i]];
                if (!minitData) {
                    console.error(`[Arena] Unknown minit: ${minitIds[i]}`);
                    continue;
                }
                this.slots.push(new MD.MinitSlot(
                    minitIds[i], this, i, minitData,
                    {
                        minitScale: slotOpts.minitScale,
                        createSprite: slotOpts.createSprite,
                        createEffectsUI: slotOpts.createEffectsUI
                    }
                ));
            }

            // ── Backward compat getters ──
            const getSlot0 = (prop) => () => this.slots[0] ? this.slots[0][prop] : undefined;
            Object.defineProperty(this, 'mLog', { get: getSlot0('log') });
            Object.defineProperty(this, 'mSpr', { get: getSlot0('spr') });
            Object.defineProperty(this, 'mState', { get: getSlot0('state') });
            Object.defineProperty(this, 'md', { get: getSlot0('md') });
            Object.defineProperty(this, 'animScale', { get: getSlot0('animScale') });
            Object.defineProperty(this, 'stats', { get: () => this._aggregateStats() });
        }

        // ═══════════════════════════════════════════
        // PUBLIC API
        // ═══════════════════════════════════════════
        setActiveSlot(idx) {
            if (idx < 0 || idx >= this.slots.length) return false;
            this.activeSlotIdx = idx;
            for (let i = 0; i < this.slots.length; i++) {
                const s = this.slots[i];
                if (s.spr) s.spr.tint = (i === idx) ? 0xffffff : 0x555555;
            }
            return true;
        }

        setAreaId(areaId) {
            this.areaId = areaId;
            // Force all tiles to re-check texture
            for (const vpb of this.vpBlocks) {
                vpb.dirty = true;
                vpb.lastRockKey = -1;
            }
        }

        // ═══════════════════════════════════════════
        // AGGREGATE STATS
        // ═══════════════════════════════════════════
        _aggregateStats() {
            if (!this._statsCache) this._statsCache = { d: 0, maxDp: 0 };
            let d = 0, maxDp = 0;
            for (const s of this.slots) {
                d += s.stats.d;
                if (s.stats.maxDp > maxDp) maxDp = s.stats.maxDp;
            }
            this._statsCache.d = d;
            this._statsCache.maxDp = maxDp;
            return this._statsCache;
        }

        // ═══════════════════════════════════════════
        // GRID
        // ═══════════════════════════════════════════
        genGrid(startX) {
            const COLS = this.cols;
            const MAX_DEPTH = this.maxDepth;
            for (let y = 0; y < MAX_DEPTH; y++) {
                for (let x = 0; x < COLS; x++) {
                    this.gridHP[y * COLS + x] =
                        CFG.ARENA.BASE_HP + (y * CFG.ARENA.HP_SCALING) + (FastMath.rand() * 20 | 0);
                }
            }
            this.gridHP[0 * COLS + startX] = 0;
            this.gridHP[1 * COLS + startX] = 0;
        }

        clampX(x) { return Math.max(0, Math.min(this.cols - 1, x)); }
        clampY(y) { return Math.max(0, Math.min(this.maxDepth - 1, y)); }

        getPixelCoords(gx, gy) {
            return {
                px: gx * this.ts + this.halfTs,
                py: (gy - this.camY) * this.ts + this.halfTs
            };
        }

        getHP(x, y) {
            if (x < 0 || x >= this.cols || y < 0 || y >= this.maxDepth) return 9999;
            return this.gridHP[y * this.cols + x];
        }

        triggerFlash(a = 0.5) { this.flashAlpha = Math.max(this.flashAlpha, a); }

        // ═══════════════════════════════════════════
        // ENTITY SPAWN
        // ═══════════════════════════════════════════
        spawnEnt(props) {
            for (let i = 0; i < this.ents.length; i++) {
                this.entIdx = (this.entIdx + 1) % this.ents.length;
                const e = this.ents[this.entIdx];
                if (e.active) continue;
                e.active = true;
                e.dead = false;
                e.hitGround = false;
                e.spinning = false;
                e.fallTimer = 0;
                e.step = 0;
                e.x = props.x ?? 0;
                e.y = props.y ?? 0;
                e.startX = props.startX ?? e.x;
                e.startY = props.startY ?? e.y;
                e.curX = props.startX ?? e.x;
                e.curY = props.startY ?? e.y;
                e.tx = props.tx ?? 0;
                e.ty = props.ty ?? 0;
                e.dx = props.dx ?? 0;
                e.dy = props.dy ?? 0;
                e.l = props.l ?? 0;
                e.maxL = props.maxL ?? e.l;
                e.f = props.f ?? 0;
                e.ang = props.ang ?? 0;
                e.traits = props.traits || [];
                // Merge customTraits dari owner slot
                if (props.owner && props.owner.customTraits && props.owner.customTraits.length > 0) {
                    e.traits = e.traits.concat(props.owner.customTraits);
                }
                e.p = props.p || {};
                e._ts = {};
                e.counter = 0;
                e.owner = props.owner || null;
                this.activeEnts.add(e);
                return e;
            }
            return null;
        }

        // ═══════════════════════════════════════════
        // DIRTY MARKING
        // ═══════════════════════════════════════════
        _markDirty(x, y) {
            const rY = y - (this.camY | 0);
            if (rY < 0 || rY >= this.RENDER_ROWS) return;
            const vpb = this.vpBlocks[rY * this.cols + x];
            if (vpb) vpb.dirty = true;
        }

        // ═══════════════════════════════════════════
        // DAMAGE
        // ═══════════════════════════════════════════
        dmg(x, y, amount, showText = false, fxColor = 0xff0000, creditTo = null) {
            const COLS = this.cols;
            const TS = this.ts;
            const HALF_TS = this.halfTs;
            const ROWS = this.rows;

            if (x < 0 || x >= COLS || y < 0 || y >= this.maxDepth) return false;
            const id = y * COLS + x;
            const curHp = this.gridHP[id];
            if (curHp <= 0) return false;

            const maxHp = CFG.ARENA.BASE_HP + (y * CFG.ARENA.HP_SCALING);
            const oldPct = curHp / maxHp;
            this.gridHP[id] -= amount;
            const newPct = this.gridHP[id] / maxHp;

            this._markDirty(x, y);

            const rY = y - (this.camY | 0);
            if (rY >= -1 && rY <= ROWS) {
                const pX = x * TS;
                const pY = rY * TS;

                if (showText && this.simTicks > this.textCooldowns[id]) {
                    this.textCooldowns[id] = this.simTicks + CFG.VFX.TEXT_COOLDOWN;
                    this.fxPool.spawnDmgText(pX, pY, amount, fxColor);
                }
                if (((oldPct * 4) | 0) > ((newPct * 4) | 0) && this.gridHP[id] > 0) {
                    const dC = Math.ceil(2 * this.vfxLod);
                    for (let i = 0; i < dC; i++) {
                        this.fxPool.spawnPhysics('fx_dust',
                            pX + HALF_TS, pY + HALF_TS,
                            FastMath.randRange(-2, 2), FastMath.randRange(-3, 0),
                            15, 0.85, 0.9, true);
                    }
                }
            }

            if (this.gridHP[id] <= 0) {
                this.gridHP[id] = 0;
                if (creditTo) creditTo.stats.d++;
                else if (this.slots.length > 0) this.slots[0].stats.d++;
                AudioSys.play('crush');
                if (rY >= -1 && rY <= ROWS) {
                    const cC = Math.ceil(6 * this.vfxLod);
                    for (let i = 0; i < cC; i++) {
                        this.fxPool.spawnPhysics('fx_dust',
                            x * TS + HALF_TS,
                            rY * TS + HALF_TS,
                            FastMath.randRange(-4, 4), FastMath.randRange(-7, -2),
                            25, 0.8, 0.95, true);
                    }
                }
                if (this.onRockDestroyed) {
                    try { this.onRockDestroyed(x, y, creditTo); }
                    catch (e) { console.warn('[Arena] onRockDestroyed error:', e); }
                }
                return true;
            } else if (!showText) {
                AudioSys.play('hit', 0.5);
            }
            return false;
        }

        dmgAoE(cx, cy, range, amt, color, creditTo = null) {
            for (let dy = -range; dy <= range; dy++)
                for (let dx = -range; dx <= range; dx++)
                    this.dmg(cx + dx, cy + dy, amt, true, color, creditTo);
        }

        // ═══════════════════════════════════════════
        // TOAST
        // ═══════════════════════════════════════════
        spawnToast(pX, pY, text, color) {
            const t = new PIXI.Text(text, {
                fontFamily: '"Press Start 2P"', fontSize: 8,
                fill: '#' + color.toString(16).padStart(6, '0'),
                stroke: '#000000', strokeThickness: 4
            });
            t.anchor.set(0.5); t.x = pX; t.y = pY; t.alpha = 1;
            this.toastLayer.addChild(t);
            this.toasts.push({ text: t, life: 40, maxLife: 40, vy: -1.2, vx: FastMath.randRange(-0.5, 0.5) });
        }

        _tickToasts(timeScale) {
            for (let i = this.toasts.length - 1; i >= 0; i--) {
                const t = this.toasts[i];
                t.life -= timeScale;
                if (t.life <= 0) {
                    if (t.text.parent) t.text.parent.removeChild(t.text);
                    t.text.destroy();
                    this.toasts.splice(i, 1);
                    continue;
                }
                t.text.y += t.vy * timeScale;
                t.text.x += t.vx * timeScale;
                t.text.alpha = Math.min(1, t.life / 20);
            }
        }

        // ═══════════════════════════════════════════
        // UPDATE
        // ═══════════════════════════════════════════
        update(renderTimeScale, shouldUpdateLogic, logicTimeScale) {
            if (shouldUpdateLogic) {
                this.tickAcc = (this.tickAcc || 0) + logicTimeScale;
                let iterations = 0;
                while (this.tickAcc >= 1 && iterations < CFG.SIM.MAX_ITERATIONS) {
                    this.tickLogic();
                    this.tickAcc -= 1;
                    iterations++;
                }
            }
            this.updateVisuals(renderTimeScale);
        }

        tickLogic() {
            this.simTicks++;
            for (const slot of this.slots) slot.tick();

            const ents = this.activeEnts.items;
            const n = ents.length;
            for (let i = 0; i < n; i++) {
                const e = ents[i];
                for (let j = 0; j < e.traits.length; j++) {
                    const fn = TRAITS[e.traits[j]];
                    if (fn) {
                        try { fn(e, this); }
                        catch (err) { console.error(`[Arena] trait "${e.traits[j]}" error:`, err); }
                    }
                }
            }

            this._deadScratch.length = 0;
            for (let i = 0; i < ents.length; i++) if (ents[i].dead) this._deadScratch.push(ents[i]);
            for (const e of this._deadScratch) {
                e.active = false;
                this.activeEnts.remove(e);
            }

            let targetLog = null;
            if (this.cameraMode === 'active' && this.slots[this.activeSlotIdx]) {
                targetLog = this.slots[this.activeSlotIdx].log;
            } else {
                targetLog = this.slots[0]?.log;
            }
            if (targetLog) {
                this.logCamY = Math.max(0, Math.min(
                    targetLog.y - ((this.rows / 2) | 0),
                    this.maxDepth - this.rows
                ));
            }

            if (this.igUI) {
                const agg = this._aggregateStats();
                this.igUI.text = `Depth:${agg.maxDp}\nMined:${agg.d}`;
            }
        }

        updateVisuals(timeScale) {
            this.camY += (this.logCamY - this.camY) * CFG.RENDER.CAM_LERP * timeScale;

            const cYInt = this.camY | 0;
            const cYFrac = this.camY - cYInt;
            const COLS = this.cols;
            const N = this.RENDER_ROWS;
            const TS = this.ts;
            const areaId = this.areaId;

            for (let vy = 0; vy < N; vy++) {
                const gy = cYInt + vy;
                const yPos = (vy - cYFrac) * TS;
                const maxHp = CFG.ARENA.BASE_HP + (gy * CFG.ARENA.HP_SCALING);
                const rockIdx = Math.min(4, (gy / 20) | 0);
                const texRock = resolveRockTexture(areaId, gy);
                const rockKey = (areaId ? areaId.charCodeAt(0) * 100 : 0) + rockIdx;

                for (let vx = 0; vx < COLS; vx++) {
                    const vpb = this.vpBlocks[vy * COLS + vx];

                    if (vpb.lastGy !== gy) {
                        vpb.lastGy = gy;
                        vpb.dirty = true;
                    }
                    // Area change → re-check rock key
                    if (vpb.lastRockKey !== rockKey) {
                        vpb.lastRockKey = rockKey;
                        vpb.dirty = true;
                    }

                    vpb.c.x = vx * TS;
                    vpb.c.y = yPos;

                    if (vpb.dirty) {
                        vpb.dirty = false;
                        const hp = this.getHP(vx, gy);
                        if (hp <= 0 || hp === 9999) {
                            vpb.c.visible = false;
                        } else {
                            vpb.c.visible = true;
                            vpb.b.texture = texRock;
                            vpb.b.width = TS;
                            vpb.b.height = TS;
                            vpb.b.alpha = 0.6;
                            const pct = hp / maxHp;
                            if (pct > 0.9) vpb.cr.visible = false;
                            else {
                                vpb.cr.visible = true;
                                vpb.cr.width = TS;
                                vpb.cr.height = TS;
                                if (pct > 0.75) vpb.cr.texture = MD.Textures['crack_1'];
                                else if (pct > 0.5) vpb.cr.texture = MD.Textures['crack_2'];
                                else if (pct > 0.25) vpb.cr.texture = MD.Textures['crack_3'];
                                else vpb.cr.texture = MD.Textures['crack_4'];
                            }
                        }
                    }
                }
            }
            this.lastRenderCamYInt = cYInt;

            for (const slot of this.slots) slot.updateVisuals(timeScale);
            this.fxPool.update(this.camY, timeScale);
            this._tickToasts(timeScale);

            if (this.flashAlpha > 0) {
                this.screenFlash.alpha = this.flashAlpha;
                this.flashAlpha -= 0.05 * timeScale;
            } else this.screenFlash.alpha = 0;

            if (this.shake > 0) {
                this.view.position.set(
                    FastMath.randRange(-this.shake / 2, this.shake / 2),
                    FastMath.randRange(-this.shake / 2, this.shake / 2));
                this.shake *= Math.pow(0.8, timeScale);
                if (this.shake < 0.5) this.shake = 0;
            } else this.view.position.set(0, 0);
        }

        destroy(options) {
            for (const slot of this.slots) {
                try { slot.destroy(); }
                catch (e) { console.warn('[Arena] slot destroy error:', e); }
            }
            for (const t of this.toasts) {
                if (t.text && !t.text.destroyed) t.text.destroy();
            }
            super.destroy(options);
        }
    };
})();