// ==========================================
// ASSET BAKER — runtime texture generation
// ==========================================
// Bakes:
//   - Core VFX
//   - Icons (diamond, gear, flask, hex, shard, rune, essence, ember, dll)
//   - Rocks (default + per-area)
//   - Cracks
//   - Minit textures + vfx
//   - Digits
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG || !MD.PALETTE || !MD.UI_STYLE) throw new Error('[asset-baker.js] deps not met');

    MD.Textures = MD.Textures || {};
    const { CFG, PALETTE, Textures, FastMath } = MD;

    class AssetBaker {
        static bake() {
            if (this._baked) return;
            this._baked = true;
            const gfx = new PIXI.Graphics();
            const TS = CFG.GRID.TS;
            this._bakeDefaultRocks(gfx, TS);
            this._bakeAreaRocks(gfx, TS);
            this._bakeCracks(gfx, TS);
            this._bakeCoreVfx(gfx, TS);
            this._bakeIcons(gfx);
            this._bakeMinitVfx(gfx);
            this._bakeDigits();
            this._audit();
        }

        // ═══════════════════════════════════════════
        // DEFAULT ROCKS (fallback)
        // ═══════════════════════════════════════════
        static _bakeDefaultRocks(gfx, TS) {
            const rocks = [];
            for (let i = 0; i < PALETTE.ROCKS.length; i++) {
                this._drawRock(gfx, TS, PALETTE.ROCKS[i], 'solid');
                Textures[`rock_${i}`] = MD.app.renderer.generateTexture(gfx);
                rocks.push(Textures[`rock_${i}`]);
            }
            AssetBaker.ROCK_TEXTURES = rocks;
        }

        // ═══════════════════════════════════════════
        // AREA ROCKS
        // ═══════════════════════════════════════════
        static _bakeAreaRocks(gfx, TS) {
            const registry = MD.MM && MD.MM.Registry;
            if (!registry || !registry.AREA_REGISTRY) return;

            for (const area of Object.values(registry.AREA_REGISTRY)) {
                const rockDef = area.rocks;
                if (!rockDef || !Array.isArray(rockDef.colors)) continue;
                const shape = rockDef.shape || 'solid';
                for (let i = 0; i < rockDef.colors.length; i++) {
                    try {
                        this._drawRock(gfx, TS, rockDef.colors[i], shape);
                        Textures[`rock_${area.id}_${i}`] = MD.app.renderer.generateTexture(gfx);
                    } catch (e) {
                        console.warn(`[AssetBaker] Failed rock for area ${area.id} index ${i}:`, e);
                        // Fallback
                        this._drawRock(gfx, TS, rockDef.colors[i], 'solid');
                        Textures[`rock_${area.id}_${i}`] = MD.app.renderer.generateTexture(gfx);
                    }
                }
            }
        }

        // ═══════════════════════════════════════════
        // ROCK SHAPE GENERATOR
        // ═══════════════════════════════════════════
        static _drawRock(gfx, TS, baseColor, shape) {
            gfx.clear();
            gfx.beginFill(baseColor).drawRect(0, 0, TS, TS);

            // Shape decoration
            switch (shape) {
                case 'crystal':
                    // Facet lines
                    gfx.lineStyle(1, 0xffffff, 0.3);
                    gfx.moveTo(TS * 0.2, 0).lineTo(TS * 0.5, TS * 0.5).lineTo(TS * 0.8, 0);
                    gfx.moveTo(TS * 0.5, TS * 0.5).lineTo(TS, TS * 0.8);
                    gfx.moveTo(TS * 0.5, TS * 0.5).lineTo(0, TS * 0.8);
                    gfx.lineStyle(0);
                    // Highlight corner
                    gfx.beginFill(0xffffff, 0.2);
                    gfx.moveTo(TS * 0.5, TS * 0.5).lineTo(TS * 0.8, 0).lineTo(TS, 0).lineTo(TS, TS * 0.3).closePath().endFill();
                    break;
                case 'rusty':
                    // Rust spots
                    gfx.beginFill(0x000000, 0.3);
                    for (let k = 0; k < 8; k++) {
                        gfx.drawRect(
                            (FastMath.rand() * (TS - 6) + 3) | 0,
                            (FastMath.rand() * (TS - 6) + 3) | 0,
                            3, 3
                        );
                    }
                    gfx.endFill();
                    // Highlight top
                    gfx.beginFill(0xffffff, 0.1).drawRect(0, 0, TS, 3).endFill();
                    break;
                case 'organic':
                    // Speckled texture
                    gfx.beginFill(0x000000, 0.2);
                    for (let k = 0; k < 12; k++) {
                        gfx.drawCircle(
                            (FastMath.rand() * TS) | 0,
                            (FastMath.rand() * TS) | 0,
                            1 + (FastMath.rand() * 2) | 0
                        );
                    }
                    gfx.endFill();
                    gfx.beginFill(0xffffff, 0.15);
                    for (let k = 0; k < 6; k++) {
                        gfx.drawCircle(
                            (FastMath.rand() * TS) | 0,
                            (FastMath.rand() * TS) | 0,
                            1
                        );
                    }
                    gfx.endFill();
                    break;
                case 'metallic':
                    // Diagonal highlights
                    gfx.beginFill(0xffffff, 0.15);
                    gfx.moveTo(0, TS * 0.7);
                    gfx.lineTo(TS * 0.7, 0);
                    gfx.lineTo(TS, 0);
                    gfx.lineTo(0, TS);
                    gfx.closePath().endFill();
                    gfx.beginFill(0x000000, 0.15);
                    gfx.moveTo(TS * 0.3, TS);
                    gfx.lineTo(TS, TS * 0.3);
                    gfx.lineTo(TS, TS);
                    gfx.closePath().endFill();
                    break;
                default: // solid
                    gfx.beginFill(0x000000, 0.4);
                    for (let k = 0; k < 6; k++) {
                        gfx.drawRect(
                            (FastMath.rand() * (TS - 4) + 2) | 0,
                            (FastMath.rand() * (TS - 4) + 2) | 0,
                            2, 2
                        );
                    }
                    gfx.endFill();
                    gfx.beginFill(0xffffff, 0.15).drawRect(0, 0, TS, 2).endFill();
                    gfx.beginFill(0x000000, 0.5).drawRect(0, TS - 2, TS, 2).endFill();
                    break;
            }
        }

        static _bakeCracks(gfx, TS) {
            for (let c = 1; c <= 4; c++) {
                gfx.clear().lineStyle(1, 0x000000, 1);
                for (let j = 0; j < c * 3; j++) {
                    gfx.moveTo(FastMath.rand() * TS, FastMath.rand() * TS);
                    gfx.lineTo(FastMath.rand() * TS, FastMath.rand() * TS);
                }
                Textures[`crack_${c}`] = MD.app.renderer.generateTexture(gfx);
            }
        }

        static _bakeCoreVfx(gfx, TS) {
            gfx.clear().beginFill(0xff8800, 0.9).drawRect(0, 0, TS, TS);
            Textures['fx_explosion'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().beginFill(0xffdd00, 1).drawRect(4, 4, 8, 8);
            Textures['fx_shrapnel'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().beginFill(0xffffff, 1).drawRect(0, 0, TS, TS);
            Textures['fx_flash'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().beginFill(0xcc00ff, 0.9).drawRect(6, 6, 4, 4);
            Textures['fx_nano'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().beginFill(0xaaaaaa, 1).drawRect(0, 0, 4, 4);
            Textures['fx_dust'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().lineStyle(2, 0xffffff, 1).drawCircle(64, 64, 60);
            Textures['fx_ring'] = MD.app.renderer.generateTexture(gfx);
            gfx.clear().lineStyle(3, 0x0088ff, 0.2).moveTo(32, 0).lineTo(32, 32).moveTo(0, 32).lineTo(32, 32);
            gfx.lineStyle(1, 0x00ccff, 0.05).moveTo(32, 0).lineTo(32, 32).moveTo(0, 32).lineTo(32, 32);
            Textures['bg_grid'] = MD.app.renderer.generateTexture(gfx);
        }

        // ═══════════════════════════════════════════
        // ICONS
        // ═══════════════════════════════════════════
        static _bakeIcons(gfx) {
            const S = 24;
            const HALF = S / 2;
            const draw = (fn, color) => {
                gfx.clear();
                fn(gfx, HALF, HALF, color);
                return MD.app.renderer.generateTexture(gfx);
            };

            // ─── Resource icons ───
            // Diamond
            Textures['icon_diamond'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx, cy - 9).lineTo(cx + 7, cy)
                    .lineTo(cx, cy + 9).lineTo(cx - 7, cy).closePath().endFill();
                g.beginFill(0xffffff, 0.5).drawRect(cx - 1, cy - 5, 2, 4).endFill();
            }, 0x00ffcc);

            // Gear
            Textures['icon_gear'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                for (let i = 0; i < 6; i++) {
                    const a = (i / 6) * Math.PI * 2;
                    g.drawRect(cx + Math.cos(a) * 8 - 2, cy + Math.sin(a) * 8 - 2, 4, 4);
                }
                g.endFill();
                g.beginFill(c, 1).drawCircle(cx, cy, 7).endFill();
                g.beginFill(0x000000, 1).drawCircle(cx, cy, 3).endFill();
            }, 0xcccccc);

            // Flask
            Textures['icon_flask'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx - 3, cy - 8).lineTo(cx + 3, cy - 8)
                    .lineTo(cx + 3, cy - 2).lineTo(cx + 7, cy + 6)
                    .lineTo(cx + 7, cy + 8).lineTo(cx - 7, cy + 8)
                    .lineTo(cx - 7, cy + 6).lineTo(cx - 3, cy - 2).closePath().endFill();
                g.beginFill(0xffffff, 0.4).drawRect(cx - 5, cy + 2, 10, 4).endFill();
            }, 0xcc88ff);

            // Hex (cores)
            Textures['icon_hex'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                for (let i = 0; i < 6; i++) {
                    const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
                    const px = cx + Math.cos(a) * 8;
                    const py = cy + Math.sin(a) * 8;
                    if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
                }
                g.closePath().endFill();
                g.beginFill(0xffffff, 0.6).drawCircle(cx, cy, 3).endFill();
            }, 0xffaa44);

            // Shard (triangle)
            Textures['icon_shard'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx, cy - 10).lineTo(cx + 8, cy + 6).lineTo(cx - 8, cy + 6).closePath().endFill();
                g.beginFill(0xffffff, 0.5).drawRect(cx - 1, cy - 4, 2, 6).endFill();
            }, 0xff88ff);

            // Rune (square rotated with glyph)
            Textures['icon_rune'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx - 7, cy - 7).lineTo(cx + 7, cy - 7)
                    .lineTo(cx + 7, cy + 7).lineTo(cx - 7, cy + 7).closePath().endFill();
                g.lineStyle(2, 0x000000, 0.6);
                g.moveTo(cx - 3, cy - 3).lineTo(cx - 3, cy + 3);
                g.moveTo(cx + 3, cy - 3).lineTo(cx + 3, cy + 3);
                g.moveTo(cx - 3, cy).lineTo(cx + 3, cy);
                g.lineStyle(0);
            }, 0xffcc44);

            // Essence (droplet)
            Textures['icon_essence'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx, cy - 9).lineTo(cx + 5, cy).lineTo(cx + 3, cy + 6)
                    .lineTo(cx - 3, cy + 6).lineTo(cx - 5, cy).closePath().endFill();
                g.beginFill(0xffffff, 0.4).drawCircle(cx - 1, cy, 2).endFill();
            }, 0x88ff44);

            // Ember (flame)
            Textures['icon_ember'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx, cy - 10).lineTo(cx + 5, cy - 2).lineTo(cx + 7, cy + 4)
                    .lineTo(cx + 3, cy + 8).lineTo(cx - 3, cy + 8)
                    .lineTo(cx - 7, cy + 4).lineTo(cx - 5, cy - 2).closePath().endFill();
                g.beginFill(0xffff00, 0.6);
                g.moveTo(cx, cy - 4).lineTo(cx + 2, cy + 2).lineTo(cx - 2, cy + 2).closePath().endFill();
            }, 0xff6622);

            // ─── UI icons ───
            Textures['icon_sword'] = draw((g, cx, cy, c) => {
                g.lineStyle(2, c, 1);
                g.moveTo(cx - 7, cy + 7).lineTo(cx + 7, cy - 7);
                g.lineStyle(0);
                g.beginFill(c, 1);
                g.moveTo(cx + 7, cy - 7).lineTo(cx + 5, cy - 9)
                    .lineTo(cx + 9, cy - 5).lineTo(cx + 7, cy - 7).closePath().endFill();
                g.beginFill(0xffffff, 1).drawRect(cx - 5, cy + 2, 3, 3).endFill();
            }, 0xffcc88);

            Textures['icon_lightning'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx - 2, cy - 10).lineTo(cx + 5, cy - 3)
                    .lineTo(cx + 1, cy - 3).lineTo(cx + 4, cy + 10)
                    .lineTo(cx - 5, cy - 1).lineTo(cx - 1, cy - 1).closePath().endFill();
            }, 0x88ddff);

            Textures['icon_hammer'] = draw((g, cx, cy, c) => {
                g.lineStyle(3, 0x888888, 1);
                g.moveTo(cx - 5, cy + 8).lineTo(cx + 3, cy - 2);
                g.lineStyle(0);
                g.beginFill(c, 1).drawRect(cx + 1, cy - 8, 9, 6).endFill();
                g.beginFill(0xffffff, 0.4).drawRect(cx + 1, cy - 8, 9, 2).endFill();
            }, 0xddaaff);

            Textures['icon_box'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.drawRect(cx - 8, cy - 5, 16, 12).endFill();
                g.beginFill(c, 1).drawRect(cx - 10, cy - 8, 20, 5).endFill();
                g.beginFill(0xff0055, 1).drawRect(cx - 2, cy - 8, 4, 15).endFill();
                g.beginFill(0xffff00, 1);
                g.drawCircle(cx - 4, cy - 6, 2);
                g.drawCircle(cx + 4, cy - 6, 2);
                g.endFill();
            }, 0xffdd44);

            Textures['icon_trophy'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1).drawRect(cx - 5, cy - 6, 10, 8).endFill();
                g.beginFill(c, 1);
                g.drawRect(cx - 8, cy - 6, 3, 5);
                g.drawRect(cx + 5, cy - 6, 3, 5);
                g.endFill();
                g.beginFill(0x888888, 1);
                g.drawRect(cx - 1, cy + 2, 2, 5);
                g.drawRect(cx - 5, cy + 7, 10, 2);
                g.endFill();
                g.beginFill(0xffffff, 0.5).drawRect(cx - 3, cy - 4, 2, 4).endFill();
            }, 0xffcc44);

            Textures['icon_play'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx - 6, cy - 8).lineTo(cx + 8, cy)
                    .lineTo(cx - 6, cy + 8).closePath().endFill();
            }, 0x88ffaa);

            Textures['icon_lock'] = draw((g, cx, cy, c) => {
                g.lineStyle(2, c, 1);
                g.arc(cx, cy - 3, 4, Math.PI, 0);
                g.lineStyle(0);
                g.beginFill(c, 1).drawRect(cx - 6, cy - 3, 12, 10).endFill();
                g.beginFill(0x000000, 0.6).drawCircle(cx, cy + 1, 2).endFill();
                g.beginFill(0x000000, 0.6).drawRect(cx - 1, cy + 1, 2, 3).endFill();
            }, 0xff4444);

            Textures['icon_arrow_left'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx + 5, cy - 9).lineTo(cx - 5, cy)
                    .lineTo(cx + 5, cy + 9).closePath().endFill();
            }, 0x00ccff);

            Textures['icon_arrow_right'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.moveTo(cx - 5, cy - 9).lineTo(cx + 5, cy)
                    .lineTo(cx - 5, cy + 9).closePath().endFill();
            }, 0x00ccff);

            Textures['icon_plus'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                g.drawRect(cx - 8, cy - 2, 16, 4);
                g.drawRect(cx - 2, cy - 8, 4, 16);
                g.endFill();
            }, 0x555555);

            // Star icons (for rating)
            Textures['icon_star_filled'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                for (let i = 0; i < 5; i++) {
                    const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
                    const px = cx + Math.cos(a) * 8;
                    const py = cy + Math.sin(a) * 8;
                    if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
                    const a2 = a + Math.PI / 5;
                    g.lineTo(cx + Math.cos(a2) * 3.5, cy + Math.sin(a2) * 3.5);
                }
                g.closePath().endFill();
            }, 0xffcc44);

            Textures['icon_star_empty'] = draw((g, cx, cy, c) => {
                g.beginFill(c, 1);
                for (let i = 0; i < 5; i++) {
                    const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
                    const px = cx + Math.cos(a) * 8;
                    const py = cy + Math.sin(a) * 8;
                    if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
                    const a2 = a + Math.PI / 5;
                    g.lineTo(cx + Math.cos(a2) * 3.5, cy + Math.sin(a2) * 3.5);
                }
                g.closePath().endFill();
            }, 0x333344);
        }

        static _bakeMinitVfx(gfx) {
            Object.values(MD.MINIT_DB).forEach(m => {
                if (m.textures) {
                    Object.keys(m.textures).forEach(k => {
                        gfx.clear().lineStyle(1, 0x000000, 1, 0);
                        m.textures[k](gfx, m.color);
                        gfx.lineStyle(0).beginFill(0, 0).drawRect(-12, -12, 24, 24).endFill();
                        Textures[`minit_${m.id}_${k}`] = MD.app.renderer.generateTexture(gfx);
                    });
                }
                if (m.vfx) {
                    Object.keys(m.vfx).forEach(name => {
                        gfx.clear().lineStyle(1, 0x000000, 1, 0);
                        m.vfx[name](gfx, m.color);
                        Textures[`minit_${m.id}_vfx_${name}`] = MD.app.renderer.generateTexture(gfx);
                    });
                }
            });
        }

        static _bakeDigits() {
            const style = MD.UI_STYLE.DMG_POPUP;
            for (let i = 0; i <= 9; i++) {
                const t = new PIXI.Text(i.toString(), style);
                Textures['digit_' + i] = MD.app.renderer.generateTexture(t);
                t.destroy();
            }
            const tm = new PIXI.Text("-", style);
            Textures['digit_minus'] = MD.app.renderer.generateTexture(tm);
            tm.destroy();
        }

        static _audit() {
            const missing = new Set();

            // Minit textures
            Object.values(MD.MINIT_DB).forEach(m => {
                if (m.textures) Object.keys(m.textures).forEach(k => {
                    if (!Textures[`minit_${m.id}_${k}`]) missing.add(`minit_${m.id}_${k}`);
                });
                if (m.vfx) Object.keys(m.vfx).forEach(k => {
                    if (!Textures[`minit_${m.id}_vfx_${k}`]) missing.add(`minit_${m.id}_vfx_${k}`);
                });
            });

            // Resource icons
            const registry = MD.MM && MD.MM.Registry;
            if (registry && registry.RESOURCE_REGISTRY) {
                for (const r of Object.values(registry.RESOURCE_REGISTRY)) {
                    if (r.iconTexture && !Textures[r.iconTexture]) {
                        missing.add(`${r.iconTexture} (resource: ${r.id})`);
                    }
                }
            }

            // Area rocks
            if (registry && registry.AREA_REGISTRY) {
                for (const area of Object.values(registry.AREA_REGISTRY)) {
                    if (area.rocks && Array.isArray(area.rocks.colors)) {
                        for (let i = 0; i < area.rocks.colors.length; i++) {
                            if (!Textures[`rock_${area.id}_${i}`]) {
                                missing.add(`rock_${area.id}_${i}`);
                            }
                        }
                    }
                }
            }

            if (missing.size > 0) {
                console.warn('[AssetBaker] Missing textures:');
                missing.forEach(t => console.warn(`   ✗ ${t}`));
            } else {
                console.log('[AssetBaker] All texture references resolved ✓');
            }
        }
    }

    MD.AssetBaker = AssetBaker;
})();