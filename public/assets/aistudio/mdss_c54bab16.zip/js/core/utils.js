// ==========================================
// UTILS — MinitLoader + FastMath + AudioSys + VFXPool + SparseSet
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[utils.js] namespace.js not loaded');
    if (!MD.CFG) throw new Error('[utils.js] config.js must load before utils.js');
    if (!MD.AUDIO_PROFS) throw new Error('[utils.js] sfx.js must load before utils.js');

    const { CFG, AUDIO_PROFS } = MD;

    // ═══════════════════════════════════════════
    // MINIT LOADER
    // ═══════════════════════════════════════════
    const MinitLoader = {
        DB: {},  // akan di-attach ke MD.MINIT_DB
        MANIFEST: ['laser.js', 'moth.js', 'absorb.js', 'lithos.js'],
        BASE_PATH: 'js/datas/minits/',
        loaded: false,

        async load() {
            if (this.loaded) return;
            try {
                const res = await fetch(this.BASE_PATH + '1manifest.json');
                if (res.ok) {
                    const data = await res.json();
                    if (Array.isArray(data.minits) && data.minits.length > 0) {
                        this.MANIFEST = data.minits;
                    }
                }
            } catch (e) {
                console.warn('[MinitLoader] manifest.json unavailable, using fallback.');
            }

            await Promise.all(this.MANIFEST.map(file =>
                this._loadScript(this.BASE_PATH + file).catch(err => {
                    console.error(err.message);
                    return null;
                })
            ));

            this.loaded = true;
            console.log(`[MinitLoader] Loaded ${Object.keys(this.DB).length}/${this.MANIFEST.length} minits:`,
                Object.keys(this.DB).join(', '));
        },

        _loadScript(src) {
            return new Promise((resolve, reject) => {
                const s = document.createElement('script');
                s.src = src;
                s.async = false;
                s.onload = () => resolve(src);
                s.onerror = () => reject(new Error(`[MinitLoader] Failed: ${src}`));
                document.head.appendChild(s);
            });
        }
    };

    // Attach DB ke MD, alias MINIT_DB untuk minit files
    MD.MINIT_DB = MinitLoader.DB;

    // ═══════════════════════════════════════════
    // FAST MATH (LUT-based)
    // ═══════════════════════════════════════════
    const FastMath = {
        seed: 123456789,
        sinLUT: new Float32Array(1024),
        cosLUT: new Float32Array(1024),
        PI: 3.14159265359,

        init() {
            for (let i = 0; i < 1024; i++) {
                const rad = (i * Math.PI * 2) / 1024;
                this.sinLUT[i] = Math.sin(rad);
                this.cosLUT[i] = Math.cos(rad);
            }
            this.seed = (Date.now() ^ (Math.random() * 0x100000000)) | 0;
        },
        rand() {
            this.seed = (this.seed * 1664525 + 1013904223) | 0;
            return (this.seed & 0x7fffffff) / 0x7fffffff;
        },
        randRange(min, max) { return min + this.rand() * (max - min); },
        sin(rad) { return this.sinLUT[((rad > 0 ? rad : -rad) * 162.97466) & 1023] * (rad > 0 ? 1 : -1); },
        cos(rad) { return this.cosLUT[((rad > 0 ? rad : -rad) * 162.97466) & 1023]; }
    };
    // Attach EARLY agar sfx.js deferred functions bisa akses
    MD.FastMath = FastMath;

    // ═══════════════════════════════════════════
    // AUDIO SYSTEM
    // ═══════════════════════════════════════════
    const AudioSys = {
        ctx: new (window.AudioContext || window.webkitAudioContext)(),
        lastPlay: {},
        masterGain: null,
        compressor: null,

        init() {
            if (this.ctx.state === 'suspended') this.ctx.resume();
            if (!this.masterGain) {
                this.masterGain = this.ctx.createGain();
                this.masterGain.gain.value = CFG.AUDIO.MASTER_GAIN;
                this.compressor = this.ctx.createDynamicsCompressor();
                this.compressor.threshold.value = CFG.AUDIO.COMPRESSOR.THRESHOLD;
                this.compressor.ratio.value = CFG.AUDIO.COMPRESSOR.RATIO;
                this.masterGain.connect(this.compressor);
                this.compressor.connect(this.ctx.destination);
            }
        },

        play(type, volMult = 1) {
            if (this.ctx.state === 'suspended' || !this.masterGain) return;
            const now = this.ctx.currentTime;
            const throttle = CFG.AUDIO.THROTTLE[type] ?? CFG.AUDIO.THROTTLE.DEFAULT;
            if (this.lastPlay[type] && now - this.lastPlay[type] < throttle) return;
            this.lastPlay[type] = now;

            const p = AUDIO_PROFS[type];
            if (!p) return;

            const gain = this.ctx.createGain();
            gain.connect(this.masterGain);
            const targetVol = (typeof p.v === 'function' ? p.v() : p.v) * volMult;

            if (p.noise) {
                const bufSize = this.ctx.sampleRate * p.d;
                const buffer = this.ctx.createBuffer(1, bufSize, this.ctx.sampleRate);
                const data = buffer.getChannelData(0);
                for (let i = 0; i < bufSize; i++) data[i] = FastMath.rand() * 2 - 1;

                const noise = this.ctx.createBufferSource();
                noise.buffer = buffer;
                const filter = this.ctx.createBiquadFilter();
                filter.type = p.fType;
                filter.frequency.setValueAtTime(typeof p.f0 === 'function' ? p.f0() : p.f0, now);
                if (p.f1) filter.frequency.exponentialRampToValueAtTime(p.f1, now + p.d);
                if (p.fQ) filter.Q.value = p.fQ;

                noise.connect(filter);
                filter.connect(gain);
                gain.gain.setValueAtTime(targetVol, now);
                gain.gain.exponentialRampToValueAtTime(0.01, now + p.d);

                if (p.oF0) {
                    const osc = this.ctx.createOscillator();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(p.oF0, now);
                    osc.frequency.exponentialRampToValueAtTime(p.oF1, now + Math.min(0.4, p.d));
                    osc.connect(gain);
                    osc.start(now);
                    osc.stop(now + Math.min(0.4, p.d));
                }
                noise.start(now);
                noise.stop(now + p.d);
                noise.onended = () => { filter.disconnect(); gain.disconnect(); };
            } else {
                const osc = this.ctx.createOscillator();
                osc.connect(gain);
                osc.type = p.t;
                const startFreq = typeof p.f0 === 'function' ? p.f0() : p.f0;
                osc.frequency.setValueAtTime(startFreq, now);

                if (p.seq) {
                    p.seq.forEach((f, i) => {
                        const freq = typeof f === 'function' ? f() : f;
                        osc.frequency.setValueAtTime(freq, now + ((i + 1) * 0.05));
                    });
                } else if (p.ramp === 'lin_exp' && p.f1 && p.f2) {
                    const midFreq = typeof p.f1 === 'function' ? p.f1(startFreq) : p.f1;
                    osc.frequency.linearRampToValueAtTime(midFreq, now + 0.1);
                    osc.frequency.exponentialRampToValueAtTime(p.f2, now + p.d);
                } else if (p.f1) {
                    if (p.ramp === 'lin') osc.frequency.linearRampToValueAtTime(p.f1, now + p.d);
                    else osc.frequency.exponentialRampToValueAtTime(p.f1, now + p.d);
                }

                gain.gain.setValueAtTime(p.ramp === 'lin_exp' || type === 'start' ? 0 : targetVol, now);
                if (p.ramp === 'lin_exp') gain.gain.linearRampToValueAtTime(targetVol, now + 0.05);
                if (type === 'start') gain.gain.linearRampToValueAtTime(targetVol, now + 0.1);
                gain.gain.exponentialRampToValueAtTime(0.01, now + p.d);

                if (type === 'laser') {
                    const osc2 = this.ctx.createOscillator();
                    osc2.type = 'square';
                    osc2.frequency.setValueAtTime(1000, now);
                    osc2.frequency.exponentialRampToValueAtTime(50, now + p.d);
                    osc2.connect(gain);
                    osc2.start(now);
                    osc2.stop(now + p.d);
                }
                osc.start(now);
                osc.stop(now + p.d);
                osc.onended = () => { gain.disconnect(); };
            }
        }
    };

    // ═══════════════════════════════════════════
    // VFX POOL
    // ═══════════════════════════════════════════
    class VFXPool {
        constructor(c) {
            this.c = c;
            this.phys = []; this.txts = []; this.lzs = []; this.sws = [];
            this.pIdx = 0; this.tIdx = 0; this.lIdx = 0; this.sIdx = 0;
            this._warnedMissing = new Set();

            for (let i = 0; i < CFG.VFX.PHYSICS_LIMIT; i++) {
                const s = new PIXI.Sprite();
                s.visible = s.active = false;
                s.anchor.set(0.5);
                this.c.addChild(s);
                this.phys.push(s);
            }
            for (let i = 0; i < CFG.VFX.TEXT_LIMIT; i++) {
                const cnt = new PIXI.Container();
                cnt.visible = cnt.active = false;
                for (let j = 0; j < 4; j++) {
                    const d = new PIXI.Sprite();
                    d.x = j * 10;
                    cnt.addChild(d);
                }
                this.c.addChild(cnt);
                this.txts.push(cnt);
            }
            for (let i = 0; i < 15; i++) {
                const lz = new PIXI.Graphics();
                lz.visible = lz.active = false;
                this.c.addChild(lz);
                this.lzs.push(lz);
            }
            for (let i = 0; i < 20; i++) {
                const sw = new PIXI.Sprite(MD.Textures['fx_ring']);
                sw.anchor.set(0.5);
                sw.visible = sw.active = false;
                this.c.addChild(sw);
                this.sws.push(sw);
            }
        }

        _warnOnce(key, msg) {
            if (this._warnedMissing.has(key)) return;
            this._warnedMissing.add(key);
            console.warn(`[VFXPool] ${msg}`);
        }

        spawnPhysics(t, pX, pY, vx, vy, l, dragX = CFG.PHYSICS.DRAG_X, dragY = CFG.PHYSICS.DRAG_Y, scaleDecay = false) {
            const tex = MD.Textures[t];
            if (!tex) { this._warnOnce(t, `Missing texture "${t}" — spawn skipped.`); return null; }
            if (l <= 0) { this._warnOnce('l<=0:' + t, `Invalid life=${l}`); return null; }

            this.pIdx = (this.pIdx + 1) % this.phys.length;
            const s = this.phys[this.pIdx];
            s.texture = tex;
            s.x = pX; s.y = pY; s.vx = vx; s.vy = vy;
            s.life = s.maxL = l;
            s.dragX = dragX; s.dragY = dragY;
            s.scaleDecay = scaleDecay;
            s.active = s.visible = true;
            s.alpha = 1;
            s.scale.set(1);
            s.rotation = FastMath.randRange(0, 6);
            return s;
        }

        spawnShockwave(pX, pY, color, maxRad = 80, width = 4) {
            if (maxRad <= 0) { this._warnOnce('sw:rad', `Invalid maxRad=${maxRad}`); return; }
            this.sIdx = (this.sIdx + 1) % this.sws.length;
            const sw = this.sws[this.sIdx];
            sw.x = pX; sw.y = pY;
            sw.tint = color;
            sw.radius = 0.1;
            sw.maxRadius = maxRad / 60;
            sw.life = sw.maxL = 20;
            sw.active = sw.visible = true;
            sw.alpha = 1;
            sw.scale.set(0.1);
        }

        spawnLaser(sx, sy, ex, ey, color, width, dur, jagged = false) {
            if (dur <= 0) { this._warnOnce('lz:dur', `Invalid dur=${dur}`); return; }
            this.lIdx = (this.lIdx + 1) % this.lzs.length;
            const z = this.lzs[this.lIdx];
            z.sx = sx; z.sy = sy; z.ex = ex; z.ey = ey;
            z.color = color; z.w = width;
            z.life = z.maxL = dur;
            z.active = z.visible = true;
            z.alpha = 1;
            z.jagged = jagged;
        }

        spawnDmgText(pX, pY, dmg, color = 0xff0000) {
            if (!isFinite(dmg)) return;
            this.tIdx = (this.tIdx + 1) % this.txts.length;
            const t = this.txts[this.tIdx];
            const str = Math.floor(dmg).toString();
            t.children[0].texture = MD.Textures['digit_minus'];
            t.children[0].tint = color;
            t.children[0].visible = true;
            for (let j = 1; j < 4; j++) {
                if (j - 1 < str.length) {
                    t.children[j].texture = MD.Textures['digit_' + str[j - 1]];
                    t.children[j].tint = color;
                    t.children[j].visible = true;
                } else {
                    t.children[j].visible = false;
                }
            }
            t.x = pX + FastMath.randRange(-6, 6);
            t.y = pY + FastMath.randRange(-2, 2);
            t.vx = FastMath.randRange(-1.5, 1.5);
            t.vy = FastMath.randRange(-4, -2);
            t.life = t.maxL = CFG.VFX.TEXT_LIFE;
            t.active = t.visible = true;
            t.alpha = 1;
            t.scale.set(0.5);
        }

        update(camY, timeScale = 1.0) {
            const pDragX = Math.pow(CFG.PHYSICS.DRAG_X, timeScale);
            const pDragY = Math.pow(CFG.PHYSICS.DRAG_Y, timeScale);

            for (let i = 0, len = this.phys.length; i < len; i++) {
                const s = this.phys[i];
                if (!s.active) continue;
                s.life -= timeScale;
                if (s.life <= 0) { s.active = s.visible = false; continue; }
                s.vy += 0.5 * timeScale;
                s.vx *= (s.dragX === CFG.PHYSICS.DRAG_X ? pDragX : Math.pow(s.dragX, timeScale));
                s.vy *= (s.dragY === CFG.PHYSICS.DRAG_Y ? pDragY : Math.pow(s.dragY, timeScale));
                s.x += s.vx * timeScale;
                s.y += s.vy * timeScale;
                s.rotation += s.vx * 0.1 * timeScale;
                s.alpha = s.life / s.maxL < 0.1 ? 0.1 : s.life / s.maxL;
                if (s.scaleDecay) s.scale.set(s.life / s.maxL);
            }
            for (let i = 0, len = this.sws.length; i < len; i++) {
                const s = this.sws[i];
                if (!s.active) continue;
                s.life -= timeScale;
                if (s.life <= 0) { s.active = s.visible = false; continue; }
                s.radius += (s.maxRadius - s.radius) * 0.2 * timeScale;
                s.scale.set(s.radius);
                s.alpha = s.life / s.maxL;
            }
            for (let i = 0, len = this.lzs.length; i < len; i++) {
                const z = this.lzs[i];
                if (!z.active) continue;
                z.life -= timeScale;
                if (z.life <= 0) { z.active = z.visible = false; continue; }
                z.clear().lineStyle(z.w, z.color, z.life / z.maxL);
                z.moveTo(z.sx, z.sy);
                for (let j = 1; j <= 4; j++) {
                    let tx = z.sx + (z.ex - z.sx) * (j / 4);
                    let ty = z.sy + (z.ey - z.sy) * (j / 4);
                    if (z.jagged) {
                        tx += FastMath.randRange(-15, 15);
                        ty += FastMath.randRange(-5, 5);
                    }
                    if (j === 4) { tx = z.ex; ty = z.ey; }
                    z.lineTo(tx, ty);
                }
            }
            for (let i = 0, len = this.txts.length; i < len; i++) {
                const t = this.txts[i];
                if (!t.active) continue;
                t.life -= timeScale;
                if (t.life <= 0) { t.active = t.visible = false; continue; }
                t.vy += 0.4 * timeScale;
                t.vx *= pDragX;
                t.vy *= pDragX;
                t.x += t.vx * timeScale;
                t.y += t.vy * timeScale;
                t.alpha = t.life < 10 ? t.life / 10 : 1;
                t.scale.set(0.5 + FastMath.sin((1 - (t.life / t.maxL)) * Math.PI) * 0.5);
            }
        }
    }

    // ═══════════════════════════════════════════
    // SPARSE SET — generic active-only iteration
    // ═══════════════════════════════════════════
    // Array dengan swap-remove O(1). Iterasi hanya active items.
    // Cocok untuk entity pool (1000 slot, mayoritas inactive).
    class SparseSet {
        constructor(capacity = 0) {
            this.items = [];
            this._indices = new Map();  // item → index (untuk O(1) removal)
            this.capacity = capacity;
        }
        add(item) {
            if (this._indices.has(item)) return false;
            this._indices.set(item, this.items.length);
            this.items.push(item);
            return true;
        }
        remove(item) {
            const idx = this._indices.get(item);
            if (idx === undefined) return false;
            const last = this.items[this.items.length - 1];
            this.items[idx] = last;
            this._indices.set(last, idx);
            this.items.pop();
            this._indices.delete(item);
            return true;
        }
        has(item) { return this._indices.has(item); }
        get size() { return this.items.length; }
        clear() { this.items.length = 0; this._indices.clear(); }
        [Symbol.iterator]() { return this.items[Symbol.iterator](); }
    }

    // ═══════════════════════════════════════════
    // ATTACH
    // ═══════════════════════════════════════════
    MD.MinitLoader = MinitLoader;
    MD.AudioSys = AudioSys;
    // MD.FastMath sudah di-attach di atas
    MD.VFXPool = VFXPool;
    MD.SparseSet = SparseSet;
})();