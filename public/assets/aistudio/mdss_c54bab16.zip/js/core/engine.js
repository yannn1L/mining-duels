// ==========================================
// ENGINE — PIXI bootstrap + Orientation
// ==========================================
(function() {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG || !MD.UI_STYLE) throw new Error('[engine.js] deps not met');
    
    const { CFG, PALETTE } = MD;
    PIXI.settings.SCALE_MODE = PIXI.SCALE_MODES.NEAREST;
    PIXI.settings.ROUND_PIXELS = true;
    
    const app = new PIXI.Application({
        view: document.getElementById('gameCanvas'),
        resizeTo: window,
        backgroundColor: CFG.APP.BG_COLOR,
        resolution: window.devicePixelRatio || 1
    });
    MD.app = app;
    
    const bgContainer = new PIXI.Container();
    const gameContainer = new PIXI.Container();
    app.stage.addChild(bgContainer, gameContainer);
    MD.bgContainer = bgContainer;
    MD.gameContainer = gameContainer;
    
    // ═══ Orientation ═══
    MD.Orientation = {
        current: 'landscape',
        _mq: null,
        init() {
            if (!window.matchMedia) {
                this.current = window.innerWidth >= window.innerHeight ? 'landscape' : 'portrait';
                return;
            }
            this._mq = window.matchMedia('(orientation: portrait)');
            this._apply(this._mq);
            this._onChange = (e) => this._apply(e);
            this._mq.addEventListener('change', this._onChange);
        },
        _apply(e) {
            const next = e.matches ? 'portrait' : 'landscape';
            if (next !== this.current) {
                this.current = next;
                console.log(`[Orientation] → ${next}`);
            }
        },
        getLayout(playerCount = 2) {
            const orient = CFG.LAYOUT[this.current];
            if (!orient || !orient[playerCount]) {
                console.warn(`[Orientation] Missing LAYOUT.${this.current}[${playerCount}]`);
                return CFG.LAYOUT.landscape[playerCount];
            }
            return orient[playerCount];
        }
    };
    
    // ═══ CRT Shader ═══
    const crtFrag = `precision mediump float; varying vec2 vTextureCoord; uniform sampler2D uSampler; uniform float time; uniform float uAberration; uniform float uScanline; uniform float uVignette; uniform float uBrightness; void main() { vec2 uv = vTextureCoord; float r = texture2D(uSampler, vec2(uv.x + uAberration, uv.y)).r; float g = texture2D(uSampler, uv).g; float b = texture2D(uSampler, vec2(uv.x - uAberration, uv.y)).b; vec3 color = vec3(r, g, b); color -= sin(uv.y * 1000.0 + time * 10.0) * uScanline; vec2 crv = uv - 0.5; float rsq = crv.x*crv.x + crv.y*crv.y; color *= 1.0 - (rsq * uVignette); gl_FragColor = vec4(color * uBrightness, 1.0); }`;
    const crtFilter = new PIXI.Filter(null, crtFrag, {
        time: 0,
        uAberration: CFG.SHADER.aberration,
        uScanline: CFG.SHADER.scanline,
        uVignette: CFG.SHADER.vignette,
        uBrightness: CFG.SHADER.brightness
    });
    MD.crtFilter = crtFilter;
    app.stage.filters = [crtFilter];
    app.ticker.add((d) => crtFilter.uniforms.time += 0.01 * d);
    
    // ═══ Global background ═══
    const globalBg = new PIXI.TilingSprite(PIXI.Texture.EMPTY, window.innerWidth, window.innerHeight);
    globalBg.alpha = 0.5;
    bgContainer.addChild(globalBg);
    MD.globalBg = globalBg;
    MD.bgFloaters = [];
    
    // ═══ Resize ═══
    window.addEventListener('resize', () => {
        app.renderer.resize(window.innerWidth, window.innerHeight);
        if (globalBg.texture !== PIXI.Texture.EMPTY) {
            globalBg.width = window.innerWidth;
            globalBg.height = window.innerHeight;
        }
        const scale = Math.min(window.innerWidth / CFG.APP.W, window.innerHeight / CFG.APP.H);
        gameContainer.scale.set(scale);
        gameContainer.x = (window.innerWidth - CFG.APP.W * scale) / 2;
        gameContainer.y = (window.innerHeight - CFG.APP.H * scale) / 2;
    });
})();