// ==========================================
// NAMESPACE — Central MD object
// ==========================================
// Semua module attach ke window.MD.
// Tidak ada global lain di-expose.
//
// Load order (dependency-based):
//   namespace → config → styles → sfx → effects
//   → utils → traits → behaviors → effect-system
//   → minit-slot → arena → engine → asset-baker → scenes
// ==========================================

(function() {
  'use strict';
  
  if (window.MD) {
    console.warn('[Namespace] MD already exists, reusing.');
    return;
  }
  
  window.MD = Object.create(null);
  
  // ---------- Runtime assertion helper ----------
  // Dipakai di critical paths untuk type safety runtime.
  MD.assert = function(cond, msg) {
    if (!cond) {
      console.error('[MD.assert]', msg);
      throw new Error(msg);
    }
  };
})();