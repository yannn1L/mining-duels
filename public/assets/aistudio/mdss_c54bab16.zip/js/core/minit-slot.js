// ==========================================
// MINIT SLOT — Encapsulates 1 minit
// ==========================================
// Slot punya:
//   - log (posisi, timer)
//   - spr (PIXI sprite)
//   - state (user state untuk minit)
//   - stats (d/maxDp)
//   - modifiers (speedMul, dmgMul, blind, shieldCharges)
//   - effects (array EffectInstance)
//   - customTraits (array string trait name) — dari inventory
//   - customEffects (array { id, magnitude, duration }) — dari inventory
//   - displayScale (untuk mode manager)
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG || !MD.EffectManager) throw new Error('[minit-slot.js] deps not met');

    const { CFG } = MD;

    MD.MinitSlot = class MinitSlot {
        constructor(minitId, arena, slotIndex, minitData, options = {}) {
            this.id = minitId;
            this.md = minitData || MD.MINIT_DB[minitId];
            MD.assert(this.md, `[MinitSlot] Unknown minit: ${minitId}`);
            this.arena = arena;
            this.slotIndex = slotIndex;

            // ── Custom traits/effects dari inventory ──
            this.customTraits = [];       // string trait names
            this.customBehaviors = [];    // string behavior names (dipakai minit sendiri, tidak auto-merge)
            this.customEffects = [];      // { id } — permanent effects applied via addEffect

            // ── Starting X: bagi rata kalau multi-slot ──
            const slotCount = arena.minitIds ? arena.minitIds.length : 1;
            const cols = arena.cols ?? CFG.GRID.COLS;
            const margin = 3;
            const usableWidth = cols - margin * 2;
            const slotWidth = Math.max(1, Math.floor(usableWidth / slotCount));
            const slotCenter = margin + slotIndex * slotWidth + (slotWidth >> 1);
            const startX = Math.max(0, Math.min(cols - 1, slotCenter));

            this.log = { x: startX, y: 0, t: 0 };

            // ── Visual ──
            const createSprite = options.createSprite || ((texName) => {
                const s = new PIXI.Sprite(MD.Textures[texName]);
                s.anchor.set(0.5);
                return s;
            });
            this.spr = createSprite(`minit_${minitId}_base`);
            const p = arena.getPixelCoords(this.log.x, this.log.y);
            this.spr.x = p.px;
            this.spr.y = p.py;
            if (arena.layer && arena.layer.addChild) arena.layer.addChild(this.spr);

            this.animScale = { x: 1, y: 1, tX: 1, tY: 1 };
            this.baseScale = 1.0;

            // ── Display scale (untuk mode manager) ──
            // Default 1.0 = normal (sprite dimasukkan apa adanya).
            // Di manager bisa di-set 0.9 untuk minit lebih kecil.
            this.displayScale = options.minitScale ?? 1.0;

            // Apply initial scale
            if (this.spr && this.spr.scale) {
                const s = this.displayScale * this.baseScale;
                this.spr.scale.set(s, s);
            }

            // ── State ──
            this.state = { wasFalling: false, arena, slot: this };

            // ── Stats ──
            this.stats = { d: 0, maxDp: 0};

            // ── Modifiers ──
            this.modifiers = {
                speedMul: 1.0,
                dmgMul: 1.0,
                blind: false,
                shieldCharges: 0
            };

            // ── Effects ──
            this.effects = [];

            // ── Error tracking ──
            this.errorCount = 0;
            this.disabled = false;
            this.active = true;

            // ── Effects UI ──
            const createUI = options.createEffectsUI || (() => {
                const c = new PIXI.Container();
                c.position.set(p.px, p.py - 26 * this.displayScale);
                return c;
            });
            this.effectsUI = createUI();
            if (arena.layer && arena.layer.addChild) arena.layer.addChild(this.effectsUI);

            // ── Call onInit ──
            if (this.md.onInit) {
                try { this.md.onInit(this.state, arena, this); }
                catch (e) { console.error(`[MinitSlot:${minitId}] onInit:`, e); }
            }
        }

        // ═══════════════════════════════════════════
        // MOVEMENT
        // ═══════════════════════════════════════════
        isFalling() {
            return this.arena.getHP(this.log.x, this.log.y + 1) === 0
                && this.log.y < this.arena.maxDepth - 1;
        }

        moveStep() {
            const ml = this.log, md = this.md;
            if (this.isFalling()) {
                ml.y++;
                this.animScale.tY = 1.3;
                this.animScale.tX = 0.7;
                this.state.wasFalling = true;
            } else {
                if (this.state.wasFalling) {
                    this.animScale.tY = 0.7;
                    this.animScale.tX = 1.3;
                    this.state.wasFalling = false;
                }
                if (MD.FastMath.rand() < md.roam * this.modifiers.speedMul) {
                    const dir = MD.FastMath.rand() > 0.5 ? 1 : -1;
                    const cols = this.arena.cols ?? CFG.GRID.COLS;
                    if (ml.x + dir >= 0 && ml.x + dir < cols
                        && this.arena.getHP(ml.x + dir, ml.y) === 0) ml.x += dir;
                }
            }
        }

        // ═══════════════════════════════════════════
        // TICK
        // ═══════════════════════════════════════════
        tick() {
            if (this.disabled) return;
            try { this._tickInternal(); }
            catch (e) {
                this.errorCount++;
                console.error(`[MinitSlot:${this.id}] tick error (${this.errorCount}):`, e);
                if (this.errorCount >= 3) {
                    this.disabled = true;
                    console.warn(`[MinitSlot:${this.id}] Disabled after 3 errors`);
                }
            }
        }

        _tickInternal() {
            const ml = this.log, md = this.md, a = this.arena;

            this.moveStep();

            const effectiveCd = Math.max(1, Math.floor(md.cd / this.modifiers.speedMul));
            ml.t++;
            if (ml.t >= effectiveCd) {
                ml.t = 0;
                this.animScale.tX = 1.3;
                this.animScale.tY = 0.7;
                if (md.onTrigger) md.onTrigger(this.state, a, this);
            }

            if (md.onUpdate) md.onUpdate(this.state, a, this.spr, this);

            MD.EffectManager.tick(this);

            this.stats.maxDp = Math.max(this.stats.maxDp, ml.y);

            this._updateEffectsUI();
        }

        // ═══════════════════════════════════════════
        // EFFECTS API
        // ═══════════════════════════════════════════
        addEffect(id, opts) { return MD.EffectManager.apply(this, id, opts || {}); }
        removeEffect(id) { return MD.EffectManager.remove(this, id); }
        hasEffect(id) { return MD.EffectManager.has(this, id); }
        getEffect(id) { return MD.EffectManager.get(this, id); }
        clearEffects() { MD.EffectManager.clear(this); }

        // ═══════════════════════════════════════════
        // EFFECTS UI — icon + timer bar
        // ═══════════════════════════════════════════
        _updateEffectsUI() {
            const ui = this.effectsUI;
            if (!ui || !ui.removeChildren) return;
            const a = this.arena;
            const p = a.getPixelCoords(this.log.x, this.log.y);
            ui.position.set(p.px, p.py - 26 * this.displayScale);

            if (ui._effectCount !== this.effects.length) {
                ui.removeChildren();
                for (const eff of this.effects) {
                    const icon = new PIXI.Graphics();
                    icon.beginFill(eff.color, 0.9).drawRect(-4, -4, 8, 8).endFill();
                    icon.beginFill(0x000000, 0.5).drawRect(-4, 4, 8, 2).endFill();
                    ui.addChild(icon);
                    eff._uiIcon = icon;
                }
                const spacing = 12;
                const startX = -((this.effects.length - 1) * spacing) / 2;
                this.effects.forEach((eff, i) => {
                    if (eff._uiIcon) eff._uiIcon.x = startX + i * spacing;
                });
                ui._effectCount = this.effects.length;
            }

            for (const eff of this.effects) {
                const icon = eff._uiIcon;
                if (!icon || !icon.clear) continue;
                const pct = eff.duration / eff.def.defaultDur;
                icon.clear();
                icon.beginFill(eff.color, 0.9).drawRect(-4, -4, 8, 8).endFill();
                icon.beginFill(0x000000, 0.5).drawRect(-4, 4, 8, 2).endFill();
                icon.beginFill(eff.color, 1).drawRect(-4, 4, 8 * Math.min(1, pct), 2).endFill();
            }
        }

        // ═══════════════════════════════════════════
        // VISUAL UPDATE
        // ═══════════════════════════════════════════
        updateVisuals(timeScale) {
            const p = this.arena.getPixelCoords(this.log.x, this.log.y);
            const spr = this.spr;
            if (!spr) return;

            spr.x += (p.px - spr.x) * CFG.RENDER.LERP * timeScale;
            spr.y += (p.py - spr.y) * CFG.RENDER.LERP * timeScale;

            this.animScale.tX += (1.0 - this.animScale.tX) * CFG.RENDER.SPRING_TENSION * timeScale;
            this.animScale.tY += (1.0 - this.animScale.tY) * CFG.RENDER.SPRING_TENSION * timeScale;

            // Target = spring scale × baseScale × displayScale
            const targetX = this.animScale.tX * this.baseScale * this.displayScale;
            const targetY = this.animScale.tY * this.baseScale * this.displayScale;
            this.animScale.x += (targetX - this.animScale.x) * CFG.RENDER.SPRING_DAMP * timeScale;
            this.animScale.y += (targetY - this.animScale.y) * CFG.RENDER.SPRING_DAMP * timeScale;
            spr.scale.set(this.animScale.x, this.animScale.y);

            if (this.effectsUI) {
                this.effectsUI.position.set(spr.x, spr.y - 26 * this.displayScale);
            }
        }

        // ═══════════════════════════════════════════
        // CLEANUP
        // ═══════════════════════════════════════════
        destroy() {
            MD.EffectManager.clear(this);
            if (this.spr && this.spr.parent) this.spr.parent.removeChild(this.spr);
            if (this.effectsUI && this.effectsUI.parent) this.effectsUI.parent.removeChild(this.effectsUI);
            if (this.spr && this.spr.destroy) this.spr.destroy();
            if (this.effectsUI && this.effectsUI.destroy) this.effectsUI.destroy({ children: true });
        }
    };
})();