// ==========================================
// CONFIG — pure data (no runtime deps)
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[config.js] namespace.js not loaded');

    const CFG = {
        APP: { W: 800, H: 600, BG_COLOR: 0x050508 },
        GRID: { TS: 16, HALF_TS: 8, COLS: 15, ROWS: 20, MAX_DEPTH: 999 },
        RENDER: { LERP: 0.15, CAM_LERP: 0.1, SPRING_TENSION: 0.15, SPRING_DAMP: 0.3 },
        ARENA: { BASE_HP: 10, HP_SCALING: 3 },
        SIM: {
            DUR: 20.0, MULT: 0.50, OVERTIME_HITS: 5,
            SLOWMO_SPEED: 0.15, SLOWMO_DUR: 120,
            MAX_DT: 2.0, MAX_ITERATIONS: 3,
            VFX_LOD: { 2: 1.0 }
        },
        SHADER: { aberration: 0.001, scanline: 0.01, vignette: 0, brightness: 1.1 },
        PHYSICS: { DRAG_X: 0.9, DRAG_Y: 0.95 },
        VECTORS: { DOWN: [[0, 1]], SPREAD: [[0, -1], [1, 0], [-1, 0]] },
        UI: {
            CARD: { W: 240, H: 110, SCALE: 0.68, GAP_X: 15, GAP_Y: 15, COLS: 4, START_Y: 120 },
            SCROLL: { Y: 110, H: 350 }
        },
        
        LAYOUT: {
            landscape: {
                2: {
                    title: { x: 400, y: 3 },
                    timer: { x: 400, y: 24, size: 20 },
                    slots: [
                        { x: 210, y: 310, scale: 1.17 },
                        { x: 590, y: 310, scale: 1.17 }
                    ]
                }
            },
            portrait: {
                2: {
                    title: { x: 400, y: -85 },
                    timer: { x: 400, y: -52, size: 20 },
                    slots: [
                        { x: 200, y: 330, scale: 1.6 },
                        { x: 600, y: 330, scale: 1.6 }
                    ]
                }
            },
            menu: {
                landscape: {
                    title: { x: 400, y: 120, scale: 1.0 },
                    subtitle: { x: 400, y: 172 },
                    buttons: {
                        x: 400,
                        startY: 250,
                        gap: 70,
                        width: 280,
                        height: 50
                    },
                    footer: { x: 400, y: 570 }
                },
                portrait: {
                    title: { x: 400, y: 130, scale: 0.95 },
                    subtitle: { x: 400, y: 178 },
                    buttons: {
                        x: 400,
                        startY: 250,
                        gap: 68,
                        width: 300,
                        height: 52
                    },
                    footer: { x: 400, y: 570 }
                }
            }
            
        },
        AUDIO: {
            MASTER_GAIN: 0.8,
            COMPRESSOR: { THRESHOLD: -12, RATIO: 4 },
            THROTTLE: {
                hit: 0.05, laser: 0.08, crush: 0.06, gun: 0.04,
                swarm: 0.1, DEFAULT: 0.04
            }
        },
        VFX: {
            TEXT_LIMIT: 60, PHYSICS_LIMIT: 800,
            TEXT_LIFE: 30, TEXT_COOLDOWN: 15
        }
    };

    const PALETTE = {
        ROCKS: [0x222222, 0x3d4045, 0x544738, 0x6e3636, 0x5e236e],
        TEXT: '#ffffff', NEON: '#00ccff', ALERT: '#ff0055', MUTED: '#aaaaaa',
        CARD_BG: 0x0a0a0f, BORDER: 0x2a2a3a
    };

    MD.CFG = CFG;
    MD.PALETTE = PALETTE;
})();