// ==========================================
// MINIT MANAGER — LOOTBOX + CRAFTING
// ==========================================
// Lootbox: bisa drop MINIT atau RESOURCE.
// Crafting: deterministic unlock.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-lootbox] deps not met');
    if (!MD.MM || !MD.MM.Config || !MD.MM.Registry) throw new Error('[mm-lootbox] deps not met');

    const { Config, Registry } = MD.MM;

    // ═══════════════════════════════════════════
    // LOOTBOX SYSTEM
    // ═══════════════════════════════════════════
    const LootboxSystem = {
        /**
         * Roll lootbox. Return:
         *   { type: 'minit', minitId, rarity }
         *   { type: 'resource', resourceId, amount, rarity }
         *   null (kalau tidak ada yang bisa di-drop)
         */
        roll(progress) {
            const pools = Registry.LOOTBOX_POOLS;

            // Available minits (belum unlock)
            const availMinits = {
                common: pools.common.filter(id => !progress.unlockedMinits.includes(id)),
                rare: pools.rare.filter(id => !progress.unlockedMinits.includes(id)),
                legendary: pools.legendary.filter(id => !progress.unlockedMinits.includes(id))
            };
            const totalAvailMinits =
                availMinits.common.length + availMinits.rare.length + availMinits.legendary.length;

            // Pity counter
            progress.lootbox.pityCounter = (progress.lootbox.pityCounter || 0) + 1;
            const pityActive = progress.lootbox.pityCounter >= Config.LOOTBOX.PITY_THRESHOLD;

            // Roll category
            let category;
            if (totalAvailMinits === 0) {
                category = 'resource';
            } else {
                const roll = Math.random();
                category = roll < Config.LOOTBOX.CATEGORY_WEIGHTS.minit ? 'minit' : 'resource';
            }

            if (category === 'minit') {
                return this._rollMinit(progress, availMinits, pityActive);
            }
            return this._rollResource(progress, pityActive);
        },

        _rollMinit(progress, availMinits, pityActive) {
            let rarityRoll;
            if (pityActive && (availMinits.rare.length > 0 || availMinits.legendary.length > 0)) {
                rarityRoll = 'rare';
            } else {
                rarityRoll = this._weightedRoll(Config.LOOTBOX.RARITY_WEIGHTS);
            }

            let pool = availMinits[rarityRoll];
            if (!pool || pool.length === 0) {
                if (availMinits.common.length > 0) { pool = availMinits.common; rarityRoll = 'common'; }
                else if (availMinits.rare.length > 0) { pool = availMinits.rare; rarityRoll = 'rare'; }
                else if (availMinits.legendary.length > 0) { pool = availMinits.legendary; rarityRoll = 'legendary'; }
                else return this._rollResource(progress, pityActive);
            }

            const minitId = pool[(Math.random() * pool.length) | 0];
            if (rarityRoll !== 'common') progress.lootbox.pityCounter = 0;
            return { type: 'minit', minitId, rarity: rarityRoll };
        },

        _rollResource(progress, pityActive) {
            let rarityRoll;
            if (pityActive) {
                rarityRoll = 'rare';
            } else {
                rarityRoll = this._weightedRoll(Config.LOOTBOX.RARITY_WEIGHTS);
            }

            const pools = Config.LOOTBOX.RESOURCE_POOLS;
            let pool = pools[rarityRoll];
            if (!pool || pool.length === 0) {
                pool = pools.common;
                rarityRoll = 'common';
            }

            const pick = pool[(Math.random() * pool.length) | 0];
            const range = pick.amount;
            const amount = Math.floor(range[0] + Math.random() * (range[1] - range[0] + 1));

            if (rarityRoll !== 'common') progress.lootbox.pityCounter = 0;
            return { type: 'resource', resourceId: pick.id, amount, rarity: rarityRoll };
        },

        _weightedRoll(weights) {
            const r = Math.random();
            let acc = 0;
            for (const k of Object.keys(weights)) {
                acc += weights[k];
                if (r <= acc) return k;
            }
            return 'common';
        },

        getCost() {
            return { ...Config.LOOTBOX.COST };
        },

        /**
         * Open lootbox: spend cost, roll, apply result.
         * Return result object atau null (gagal).
         */
        open(progress, ProgressOps) {
            const cost = this.getCost();
            if (!ProgressOps.canAfford(progress, cost)) return null;
            ProgressOps.spend(progress, cost);

            const result = this.roll(progress);
            if (!result) return null;

            if (result.type === 'minit') {
                ProgressOps.unlockMinit(progress, result.minitId);
            } else if (result.type === 'resource') {
                const grant = Registry.ResourceRegistry.grant(progress, result.resourceId, result.amount);
                result.discovered = grant.discovered;
            }

            progress.markDirty();
            return result;
        }
    };

    // ═══════════════════════════════════════════
    // CRAFTING SYSTEM
    // ═══════════════════════════════════════════
    const CraftingSystem = {
        getCraftCost(minitId) {
            const reg = Registry.MINIT_UNLOCK_REGISTRY[minitId];
            if (!reg || reg.method !== 'crafting') return null;
            return reg.cost;
        },

        getCraftable(progress) {
            const out = [];
            for (const minitId of Object.keys(Registry.MINIT_UNLOCK_REGISTRY)) {
                const reg = Registry.MINIT_UNLOCK_REGISTRY[minitId];
                if (reg.method !== 'crafting') continue;
                if (progress.unlockedMinits.includes(minitId)) continue;
                out.push({ minitId, cost: reg.cost });
            }
            return out;
        },

        craft(progress, minitId, ProgressOps) {
            const cost = this.getCraftCost(minitId);
            if (!cost) return false;
            if (!ProgressOps.canAfford(progress, cost)) return false;
            if (progress.unlockedMinits.includes(minitId)) return false;
            ProgressOps.spend(progress, cost);
            ProgressOps.unlockMinit(progress, minitId);
            return true;
        }
    };

    MD.MM.LootboxSystem = LootboxSystem;
    MD.MM.CraftingSystem = CraftingSystem;
})();