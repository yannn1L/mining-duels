// ==========================================
// MINIT MANAGER — CONFIG
// ==========================================
// Pure data. Zero logic. Zero side effects.
// Semua magic number untuk layout ada di sini.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-config] namespace.js not loaded');

    const { CFG } = MD;

    // ═══════════════════════════════════════════
    // LAYOUT — per orientasi
    // ═══════════════════════════════════════════
    const LAYOUT = {
        landscape: {
            veinScale: 1.1,
            minitScale: 0.9,
            title: { x: 400, y: 8 },
            timer: { x: 400, y: 36, w: 400, h: 6 },
            vein: { x: 400, y: 150, anchor: 'topcenter' },
            resource: { x: 12, y: 80 },
            bottomBar: { y: 524 }
        },
        portrait: {
            veinScale: 1.3,
            minitScale: 0.9,
            title: { x: 400, y: 8 },
            timer: { x: 400, y: 36, w: 400, h: 6 },
            vein: { x: 400, y: 90, anchor: 'topcenter' },
            resource: { x: 12, y: 90 },
            bottomBar: { y: 524 }
        }
    };

    // ═══════════════════════════════════════════
    // LAYOUT_CONST — semua magic number UI
    // ═══════════════════════════════════════════
    const LAYOUT_CONST = {
        PAD: 8,
        RIGHT_PANEL: {
            X_OFFSET: 150,
            Y_START: 80,
            BTN_W: 40,
            BTN_H: 40,
            BTN_GAP: 20,
            LABEL_GAP: 3
        },
        LEFT_PANEL: {
            X: 12,
            Y: 80,
            TITLE_Y: 0,
            ROW_START: 30,
            ROW_H: 40,
            ICON_SCALE: 0.7,
            LABEL_X: 22,
            LABEL_GAP: 2,
            VALUE_Y_OFF: 13,
            MAX_PRIMARY: 6
        },
        BOTTOM_BAR: {
            Y: 524,
            SQUAD_Y: 20,
            SLOT_W: 44,
            SLOT_H: 44,
            SLOT_GAP: 8,
            SLOT_NUM_OFF: 3
        },
        MODAL: {
            BACKDROP_ALPHA: 0.85,
            PADDING: 20,
            TITLE_Y: 16,
            TITLE_OFF_Y: 26,
            CLOSE_BTN_W: 100,
            CLOSE_BTN_H: 28,
            CLOSE_BTN_BOTTOM: 36
        },
        MODAL_UPGRADE: {
            W: 640, H: 480,
            TAB_W: 100, TAB_H: 26, TAB_GAP: 6, TAB_Y: 50,
            TAB_SCROLL_MAX: 6,
            STAT_ROW_H: 22,
            STAT_FIELD_MAX: 6,
            STATS_Y: 100,
            TREE_Y_GAP: 20,
            BRANCH_W: 180,
            BRANCH_H: 40,
            TIER_START_Y: 24,
            TIER_H: 40,
            UNLOCK_BTN_H: 14
        },
        MODAL_SQUAD: {
            W: 720, H: 520,
            SLOT_PREVIEW_Y: 60,
            SLOT_PREVIEW_W: 100,
            SLOT_PREVIEW_H: 80,
            SLOT_PREVIEW_GAP: 10,
            LIST_Y: 170,
            ROW_W: 220,
            ROW_H: 96,
            ROW_GAP: 12,
            COLS: 3,
            ICON_X: 32,
            TEXT_X: 60,
            STAR_Y_OFF: 60,
            BTN_W: 90,
            BTN_H: 26,
            UPGRADE_SLOT_BTN_W: 130,
            UPGRADE_SLOT_BTN_H: 28,
            UPGRADE_SLOT_BTN_PAD: 20
        },
        MODAL_ACHIEVEMENT: {
            W: 560, H: 460,
            LIST_Y: 60,
            ROW_H: 58,
            PROGRESS_BAR_W: 160,
            PROGRESS_BAR_H: 8,
            ICON_X: 50,
            TEXT_X: 80,
            BAR_RIGHT_PAD: 30
        },
        MODAL_LOOTBOX: {
            W: 420, H: 340,
            INFO_Y: 70,
            BTN_W: 160, BTN_H: 44,
            BTN_Y: 170,
            RESULT_Y: 240
        },
        MODAL_CRAFT: {
            W: 520, H: 400,
            LIST_Y: 70,
            ROW_H: 60,
            ICON_X: 70,
            TEXT_X: 110,
            BTN_W_OFF: 120,
            BTN_Y_OFF: 15
        },
        TOAST: {
            QUEUE_MAX: 10,
            DURATION_MS: 2200,
            FADE_IN_MS: 200,
            FADE_OUT_MS: 400,
            Y_POSITION: 250,
            SPRITE_SIZE: 48,
            SLIDE_IN_OFFSET: 60,
            BG_W: 360,
            BG_H: 80,
            BG_X: -180,
            BG_Y: -40,
            TITLE_Y: -32,
            ICON_OFFSET_X: -100,
            TEXT_OFFSET_X: -70,
            TEXT_OFFSET_Y: 5
        },
        AREA_SELECT: {
            PREVIEW_SCALE: 0.85,
            PREVIEW_Y: 160,
            SWAP_BTN_SIZE: 44,
            SWAP_BTN_GAP: 16,
            NAME_OFF_Y: -34,
            DESC_OFF_Y: 14,
            PLAY_BTN_W: 180,
            PLAY_BTN_H: 48,
            PLAY_OFF_Y: 90
        },
        LOADING_OVERLAY: {
            TITLE_Y_OFF: -20,
            DOTS_Y_OFF: 20,
            DOT_INTERVAL: 20
        }
    };

    // ═══════════════════════════════════════════
    // VEIN
    // ═══════════════════════════════════════════
    const VEIN = {
        COLS: 30,
        ROWS: 30,
        TS: CFG.GRID.HALF_TS,
        MAX_DEPTH: 999
    };

    // ═══════════════════════════════════════════
    // RUN
    // ═══════════════════════════════════════════
    const RUN = {
        DEFAULT_DURATION_SEC: 120,
        TICK_RATE: 60
    };

    // ═══════════════════════════════════════════
    // SQUAD
    // ═══════════════════════════════════════════
    const SQUAD = {
        MAX_SIZE: 5,
        START_SIZE: 1
    };

    // ═══════════════════════════════════════════
    // PALETTE
    // ═══════════════════════════════════════════
    const PALETTE_MM = {
        PANEL_BG: 0x0a0a14,
        PANEL_BORDER: 0x2a2a3a,
        SLOT_BG: 0x111118,
        SLOT_ACTIVE: 0x00ccff,
        SLOT_IDLE: 0x2a2a3a,
        SLOT_IN_SQUAD: 0x1a3a5a,
        VEIN_BORDER: 0x555555,
        STAR_FILLED: 0xffcc44,
        STAR_EMPTY: 0x333344
    };

    // ═══════════════════════════════════════════
    // UPGRADE COSTS
    // ═══════════════════════════════════════════
    const STAT_UPGRADE_COSTS = [
        { gems: 200 },
        { gems: 500, parts: 20 },
        { gems: 1200, parts: 60, research: 5 },
        { gems: 3000, parts: 200, research: 20 },
        { gems: 8000, parts: 600, research: 60, cores: 3 }
    ];

    const TREE_UPGRADE_COSTS = [
        { gems: 300, parts: 100 },
        { gems: 1000, parts: 400, research: 20 },
        { gems: 3000, parts: 1200, research: 80, cores: 5 }
    ];

    // ═══════════════════════════════════════════
    // STAT INCREMENTS
    // ═══════════════════════════════════════════
    const STAT_INCREMENTS = {
        cd: { step: -2, min: 1 },
        dmg: { step: 5, min: 0 },
        baseDmg: { step: 5, min: 0 },
        length: { step: 1, min: 1 },
        duration: { step: 5, min: 5 },
        range: { step: 0.5, min: 0 },
        radius: { step: 0.5, min: 0 },
        life: { step: 5, min: 5 },
        hatchTime: { step: -30, min: 60 },
        shake: { step: 0.5, min: 0 },
        scaling: { step: 0.5, min: 0 },
        snapDmg: { step: 50, min: 100 },
        areaDmg: { step: 10, min: 0 },
        baseRange: { step: 0.5, min: 0 },
        maxTargets: { step: 3, min: 1 },
        snapRange: { step: 1, min: 1 },
        areaRange: { step: 0.5, min: 1 },
        rareChance: { step: 0.05, min: 0 }
    };

    // ═══════════════════════════════════════════
    // SLOT UNLOCK COSTS
    // ═══════════════════════════════════════════
    const SLOT_UNLOCK_COSTS = [
        null,
        { gems: 1000 },
        { gems: 5000, parts: 200 },
        { gems: 20000, parts: 1000, research: 20 },
        { gems: 100000, parts: 5000, research: 200, cores: 20 }
    ];

    // ═══════════════════════════════════════════
    // SAVE
    // ═══════════════════════════════════════════
    const SAVE = {
        DB_NAME: 'mining_duels_save',
        DB_VERSION: 1,
        STORE_NAME: 'progress',
        KEY: 'main',
        AUTOSAVE_DEBOUNCE_MS: 500,
        FALLBACK_LS_KEY: 'md_progress_v1'
    };

    // ═══════════════════════════════════════════
    // LOOTBOX
    // ═══════════════════════════════════════════
    const LOOTBOX = {
        PITY_THRESHOLD: 10,
        COST: { gems: 2000 },
        // Category weights (minit vs resource)
        CATEGORY_WEIGHTS: {
            minit: 0.20,
            resource: 0.80
        },
        // Rarity weights untuk roll
        RARITY_WEIGHTS: {
            common: 0.70,
            rare: 0.25,
            legendary: 0.05
        },
        // Resource pools by rarity
        RESOURCE_POOLS: {
            common: [
                { id: 'gems', amount: [500, 2000] },
                { id: 'parts', amount: [200, 800] }
            ],
            rare: [
                { id: 'research', amount: [100, 400] },
                { id: 'crystal_shard', amount: [30, 150] },
                { id: 'parts', amount: [1000, 3000] }
            ],
            legendary: [
                { id: 'cores', amount: [20, 80] },
                { id: 'magma_ember', amount: [10, 50] },
                { id: 'ancient_rune', amount: [5, 30] }
            ]
        }
    };

    // ═══════════════════════════════════════════
    // ROCK SHAPES
    // ═══════════════════════════════════════════
    const ROCK_SHAPES = ['solid', 'crystal', 'rusty', 'organic', 'metallic'];
    const RESOURCE_SHAPES = ['diamond', 'hex', 'star', 'circle', 'square', 'triangle'];

    // ═══════════════════════════════════════════
    // EXPORT
    // ═══════════════════════════════════════════
    MD.MM = MD.MM || {};
    MD.MM.Config = {
        LAYOUT,
        LAYOUT_CONST,
        VEIN,
        RUN,
        SQUAD,
        PALETTE: PALETTE_MM,
        STAT_UPGRADE_COSTS,
        TREE_UPGRADE_COSTS,
        STAT_INCREMENTS,
        SLOT_UNLOCK_COSTS,
        SAVE,
        LOOTBOX,
        ROCK_SHAPES,
        RESOURCE_SHAPES
    };

    MD.MM.getLayout = function () {
        const orientation = MD.Orientation ? MD.Orientation.current : 'landscape';
        return LAYOUT[orientation] || LAYOUT.landscape;
    };
})();