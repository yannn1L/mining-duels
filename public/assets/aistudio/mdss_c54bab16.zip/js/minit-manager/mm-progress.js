// ==========================================
// MINIT MANAGER — PROGRESS + SAVE
// ==========================================
// PlayerProgress state + SaveManager (IndexedDB).
// Deterministic loading. Serialized save queue.
// Debug commands via MD.MM.Debug.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-progress] deps not met');
    if (!MD.MM || !MD.MM.Config || !MD.MM.Registry) throw new Error('[mm-progress] deps not met');

    const { Config, Registry } = MD.MM;

    // ═══════════════════════════════════════════
    // PLAYER PROGRESS
    // ═══════════════════════════════════════════
    class PlayerProgress {
        constructor() {
            this.version = Config.SAVE.DB_VERSION;
            this.resources = {};
            this.discoveredResources = [];
            this.unlockedMinits = ['laser'];
            this.unlockedAreas = ['common_vein'];
            this.completedAchievements = [];
            this.minitUpgrades = {};
            this.slotCount = 1;
            this.squad = ['laser'];
            this.currentAreaId = 'common_vein';
            this.achievements = {
                maxDepth_global: 0,
                maxDepth_per_area: {},
                rocks_destroyed: 0,
                runs_completed: 0,
                totalEarned: {}
            };
            this.lootbox = { pityCounter: 0 };
            this._dirty = false;

            this._initResources();
        }

        _initResources() {
            for (const id of Object.keys(Registry.RESOURCE_REGISTRY)) {
                this.resources[id] = 0;
            }
        }

        sanitize() {
            // ═══ Resources — dynamic ═══
            if (!this.resources || typeof this.resources !== 'object') {
                this.resources = {};
            }
            const validIds = Object.keys(Registry.RESOURCE_REGISTRY);
            for (const id of validIds) {
                if (typeof this.resources[id] !== 'number' || !isFinite(this.resources[id])) {
                    this.resources[id] = 0;
                }
                this.resources[id] = Math.max(0, this.resources[id]);
            }
            for (const k of Object.keys(this.resources)) {
                if (!validIds.includes(k)) {
                    console.warn(`[PlayerProgress] Removing invalid resource: ${k}`);
                    delete this.resources[k];
                }
            }

            // ═══ Discovered resources ═══
            if (!Array.isArray(this.discoveredResources)) {
                this.discoveredResources = [];
                for (const id of validIds) {
                    if (this.resources[id] > 0) this.discoveredResources.push(id);
                }
            }
            this.discoveredResources = this.discoveredResources.filter(id => validIds.includes(id));
            for (const id of validIds) {
                if (this.resources[id] > 0 && !this.discoveredResources.includes(id)) {
                    this.discoveredResources.push(id);
                }
            }
            this.discoveredResources = Array.from(new Set(this.discoveredResources));

            // ═══ Unlocked arrays ═══
            if (!Array.isArray(this.unlockedMinits)) this.unlockedMinits = ['laser'];
            if (!Array.isArray(this.unlockedAreas)) this.unlockedAreas = ['common_vein'];
            if (!Array.isArray(this.completedAchievements)) this.completedAchievements = [];
            if (!Array.isArray(this.squad)) this.squad = ['laser'];

            if (MD.MINIT_DB) {
                this.unlockedMinits = this.unlockedMinits.filter(id => MD.MINIT_DB[id]);
            }
            if (this.unlockedMinits.length === 0) this.unlockedMinits = ['laser'];

            this.unlockedAreas = this.unlockedAreas.filter(id => Registry.AREA_REGISTRY[id]);
            if (this.unlockedAreas.length === 0) this.unlockedAreas = ['common_vein'];

            // ═══ Slots ═══
            this.slotCount = Math.max(1, Math.min(Config.SQUAD.MAX_SIZE, this.slotCount | 0));

            // ═══ Squad ═══
            this.squad = this.squad
                .filter(id => id && this.unlockedMinits.includes(id))
                .slice(0, this.slotCount);
            if (this.squad.length === 0) this.squad = [this.unlockedMinits[0]];

            // ═══ Minit upgrades — safety: hapus field yang tidak ada di base ═══
            if (!this.minitUpgrades || typeof this.minitUpgrades !== 'object') {
                this.minitUpgrades = {};
            }
            for (const minitId of Object.keys(this.minitUpgrades)) {
                if (!MD.MINIT_DB || !MD.MINIT_DB[minitId]) {
                    delete this.minitUpgrades[minitId];
                    continue;
                }
                const up = this.minitUpgrades[minitId];
                if (!up || typeof up !== 'object') {
                    delete this.minitUpgrades[minitId];
                    continue;
                }
                const baseMd = MD.MINIT_DB[minitId];

                if (up.stats && typeof up.stats === 'object') {
                    for (const f of Object.keys(up.stats)) {
                        // SAFETY: hanya field yang ada di base minit
                        let exists = false;
                        if (f === 'cd') exists = typeof baseMd.cd === 'number';
                        else exists = baseMd.ability && typeof baseMd.ability[f] === 'number';

                        if (!exists) {
                            console.warn(`[PlayerProgress] Removing stat "${f}" from "${minitId}" (field not in base minit)`);
                            delete up.stats[f];
                            continue;
                        }
                        const lv = up.stats[f] | 0;
                        up.stats[f] = (!isFinite(lv) || lv < 0) ? 0 : Math.min(6, lv);
                    }
                }
                if (up.tree && typeof up.tree === 'object') {
                    for (const b of Object.keys(up.tree)) {
                        const t = up.tree[b] | 0;
                        up.tree[b] = (!isFinite(t) || t < 0) ? 0 : Math.min(3, t);
                    }
                }
            }

            // ═══ Achievements ═══
            if (!this.achievements || typeof this.achievements !== 'object') {
                this.achievements = {
                    maxDepth_global: 0, maxDepth_per_area: {},
                    rocks_destroyed: 0, runs_completed: 0, totalEarned: {}
                };
            }
            if (!this.achievements.maxDepth_per_area) this.achievements.maxDepth_per_area = {};
            if (!this.achievements.totalEarned) this.achievements.totalEarned = {};
            for (const k of ['maxDepth_global', 'rocks_destroyed', 'runs_completed']) {
                if (typeof this.achievements[k] !== 'number' || !isFinite(this.achievements[k])) {
                    this.achievements[k] = 0;
                }
                this.achievements[k] = Math.max(0, this.achievements[k]);
            }
            for (const k of Object.keys(this.achievements.totalEarned)) {
                if (!validIds.includes(k)) delete this.achievements.totalEarned[k];
            }
            for (const id of validIds) {
                if (typeof this.achievements.totalEarned[id] !== 'number' ||
                    !isFinite(this.achievements.totalEarned[id])) {
                    this.achievements.totalEarned[id] = 0;
                }
            }

            // ═══ Lootbox ═══
            if (!this.lootbox || typeof this.lootbox !== 'object') {
                this.lootbox = { pityCounter: 0 };
            }
            if (typeof this.lootbox.pityCounter !== 'number' || !isFinite(this.lootbox.pityCounter)) {
                this.lootbox.pityCounter = 0;
            }
            this.lootbox.pityCounter = Math.max(0, this.lootbox.pityCounter | 0);

            return this;
        }

        markDirty() { this._dirty = true; }
        isDirty() { return this._dirty; }
        clearDirty() { this._dirty = false; }
    }

    // ═══════════════════════════════════════════
    // SAVE MANAGER
    // ═══════════════════════════════════════════
    const SaveManager = {
        _db: null,
        _available: null,
        _saveQueue: Promise.resolve(),

        async open() {
            if (this._db) return this._db;
            if (this._available === false) return null;

            if (typeof indexedDB === 'undefined') {
                console.warn('[SaveManager] IndexedDB unavailable, fallback');
                this._available = false;
                return null;
            }

            return new Promise((resolve) => {
                try {
                    const req = indexedDB.open(Config.SAVE.DB_NAME, Config.SAVE.DB_VERSION);
                    req.onerror = () => {
                        console.warn('[SaveManager] IndexedDB open failed:', req.error);
                        this._available = false;
                        resolve(null);
                    };
                    req.onsuccess = () => {
                        this._db = req.result;
                        this._available = true;
                        console.log('[SaveManager] IndexedDB opened');
                        resolve(this._db);
                    };
                    req.onupgradeneeded = (e) => {
                        const db = e.target.result;
                        if (!db.objectStoreNames.contains(Config.SAVE.STORE_NAME)) {
                            db.createObjectStore(Config.SAVE.STORE_NAME);
                        }
                    };
                } catch (e) {
                    console.warn('[SaveManager] IndexedDB exception:', e);
                    this._available = false;
                    resolve(null);
                }
            });
        },

        async load() {
            const db = await this.open();
            if (db) {
                return new Promise((resolve) => {
                    try {
                        const tx = db.transaction(Config.SAVE.STORE_NAME, 'readonly');
                        const store = tx.objectStore(Config.SAVE.STORE_NAME);
                        const req = store.get(Config.SAVE.KEY);
                        req.onsuccess = () => {
                            const result = req.result || null;
                            console.log('[SaveManager] Load result:', result ? 'found' : 'empty');
                            resolve(result);
                        };
                        req.onerror = () => {
                            console.warn('[SaveManager] Load error:', req.error);
                            resolve(null);
                        };
                    } catch (e) {
                        console.warn('[SaveManager] Load exception:', e);
                        resolve(null);
                    }
                });
            }
            try {
                const raw = localStorage.getItem(Config.SAVE.FALLBACK_LS_KEY);
                return raw ? JSON.parse(raw) : null;
            } catch (e) {
                return null;
            }
        },

        async save(data) {
            const snapshot = this._serialize(data);
            const prev = this._saveQueue;
            let resolveNext;
            this._saveQueue = new Promise(r => { resolveNext = r; });
            await prev;
            try {
                const ok = await this._saveImpl(snapshot);
                return ok;
            } finally {
                resolveNext();
            }
        },

        async _saveImpl(snapshot) {
            const db = await this.open();
            if (db) {
                return new Promise((resolve) => {
                    try {
                        const tx = db.transaction(Config.SAVE.STORE_NAME, 'readwrite');
                        const store = tx.objectStore(Config.SAVE.STORE_NAME);
                        store.put(snapshot, Config.SAVE.KEY);
                        tx.oncomplete = () => {
                            console.log('[SaveManager] Saved OK');
                            resolve(true);
                        };
                        tx.onerror = () => {
                            console.warn('[SaveManager] Save error:', tx.error);
                            resolve(false);
                        };
                    } catch (e) {
                        console.warn('[SaveManager] Save exception:', e);
                        resolve(false);
                    }
                });
            }
            try {
                localStorage.setItem(Config.SAVE.FALLBACK_LS_KEY, JSON.stringify(snapshot));
                return true;
            } catch (e) {
                console.warn('[SaveManager] LocalStorage save error:', e);
                return false;
            }
        },

        _serialize(progress) {
            const clone = (o) => JSON.parse(JSON.stringify(o || {}));
            return {
                version: progress.version,
                resources: clone(progress.resources),
                discoveredResources: (progress.discoveredResources || []).slice(),
                unlockedMinits: (progress.unlockedMinits || []).slice(),
                unlockedAreas: (progress.unlockedAreas || []).slice(),
                completedAchievements: (progress.completedAchievements || []).slice(),
                minitUpgrades: clone(progress.minitUpgrades),
                slotCount: progress.slotCount,
                squad: (progress.squad || []).slice(),
                currentAreaId: progress.currentAreaId,
                achievements: clone(progress.achievements),
                lootbox: clone(progress.lootbox)
            };
        },

        async clear() {
            const db = await this.open();
            if (db) {
                return new Promise((resolve) => {
                    try {
                        const tx = db.transaction(Config.SAVE.STORE_NAME, 'readwrite');
                        tx.objectStore(Config.SAVE.STORE_NAME).delete(Config.SAVE.KEY);
                        tx.oncomplete = () => resolve(true);
                        tx.onerror = () => resolve(false);
                    } catch (e) { resolve(false); }
                });
            }
            try { localStorage.removeItem(Config.SAVE.FALLBACK_LS_KEY); } catch (e) {}
            return true;
        }
    };

    // ═══════════════════════════════════════════
    // PROGRESS OPS
    // ═══════════════════════════════════════════
    const ProgressOps = {
        addResource(progress, key, amount) {
            const result = Registry.ResourceRegistry.grant(progress, key, amount);
            if (result.ok) progress.markDirty();
            return result;
        },

        canAfford(progress, cost) {
            return Registry.ResourceRegistry.canAfford(progress, cost);
        },

        spend(progress, cost) {
            if (!Registry.ResourceRegistry.spend(progress, cost)) return false;
            progress.markDirty();
            return true;
        },

        unlockArea(progress, areaId) {
            if (progress.unlockedAreas.includes(areaId)) return false;
            if (!Registry.AREA_REGISTRY[areaId]) return false;
            progress.unlockedAreas.push(areaId);
            progress.markDirty();
            return true;
        },

        unlockMinit(progress, minitId) {
            if (progress.unlockedMinits.includes(minitId)) return false;
            if (!MD.MINIT_DB || !MD.MINIT_DB[minitId]) return false;
            progress.unlockedMinits.push(minitId);
            progress.markDirty();
            return true;
        },

        unlockSlot(progress) {
            if (progress.slotCount >= Config.SQUAD.MAX_SIZE) return false;
            progress.slotCount++;
            progress.markDirty();
            return true;
        },

        completeAchievement(progress, achId) {
            if (progress.completedAchievements.includes(achId)) return false;
            progress.completedAchievements.push(achId);
            progress.markDirty();
            return true;
        },

        trackRun(progress, runContext) {
            const a = progress.achievements;
            a.runs_completed++;
            a.rocks_destroyed += (runContext.rocksDestroyed | 0);
            a.maxDepth_global = Math.max(a.maxDepth_global, runContext.maxDepthGlobal | 0);

            const areaId = runContext.areaId;
            a.maxDepth_per_area[areaId] = Math.max(
                a.maxDepth_per_area[areaId] || 0,
                runContext.maxDepthGlobal | 0
            );

            const session = runContext.sessionResources || {};
            const discovered = [];
            for (const k of Object.keys(session)) {
                const v = session[k] || 0;
                if (!isFinite(v) || v === 0) continue;
                const result = Registry.ResourceRegistry.grant(progress, k, v);
                if (result.discovered) discovered.push(k);
                a.totalEarned[k] = (a.totalEarned[k] || 0) + v;
            }
            progress.markDirty();
            return discovered;
        },

        processUnlocks(progress) {
            const notifications = [];

            const newAreas = Registry.UnlockEvaluator.checkAreaUnlocks(progress);
            for (const areaId of newAreas) {
                if (this.unlockArea(progress, areaId)) {
                    const area = Registry.getArea(areaId);
                    notifications.push({
                        type: 'area', id: areaId,
                        title: 'AREA UNLOCKED',
                        subtitle: (area && area.name) || areaId
                    });
                }
            }

            const newMinits = Registry.UnlockEvaluator.checkMinitAchievementUnlocks(progress);
            for (const minitId of newMinits) {
                if (this.unlockMinit(progress, minitId)) {
                    notifications.push({
                        type: 'minit', id: minitId,
                        title: 'MINIT UNLOCKED',
                        subtitle: (MD.MINIT_DB[minitId] && MD.MINIT_DB[minitId].name) || minitId
                    });
                }
            }

            const newAchs = Registry.UnlockEvaluator.checkAchievements(progress);
            for (const achId of newAchs) {
                if (this.completeAchievement(progress, achId)) {
                    const ach = Registry.ACHIEVEMENT_REGISTRY[achId];
                    notifications.push({
                        type: 'achievement', id: achId,
                        title: 'ACHIEVEMENT',
                        subtitle: (ach && ach.name) || achId
                    });
                }
            }

            return notifications;
        }
    };

    // ═══════════════════════════════════════════
    // PROGRESS SERVICE — DETERMINISTIC
    // ═══════════════════════════════════════════
    const ProgressService = {
        progress: null,
        _loadPromise: null,
        _loadCompleted: false,
        _autosaveTimer: null,
        _saveInFlight: null,

        async load() {
            if (this._loadCompleted && this.progress) {
                return this.progress;
            }
            if (this._loadPromise) return this._loadPromise;

            this._loadPromise = (async () => {
                let data = null;
                try {
                    data = await SaveManager.load();
                } catch (e) {
                    console.warn('[ProgressService] Load failed:', e);
                }

                const p = new PlayerProgress();
                if (data && typeof data === 'object') {
                    const fields = ['version', 'resources', 'discoveredResources',
                        'unlockedMinits', 'unlockedAreas', 'completedAchievements',
                        'minitUpgrades', 'slotCount', 'squad', 'currentAreaId',
                        'achievements', 'lootbox'];
                    for (const f of fields) {
                        if (data[f] !== undefined) p[f] = data[f];
                    }
                }
                p.sanitize();
                p.clearDirty();
                this.progress = p;
                this._loadCompleted = true;

                console.log('[ProgressService] Loaded:', JSON.stringify(p.resources));
                return p;
            })();

            try {
                return await this._loadPromise;
            } finally {
                this._loadPromise = null;
            }
        },

        tryGet() {
            return this._loadCompleted ? this.progress : null;
        },

        isLoaded() { return this._loadCompleted; },

        get() {
            if (!this._loadCompleted || !this.progress) {
                throw new Error('[ProgressService] Not loaded — call await load() first');
            }
            return this.progress;
        },

        markDirty() {
            if (this.progress) this.progress.markDirty();
        },

        scheduleAutosave() {
            if (!this._loadCompleted || !this.progress) return;
            this.progress.markDirty();
            if (this._autosaveTimer) clearTimeout(this._autosaveTimer);
            this._autosaveTimer = setTimeout(() => {
                this._autosaveTimer = null;
                this.saveNow();
            }, Config.SAVE.AUTOSAVE_DEBOUNCE_MS);
        },

        async saveNow() {
            if (!this._loadCompleted || !this.progress) {
                console.warn('[ProgressService] saveNow skipped — not loaded');
                return false;
            }
            if (!this.progress.isDirty()) {
                return true;
            }
            if (this._saveInFlight) {
                try { await this._saveInFlight; } catch (e) {}
            }
            try {
                this._saveInFlight = SaveManager.save(this.progress);
                await this._saveInFlight;
                this.progress.clearDirty();
                return true;
            } catch (e) {
                console.warn('[ProgressService] Save failed:', e);
                return false;
            } finally {
                this._saveInFlight = null;
            }
        },

        async reset() {
            await SaveManager.clear();
            const p = new PlayerProgress();
            p.sanitize();
            this.progress = p;
            this._loadCompleted = true;
            p.markDirty();
            await this.saveNow();
            return p;
        }
    };

    // ═══════════════════════════════════════════
    // ACHIEVEMENT SYSTEM
    // ═══════════════════════════════════════════
    const AchievementSystem = {
        getAll(progress) {
            const out = [];
            for (const id of Object.keys(Registry.ACHIEVEMENT_REGISTRY)) {
                const ach = Registry.ACHIEVEMENT_REGISTRY[id];
                out.push({
                    id, name: ach.name, desc: ach.desc,
                    completed: progress.completedAchievements.includes(id)
                });
            }
            return out;
        },

        progressFor(progress, achId) {
            const ach = Registry.ACHIEVEMENT_REGISTRY[achId];
            if (!ach) return { current: 0, target: 1, pct: 0 };
            const cond = ach.condition;
            let current = 0, target = 1;
            switch (cond.type) {
                case 'depth':
                    current = (progress.achievements.maxDepth_per_area[cond.areaId] || 0);
                    target = cond.value; break;
                case 'rocks_destroyed':
                    current = progress.achievements.rocks_destroyed;
                    target = cond.value; break;
                case 'runs_completed':
                    current = progress.achievements.runs_completed;
                    target = cond.value; break;
                case 'resource_total':
                    current = progress.achievements.totalEarned[cond.resourceId] || 0;
                    target = cond.value; break;
                default: return { current: 0, target: 1, pct: 0 };
            }
            const pct = target > 0 ? Math.min(1, current / target) : 0;
            return { current, target, pct };
        }
    };

    // ═══════════════════════════════════════════
    // DEBUG — Console commands
    // ═══════════════════════════════════════════
    const Debug = {
        help() {
            console.log(`
╔══════════════════════════════════════════════════╗
║  MINITS MANAGER — DEBUG COMMANDS                ║
╠══════════════════════════════════════════════════╣
║  GRANT RESOURCES                                 ║
║    MD.MM.Debug.grantAll(amount = 999999)        ║
║      → Beri semua resource + minit + area       ║
║        + max slot                               ║
║                                                  ║
║    MD.MM.Debug.grantResources(amount)           ║
║      → Beri semua resource saja                 ║
║                                                  ║
║    MD.MM.Debug.grantSpecific(id, amount)        ║
║      → Beri 1 resource spesifik                 ║
║      Contoh:                                     ║
║        MD.MM.Debug.grantSpecific('gems', 10000) ║
║        MD.MM.Debug.grantSpecific('cores', 100)  ║
║                                                  ║
║  UNLOCK                                          ║
║    MD.MM.Debug.unlockAll()                      ║
║      → Unlock semua minit + area + max slot     ║
║                                                  ║
║    MD.MM.Debug.unlockMinit('moth')              ║
║    MD.MM.Debug.unlockArea('volcanic')           ║
║                                                  ║
║  RESET                                           ║
║    MD.MM.Debug.resetAll()                       ║
║      → Reset semua progress                     ║
║                                                  ║
║    MD.MM.Debug.resetAndGrant()                  ║
║      → Reset + langsung grant semua             ║
║                                                  ║
║    MD.MM.Debug.clearSave()                      ║
║      → Hapus save (F5 untuk fresh start)        ║
║                                                  ║
║  INFO                                            ║
║    MD.MM.Debug.dump()                           ║
║      → Print current progress state             ║
║                                                  ║
║  Note: Setelah grant/reset, refresh scene       ║
║        (tutup-buka modal atau F5) supaya UI     ║
║        re-read progress.                        ║
╚══════════════════════════════════════════════════╝
`);
        },

        /**
         * Grant semua: resource + minit + area + max slot.
         */
        async grantAll(amount = 999999) {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }

            // Resources
            for (const id of Object.keys(Registry.RESOURCE_REGISTRY)) {
                p.resources[id] = amount;
                if (!p.discoveredResources.includes(id)) {
                    p.discoveredResources.push(id);
                }
            }
            // Minits
            for (const id of Object.keys(MD.MINIT_DB)) {
                if (!p.unlockedMinits.includes(id)) p.unlockedMinits.push(id);
            }
            // Areas
            for (const id of Object.keys(Registry.AREA_REGISTRY)) {
                if (!p.unlockedAreas.includes(id)) p.unlockedAreas.push(id);
            }
            // Slots
            p.slotCount = Config.SQUAD.MAX_SIZE;

            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] Grant all complete. Resources=${amount}, Minits=${Object.keys(MD.MINIT_DB).length}, Areas=${Object.keys(Registry.AREA_REGISTRY).length}, Slots=${Config.SQUAD.MAX_SIZE}`);
            console.log('[Debug] Refresh scene (close + reopen modal, or F5) untuk lihat perubahan.');
        },

        /**
         * Reset progress ke fresh state.
         */
        async resetAll() {
            await ProgressService.reset();
            console.log('[Debug] Progress reset. Reload page (F5) untuk fresh start.');
        },

        /**
         * Reset + grant dalam satu command.
         */
        async resetAndGrant(amount = 999999) {
            await this.resetAll();
            await new Promise(r => setTimeout(r, 150));
            await this.grantAll(amount);
            console.log('[Debug] Reset + grant complete. Reload page (F5) untuk lihat.');
        },

        /**
         * Grant semua resource (tanpa unlock minit/area).
         */
        async grantResources(amount = 999999) {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }
            for (const id of Object.keys(Registry.RESOURCE_REGISTRY)) {
                p.resources[id] = amount;
                if (!p.discoveredResources.includes(id)) p.discoveredResources.push(id);
            }
            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] Granted ${amount} of all resources.`);
        },

        /**
         * Grant 1 resource spesifik.
         */
        async grantSpecific(resourceId, amount) {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }
            if (!Registry.RESOURCE_REGISTRY[resourceId]) {
                console.warn(`[Debug] Resource "${resourceId}" not found.`);
                console.warn('Valid resources:', Object.keys(Registry.RESOURCE_REGISTRY));
                return;
            }
            if (typeof amount !== 'number' || !isFinite(amount)) {
                console.warn(`[Debug] Amount must be finite number`);
                return;
            }
            const grant = Registry.ResourceRegistry.grant(p, resourceId, amount);
            if (!grant.ok) {
                console.warn(`[Debug] Grant failed`);
                return;
            }
            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] Granted ${amount} ${resourceId}. Total: ${p.resources[resourceId]}`);
        },

        /**
         * Unlock semua minit + area + max slot.
         */
        async unlockAll() {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }
            for (const id of Object.keys(MD.MINIT_DB)) {
                if (!p.unlockedMinits.includes(id)) p.unlockedMinits.push(id);
            }
            for (const id of Object.keys(Registry.AREA_REGISTRY)) {
                if (!p.unlockedAreas.includes(id)) p.unlockedAreas.push(id);
            }
            p.slotCount = Config.SQUAD.MAX_SIZE;
            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] All unlocked. Minits=${p.unlockedMinits.length}, Areas=${p.unlockedAreas.length}, Slots=${p.slotCount}`);
        },

        /**
         * Unlock minit spesifik.
         */
        async unlockMinit(minitId) {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }
            if (!MD.MINIT_DB[minitId]) {
                console.warn(`[Debug] Minit "${minitId}" not found.`);
                console.warn('Valid minits:', Object.keys(MD.MINIT_DB));
                return;
            }
            if (p.unlockedMinits.includes(minitId)) {
                console.log(`[Debug] Minit "${minitId}" already unlocked.`);
                return;
            }
            p.unlockedMinits.push(minitId);
            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] Unlocked minit "${minitId}".`);
        },

        /**
         * Unlock area spesifik.
         */
        async unlockArea(areaId) {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return; }
            if (!Registry.AREA_REGISTRY[areaId]) {
                console.warn(`[Debug] Area "${areaId}" not found.`);
                console.warn('Valid areas:', Object.keys(Registry.AREA_REGISTRY));
                return;
            }
            if (p.unlockedAreas.includes(areaId)) {
                console.log(`[Debug] Area "${areaId}" already unlocked.`);
                return;
            }
            p.unlockedAreas.push(areaId);
            p.markDirty();
            await ProgressService.saveNow();
            console.log(`[Debug] Unlocked area "${areaId}".`);
        },

        /**
         * Hapus save dari storage (F5 untuk efek fresh start).
         */
        async clearSave() {
            await SaveManager.clear();
            console.log('[Debug] Save cleared. Reload page (F5) untuk fresh start.');
        },

        /**
         * Print current progress state.
         */
        dump() {
            const p = ProgressService.tryGet();
            if (!p) { console.warn('[Debug] Progress not loaded'); return null; }
            const dump = {
                resources: { ...p.resources },
                discovered: [...p.discoveredResources],
                unlockedMinits: [...p.unlockedMinits],
                unlockedAreas: [...p.unlockedAreas],
                slotCount: p.slotCount,
                squad: [...p.squad],
                minitUpgrades: JSON.parse(JSON.stringify(p.minitUpgrades)),
                achievements: JSON.parse(JSON.stringify(p.achievements)),
                lootbox: { ...p.lootbox }
            };
            console.log('[Progress Dump]', dump);
            return dump;
        },

        /**
         * Dump daftar valid ID (helper untuk grant spesifik).
         */
        list() {
            console.log('Resources:', Object.keys(Registry.RESOURCE_REGISTRY));
            console.log('Areas:', Object.keys(Registry.AREA_REGISTRY));
            console.log('Minits:', Object.keys(MD.MINIT_DB));
        }
    };

    // ═══════════════════════════════════════════
    // EXPORT
    // ═══════════════════════════════════════════
    MD.MM.PlayerProgress = PlayerProgress;
    MD.MM.SaveManager = SaveManager;
    MD.MM.ProgressOps = ProgressOps;
    MD.MM.ProgressService = ProgressService;
    MD.MM.AchievementSystem = AchievementSystem;
    MD.MM.Debug = Debug;

    // Auto-print help hint di console
    console.log('[MM Debug] Commands available. Type: MD.MM.Debug.help()');
})();