// ==========================================
// MINIT MANAGER — UPGRADES
// ==========================================
// Upgrade trees data + stat ops + tree ops + apply logic.
// SAFETY: setiap minit punya `upgradeableStats` whitelist.
// Field yang tidak ada di base minit akan di-skip dengan warning.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-upgrades] deps not met');
    if (!MD.MM || !MD.MM.Config) throw new Error('[mm-upgrades] mm-config.js must load first');

    const { Config } = MD.MM;

    // ═══════════════════════════════════════════
    // UPGRADE TREES
    // ═══════════════════════════════════════════
    // Setiap minit:
    //   - upgradeableStats: array of field names (cd atau ability.<field>)
    //   - branches: array of 3 skill tree branches
    //
    // Field di upgradeableStats HARUS ada di MINIT_DB[minitId].
    // Kalau tidak ada → di-skip dengan warning (safety).
    // ==========================================
    const UPGRADE_TREES = {
        laser: {
            upgradeableStats: ['cd', 'dmg', 'length', 'duration'],
            branches: [
                {
                    id: 'pierce',
                    name: 'PIERCING BEAM',
                    tiers: [
                        { desc: '+2 length', effect: { ability: { length: '+2' } } },
                        { desc: '+3 length', effect: { ability: { length: '+3' } } },
                        { desc: 'Pierce (dmg x1.5)', effect: { strategy: 'beam_pierce' } }
                    ]
                },
                {
                    id: 'burst',
                    name: 'BURST FIRE',
                    tiers: [
                        { desc: 'Unlock burst x2', effect: { ability: { burstCount: 2 }, strategy: 'beam_burst' } },
                        { desc: 'Burst x3', effect: { ability: { burstCount: 3 } } },
                        { desc: '+50 burst dmg', effect: { ability: { burstDmg: '+50' } } }
                    ]
                },
                {
                    id: 'core',
                    name: 'CORE POWER',
                    tiers: [
                        { desc: '+20 dmg', effect: { ability: { dmg: '+20' } } },
                        { desc: 'CD -3', effect: { cd: -3 } },
                        { desc: '+100 dmg', effect: { ability: { dmg: '+100' } } }
                    ]
                }
            ]
        },
        moth: {
            upgradeableStats: ['cd', 'dmg', 'range', 'hatchTime'],
            branches: [
                {
                    id: 'swarm',
                    name: 'SWARM',
                    tiers: [
                        { desc: 'Spawn +1 spore', effect: { ability: { sporeCount: 2 }, strategy: 'moth_multi_spore' } },
                        { desc: 'Spawn +1 spore', effect: { ability: { sporeCount: 3 } } },
                        { desc: 'Spawn +2 spores', effect: { ability: { sporeCount: 5 } } }
                    ]
                },
                {
                    id: 'toxin',
                    name: 'TOXIN',
                    tiers: [
                        { desc: '+100 spore dmg', effect: { ability: { dmg: '+100' } } },
                        { desc: '+200 spore dmg', effect: { ability: { dmg: '+200' } } },
                        { desc: 'Slow on hit', effect: { ability: { slowOnHit: true }, strategy: 'moth_slow' } }
                    ]
                },
                {
                    id: 'hatch',
                    name: 'FAST HATCH',
                    tiers: [
                        { desc: 'Hatch -2s', effect: { ability: { hatchTime: -120 } } },
                        { desc: 'Hatch -2s', effect: { ability: { hatchTime: -120 } } },
                        { desc: 'Instant hatch', effect: { ability: { hatchTime: -240 } } }
                    ]
                }
            ]
        },
        absorb: {
            upgradeableStats: ['cd', 'baseDmg', 'scaling', 'baseRange', 'maxTargets'],
            branches: [
                {
                    id: 'chain',
                    name: 'CHAIN ABSORB',
                    tiers: [
                        { desc: 'Pull radius +1', effect: { ability: { baseRange: '+1' } } },
                        { desc: 'Chain pull', effect: { strategy: 'absorb_chain' } },
                        { desc: 'Vortex absorb', effect: { strategy: 'absorb_vortex' } }
                    ]
                },
                {
                    id: 'power',
                    name: 'DEEP DRAIN',
                    tiers: [
                        { desc: '+10 baseDmg', effect: { ability: { baseDmg: '+10' } } },
                        { desc: '+1.5 scaling', effect: { ability: { scaling: '+1.5' } } },
                        { desc: '+30 baseDmg', effect: { ability: { baseDmg: '+30' } } }
                    ]
                },
                {
                    id: 'targets',
                    name: 'MULTI-TARGET',
                    tiers: [
                        { desc: '+3 maxTargets', effect: { ability: { maxTargets: '+3' } } },
                        { desc: '+5 maxTargets', effect: { ability: { maxTargets: '+5' } } },
                        { desc: '+10 maxTargets', effect: { ability: { maxTargets: '+10' } } }
                    ]
                }
            ]
        },
        lithos: {
            upgradeableStats: ['cd', 'areaDmg', 'areaRange', 'rareChance', 'snapDmg'],
            branches: [
                {
                    id: 'crystal',
                    name: 'CRYSTAL LORE',
                    tiers: [
                        { desc: '+5% rareChance', effect: { ability: { rareChance: '+0.05' } } },
                        { desc: '+5% rareChance', effect: { ability: { rareChance: '+0.05' } } },
                        { desc: 'Guaranteed 5th crystal', effect: { ability: { guaranteedCrystal: true } } }
                    ]
                },
                {
                    id: 'snap',
                    name: 'SNAP POWER',
                    tiers: [
                        { desc: '+100 snapDmg', effect: { ability: { snapDmg: '+100' } } },
                        { desc: 'Gem burst', effect: { strategy: 'lithos_gem_burst' } },
                        { desc: 'Super snap (80% clear)', effect: { strategy: 'lithos_super_snap' } }
                    ]
                },
                {
                    id: 'area',
                    name: 'LARGER AREA',
                    tiers: [
                        { desc: '+1 areaRange', effect: { ability: { areaRange: '+1' } } },
                        { desc: '+2 areaRange', effect: { ability: { areaRange: '+2' } } },
                        { desc: '+20 areaDmg', effect: { ability: { areaDmg: '+20' } } }
                    ]
                }
            ]
        }
    };

    // ═══════════════════════════════════════════
    // HELPER: cek apakah field ada di base minit
    // ═══════════════════════════════════════════
    function fieldExists(baseMd, field) {
        if (!baseMd) return false;
        if (field === 'cd') return typeof baseMd.cd === 'number';
        return baseMd.ability && typeof baseMd.ability[field] === 'number';
    }

    // ═══════════════════════════════════════════
    // STAT OPS
    // ═══════════════════════════════════════════
    const StatOps = {
        MAX_LEVEL: 6,

        getStatLevel(progress, minitId, field) {
            const up = progress.minitUpgrades[minitId];
            if (!up || !up.stats) return 0;
            return (up.stats[field] | 0);
        },

        canUpgradeStat(progress, minitId, field) {
            return this.getStatLevel(progress, minitId, field) < this.MAX_LEVEL;
        },

        getStatCost(progress, minitId, field) {
            const level = this.getStatLevel(progress, minitId, field);
            if (level >= this.MAX_LEVEL) return null;
            return Config.STAT_UPGRADE_COSTS[level] || null;
        },

        applyStatUpgrade(progress, minitId, field, ProgressOps) {
            if (!this.canUpgradeStat(progress, minitId, field)) return false;
            const cost = this.getStatCost(progress, minitId, field);
            if (!cost) return false;
            if (!ProgressOps.spend(progress, cost)) return false;

            if (!progress.minitUpgrades[minitId]) progress.minitUpgrades[minitId] = {};
            if (!progress.minitUpgrades[minitId].stats) progress.minitUpgrades[minitId].stats = {};
            progress.minitUpgrades[minitId].stats[field] =
                (progress.minitUpgrades[minitId].stats[field] | 0) + 1;
            progress.markDirty();
            return true;
        },

        computeStatValue(baseValue, field, level) {
            if (level <= 0) return baseValue;
            const inc = Config.STAT_INCREMENTS[field];
            if (inc) {
                const val = baseValue + (inc.step * level);
                return Math.max(inc.min, val);
            }
            if (typeof baseValue !== 'number') return baseValue;
            return Math.round(baseValue * (1 + 0.1 * level));
        }
    };

    // ═══════════════════════════════════════════
    // TREE OPS
    // ═══════════════════════════════════════════
    const TreeOps = {
        getTreeState(progress, minitId) {
            const up = progress.minitUpgrades[minitId];
            if (!up || !up.tree) return {};
            return up.tree;
        },

        getBranchTier(progress, minitId, branchId) {
            return this.getTreeState(progress, minitId)[branchId] | 0;
        },

        canUnlockTier(progress, minitId, branchId, tier) {
            const current = this.getBranchTier(progress, minitId, branchId);
            return tier === current + 1 && tier <= 3;
        },

        getTierCost(progress, minitId, branchId, tier) {
            if (!this.canUnlockTier(progress, minitId, branchId, tier)) return null;
            return Config.TREE_UPGRADE_COSTS[tier - 1] || null;
        },

        applyTreeUpgrade(progress, minitId, branchId, ProgressOps) {
            const current = this.getBranchTier(progress, minitId, branchId);
            const nextTier = current + 1;
            if (nextTier > 3) return false;

            const cost = Config.TREE_UPGRADE_COSTS[nextTier - 1];
            if (!cost || !ProgressOps.spend(progress, cost)) return false;

            if (!progress.minitUpgrades[minitId]) progress.minitUpgrades[minitId] = {};
            if (!progress.minitUpgrades[minitId].tree) progress.minitUpgrades[minitId].tree = {};
            progress.minitUpgrades[minitId].tree[branchId] = nextTier;
            progress.markDirty();
            return true;
        }
    };

    // ═══════════════════════════════════════════
    // UPGRADE APPLY
    // ═══════════════════════════════════════════
    const UpgradeApply = {
        _shareFields: ['onInit', 'onUpdate', 'onTrigger', 'textures', 'vfx', 'getStatsStr'],

        cloneMinitMd(baseMd) {
            if (!baseMd || typeof baseMd !== 'object') return baseMd;
            const cloned = {};
            for (const k of Object.keys(baseMd)) {
                if (this._shareFields.includes(k)) {
                    cloned[k] = baseMd[k];
                } else if (k === 'ability' && typeof baseMd.ability === 'object') {
                    cloned.ability = { ...baseMd.ability };
                } else if (typeof baseMd[k] === 'object' && baseMd[k] !== null) {
                    try { cloned[k] = JSON.parse(JSON.stringify(baseMd[k])); }
                    catch (e) { cloned[k] = baseMd[k]; }
                } else {
                    cloned[k] = baseMd[k];
                }
            }
            return cloned;
        },

        /**
         * Get upgradeable stats untuk minit.
         * Return array of { field, maxLevel }.
         * - Skip field yang tidak ada di base minit (safety).
         * - Kalau minit tidak punya upgradeableStats → fallback ke ['cd'].
         */
        getUpgradeableStats(minitId, baseMd) {
            const tree = UPGRADE_TREES[minitId];
            const result = [];

            if (!tree || !tree.upgradeableStats) {
                // Fallback: cuma 'cd' kalau ada
                if (fieldExists(baseMd, 'cd')) {
                    result.push({ field: 'cd', maxLevel: StatOps.MAX_LEVEL });
                }
                return result;
            }

            for (const field of tree.upgradeableStats) {
                if (fieldExists(baseMd, field)) {
                    result.push({ field, maxLevel: StatOps.MAX_LEVEL });
                } else {
                    console.warn(`[UpgradeApply] Field "${field}" not found in minit "${minitId}" — skipping`);
                }
            }
            return result;
        },

        _parseEffectValue(raw) {
            if (typeof raw === 'number') return raw;
            if (typeof raw === 'boolean') return raw;
            if (typeof raw === 'string') {
                if (raw.startsWith('+')) return parseFloat(raw.slice(1));
                if (raw.startsWith('-')) return parseFloat(raw);
                if (raw === 'true') return true;
                if (raw === 'false') return false;
                const n = parseFloat(raw);
                return isNaN(n) ? raw : n;
            }
            return raw;
        },

        _applyTierEffect(md, effect) {
            if (!effect) return;
            if (effect.ability) {
                for (const k of Object.keys(effect.ability)) {
                    const raw = effect.ability[k];
                    const val = this._parseEffectValue(raw);
                    if (typeof raw === 'string' && typeof val === 'number' &&
                        typeof md.ability[k] === 'number') {
                        md.ability[k] = md.ability[k] + val;
                    } else {
                        md.ability[k] = val;
                    }
                }
            }
            if (typeof effect.cd === 'number') {
                md.cd = Math.max(1, (md.cd || 30) + effect.cd);
            }
        },

        _applyStatLevels(md, stats, minitId) {
            for (const field of Object.keys(stats)) {
                const level = stats[field] | 0;
                if (level <= 0) continue;
                if (field === 'cd') {
                    if (typeof md.cd === 'number') {
                        md.cd = Math.max(1, StatOps.computeStatValue(md.cd, 'cd', level));
                    }
                } else if (md.ability && typeof md.ability[field] === 'number') {
                    md.ability[field] = StatOps.computeStatValue(md.ability[field], field, level);
                }
            }
        },

        _applyTree(md, treeState) {
            const tree = UPGRADE_TREES[md.id];
            if (!tree) return;
            for (const branch of tree.branches) {
                const tier = treeState[branch.id] | 0;
                for (let i = 0; i < tier; i++) {
                    const t = branch.tiers[i];
                    if (t && t.effect) this._applyTierEffect(md, t.effect);
                }
            }
        },

        _collectStrategies(md, treeState) {
            const strategies = [];
            const tree = UPGRADE_TREES[md.id];
            if (!tree) return strategies;
            for (const branch of tree.branches) {
                const tier = treeState[branch.id] | 0;
                for (let i = 0; i < tier; i++) {
                    const t = branch.tiers[i];
                    if (t && t.effect && t.effect.strategy) {
                        strategies.push(t.effect.strategy);
                    }
                }
            }
            return strategies;
        },

        applyToMinit(baseMd, upgradeState) {
            if (!baseMd) return null;
            const md = this.cloneMinitMd(baseMd);
            if (!upgradeState) {
                md.abilityStrategies = [];
                return md;
            }
            if (upgradeState.stats) this._applyStatLevels(md, upgradeState.stats, baseMd.id);
            if (upgradeState.tree) this._applyTree(md, upgradeState.tree);
            md.abilityStrategies = this._collectStrategies(md, upgradeState.tree || {});
            return md;
        },

        getBranches(minitId) {
            const tree = UPGRADE_TREES[minitId];
            return tree ? tree.branches : [];
        }
    };

    MD.MM.UPGRADE_TREES = UPGRADE_TREES;
    MD.MM.StatOps = StatOps;
    MD.MM.TreeOps = TreeOps;
    MD.MM.UpgradeApply = UpgradeApply;
})();