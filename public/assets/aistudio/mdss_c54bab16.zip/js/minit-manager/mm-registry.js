// ==========================================
// MINIT MANAGER — REGISTRY
// ==========================================
// Resource, Area, Minit Unlock, Achievement registries.
// Pure functions. No side effects.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-registry] deps not met');
    if (!MD.MM || !MD.MM.Config) throw new Error('[mm-registry] mm-config.js must load first');

    const { Config } = MD.MM;

    // ═══════════════════════════════════════════
    // RESOURCE REGISTRY
    // ═══════════════════════════════════════════
    const RESOURCE_REGISTRY = {
        gems: { id: 'gems', label: 'GEMS', color: 0x00ffcc, shape: 'diamond',
            iconTexture: 'icon_diamond', desc: 'Basic currency for upgrades',
            isPrimary: true, sortOrder: 0 },
        parts: { id: 'parts', label: 'PARTS', color: 0xcccccc, shape: 'hex',
            iconTexture: 'icon_gear', desc: 'Mechanical components',
            isPrimary: true, sortOrder: 1 },
        research: { id: 'research', label: 'RESEARCH', color: 0xcc88ff, shape: 'star',
            iconTexture: 'icon_flask', desc: 'Scientific knowledge',
            isPrimary: true, sortOrder: 2 },
        cores: { id: 'cores', label: 'CORES', color: 0xffaa44, shape: 'circle',
            iconTexture: 'icon_hex', desc: 'Rare power sources',
            isPrimary: true, sortOrder: 3 },
        crystal_shard: { id: 'crystal_shard', label: 'SHARDS', color: 0xff88ff, shape: 'triangle',
            iconTexture: 'icon_shard', desc: 'Crystalline fragments',
            isPrimary: false, sortOrder: 10 },
        ancient_rune: { id: 'ancient_rune', label: 'RUNES', color: 0xffcc44, shape: 'square',
            iconTexture: 'icon_rune', desc: 'Forgotten symbols of the ancients',
            isPrimary: false, sortOrder: 11 },
        toxic_essence: { id: 'toxic_essence', label: 'ESSENCE', color: 0x88ff44, shape: 'circle',
            iconTexture: 'icon_essence', desc: 'Concentrated toxins',
            isPrimary: false, sortOrder: 12 },
        magma_ember: { id: 'magma_ember', label: 'EMBERS', color: 0xff6622, shape: 'triangle',
            iconTexture: 'icon_ember', desc: 'Eternal flames',
            isPrimary: false, sortOrder: 13 }
    };

    // ═══════════════════════════════════════════
    // AREA REGISTRY
    // ═══════════════════════════════════════════
    const AREA_REGISTRY = {
        common_vein: {
            id: 'common_vein', name: 'COMMON VEIN',
            desc: 'Balanced starter area. Good for grinding basics.',
            preset: { rockColor: 0x3d4045, oreColor: 0xaaaaaa, baseHP: 8, density: 1.0 },
            rocks: { colors: [0x3d4045, 0x4a4d52, 0x555a60, 0x606870, 0x707880], shape: 'solid' },
            duration: 120, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.50, depthMul: 0.010 },
                { id: 'parts', baseRate: 0.25, depthMul: 0.005 },
                { id: 'research', baseRate: 0.05, depthMul: 0.002 }
            ],
            unlock: null
        },
        volcanic: {
            id: 'volcanic', name: 'VOLCANIC VEIN',
            desc: 'Hot rocks yield more parts but fewer gems.',
            preset: { rockColor: 0x6e3636, oreColor: 0xff4422, baseHP: 12, density: 1.2 },
            rocks: { colors: [0x6e3636, 0x7a3a3a, 0x8a2a2a, 0x9a2020, 0xb03030], shape: 'rusty' },
            duration: 150, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.35, depthMul: 0.008 },
                { id: 'parts', baseRate: 0.65, depthMul: 0.015 },
                { id: 'cores', baseRate: 0.02, depthMul: 0.001 }
            ],
            unlock: { type: 'depth', areaId: 'common_vein', value: 50 }
        },
        crystalline: {
            id: 'crystalline', name: 'CRYSTAL VEIN',
            desc: 'Gem-rich area. Slow to mine but rewarding.',
            preset: { rockColor: 0x5e236e, oreColor: 0xcc66ff, baseHP: 16, density: 0.9 },
            rocks: { colors: [0x5e236e, 0x6a2a7a, 0x7a3088, 0x8a4498, 0x9a5aa8], shape: 'crystal' },
            duration: 180, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.75, depthMul: 0.020 },
                { id: 'crystal_shard', baseRate: 0.15, depthMul: 0.015 },
                { id: 'research', baseRate: 0.10, depthMul: 0.008 }
            ],
            unlock: { type: 'resource', resourceId: 'gems', value: 5000 }
        },
        ancient: {
            id: 'ancient', name: 'ANCIENT VEIN',
            desc: 'Precursor ruins. Research-focused.',
            preset: { rockColor: 0x544738, oreColor: 0xffcc44, baseHP: 20, density: 0.7 },
            rocks: { colors: [0x544738, 0x5e5042, 0x6a5a4a, 0x766654, 0x82725e], shape: 'organic' },
            duration: 240, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.25, depthMul: 0.008 },
                { id: 'research', baseRate: 0.55, depthMul: 0.020 },
                { id: 'ancient_rune', baseRate: 0.10, depthMul: 0.012 }
            ],
            unlock: {
                type: 'all_of',
                conditions: [
                    { type: 'depth', areaId: 'volcanic', value: 100 },
                    { type: 'resource', resourceId: 'research', value: 500 }
                ]
            }
        },
        gasrich: {
            id: 'gasrich', name: 'GAS-RICH VEIN',
            desc: 'Volatile. Fast mining, high risk, core drops.',
            preset: { rockColor: 0x3d4045, oreColor: 0x88ffcc, baseHP: 6, density: 1.5 },
            rocks: { colors: [0x2a4a4a, 0x2e5252, 0x325a5a, 0x366262, 0x3a6a6a], shape: 'organic' },
            duration: 90, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.30, depthMul: 0.010 },
                { id: 'parts', baseRate: 0.40, depthMul: 0.010 },
                { id: 'cores', baseRate: 0.15, depthMul: 0.020 }
            ],
            unlock: {
                type: 'any_of',
                conditions: [
                    { type: 'depth', areaId: 'common_vein', value: 200 },
                    { type: 'resource', resourceId: 'cores', value: 5 }
                ]
            }
        },
        crystal_depths: {
            id: 'crystal_depths', name: 'CRYSTAL DEPTHS',
            desc: 'Deep gem-rich area. Bring your best drillers.',
            preset: { rockColor: 0x4a3a5e, oreColor: 0xff88ff, baseHP: 22, density: 1.3 },
            rocks: { colors: [0x4a3a5e, 0x5a4a6e, 0x6a5a7e, 0x7a6a8e, 0x8a7a9e], shape: 'crystal' },
            duration: 200, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 1.0, depthMul: 0.025 },
                { id: 'crystal_shard', baseRate: 0.35, depthMul: 0.025 },
                { id: 'research', baseRate: 0.15, depthMul: 0.010 }
            ],
            unlock: {
                type: 'all_of',
                conditions: [
                    { type: 'depth', areaId: 'crystalline', value: 150 },
                    { type: 'resource', resourceId: 'gems', value: 20000 }
                ]
            }
        },
        toxic_mines: {
            id: 'toxic_mines', name: 'TOXIC MINES',
            desc: 'Poisonous area. Research + unique essence.',
            preset: { rockColor: 0x4a6a3a, oreColor: 0x88ff44, baseHP: 14, density: 1.4 },
            rocks: { colors: [0x3a5a2a, 0x426232, 0x4a6a3a, 0x527242, 0x5a7a4a], shape: 'organic' },
            duration: 180, maxDepth: 999,
            drops: [
                { id: 'research', baseRate: 0.55, depthMul: 0.020 },
                { id: 'toxic_essence', baseRate: 0.20, depthMul: 0.018 },
                { id: 'cores', baseRate: 0.05, depthMul: 0.005 }
            ],
            unlock: {
                type: 'all_of',
                conditions: [
                    { type: 'depth', areaId: 'ancient', value: 200 },
                    { type: 'resource', resourceId: 'research', value: 2000 }
                ]
            }
        },
        abandoned_shaft: {
            id: 'abandoned_shaft', name: 'ABANDONED SHAFT',
            desc: 'Left by ancient miners. Everything available, few rewards.',
            preset: { rockColor: 0x2a2a2a, oreColor: 0x888888, baseHP: 4, density: 2.5 },
            rocks: { colors: [0x1e1e1e, 0x2a2a2a, 0x363636, 0x424242, 0x505050], shape: 'metallic' },
            duration: 60, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.20, depthMul: 0.005 },
                { id: 'parts', baseRate: 0.30, depthMul: 0.008 },
                { id: 'research', baseRate: 0.20, depthMul: 0.008 },
                { id: 'cores', baseRate: 0.08, depthMul: 0.008 }
            ],
            unlock: { type: 'resource', resourceId: 'cores', value: 3 }
        },
        magma_chamber: {
            id: 'magma_chamber', name: 'MAGMA CHAMBER',
            desc: 'Extreme heat. Legendary cores + embers.',
            preset: { rockColor: 0x8a2a2a, oreColor: 0xff6622, baseHP: 28, density: 1.1 },
            rocks: { colors: [0x8a2a2a, 0x9a2e2e, 0xaa3232, 0xba3a3a, 0xca4444], shape: 'metallic' },
            duration: 300, maxDepth: 999,
            drops: [
                { id: 'gems', baseRate: 0.35, depthMul: 0.015 },
                { id: 'cores', baseRate: 0.30, depthMul: 0.025 },
                { id: 'magma_ember', baseRate: 0.20, depthMul: 0.020 }
            ],
            unlock: {
                type: 'any_of',
                conditions: [
                    { type: 'depth', areaId: 'crystal_depths', value: 300 },
                    { type: 'resource', resourceId: 'cores', value: 50 }
                ]
            }
        }
    };

    // ═══════════════════════════════════════════
    // MINIT UNLOCK REGISTRY
    // ═══════════════════════════════════════════
    const MINIT_UNLOCK_REGISTRY = {
        laser: { method: 'starter' },
        moth: {
            method: 'achievement',
            condition: { type: 'depth', areaId: 'common_vein', value: 40 }
        },
        absorb: {
            method: 'crafting',
            cost: { gems: 3000, parts: 300 }
        },
        lithos: {
            method: 'achievement',
            condition: { type: 'rocks_destroyed', value: 3000 }
        }
    };

    const LOOTBOX_POOLS = {
        common: ['moth'],
        rare: ['absorb'],
        legendary: ['lithos']
    };

    // ═══════════════════════════════════════════
    // ACHIEVEMENT REGISTRY
    // ═══════════════════════════════════════════
    const ACHIEVEMENT_REGISTRY = {
        first_100_rocks: {
            id: 'first_100_rocks', name: 'FIRST HAUL',
            desc: 'Destroy 100 rocks',
            condition: { type: 'rocks_destroyed', value: 100 }
        },
        depth_100: {
            id: 'depth_100', name: 'DEEP DIVER',
            desc: 'Reach depth 100',
            condition: { type: 'depth', areaId: 'common_vein', value: 100 }
        },
        gems_10k: {
            id: 'gems_10k', name: 'GEM HOARDER',
            desc: 'Collect 10,000 gems lifetime',
            condition: { type: 'resource_total', resourceId: 'gems', value: 10000 }
        },
        first_run: {
            id: 'first_run', name: 'FIRST SHIFT',
            desc: 'Complete your first run',
            condition: { type: 'runs_completed', value: 1 }
        }
    };

    // ═══════════════════════════════════════════
    // RESOURCE HELPERS
    // ═══════════════════════════════════════════
    const ResourceRegistry = {
        get(id) { return RESOURCE_REGISTRY[id] || null; },
        getAll() { return Object.values(RESOURCE_REGISTRY); },
        getSorted() {
            return this.getAll().sort((a, b) => (a.sortOrder | 0) - (b.sortOrder | 0));
        },
        getPrimary() { return this.getAll().filter(r => r.isPrimary); },

        getDiscovered(progress) {
            if (!progress || !Array.isArray(progress.discoveredResources)) {
                return this.getPrimary();
            }
            const discoveredSet = new Set(progress.discoveredResources);
            return this.getSorted().filter(r => r.isPrimary || discoveredSet.has(r.id));
        },

        grant(progress, id, amount) {
            if (!RESOURCE_REGISTRY[id]) return { ok: false, discovered: false };
            if (!isFinite(amount) || amount === 0) return { ok: false, discovered: false };
            if (!progress.resources) progress.resources = {};
            const cur = progress.resources[id] || 0;
            progress.resources[id] = Math.max(0, cur + amount);
            let discovered = false;
            if (!progress.discoveredResources) progress.discoveredResources = [];
            if (!progress.discoveredResources.includes(id) && !RESOURCE_REGISTRY[id].isPrimary) {
                progress.discoveredResources.push(id);
                discovered = true;
            }
            return { ok: true, discovered };
        },

        canAfford(progress, cost) {
            if (!cost) return true;
            for (const k of Object.keys(cost)) {
                if (!RESOURCE_REGISTRY[k]) return false;
                if ((progress.resources[k] || 0) < cost[k]) return false;
            }
            return true;
        },

        spend(progress, cost) {
            if (!this.canAfford(progress, cost)) return false;
            for (const k of Object.keys(cost)) {
                progress.resources[k] = Math.max(0, (progress.resources[k] || 0) - cost[k]);
            }
            return true;
        },

        getValue(progress, id) {
            if (!progress.resources) return 0;
            return progress.resources[id] || 0;
        }
    };

    // ═══════════════════════════════════════════
    // UNLOCK EVALUATOR
    // ═══════════════════════════════════════════
    const MAX_EVAL_DEPTH = 8;

    const UnlockEvaluator = {
        _evaluators: {
            depth: function (cond, progress) {
                const areaDeps = (progress.achievements && progress.achievements.maxDepth_per_area) || {};
                return (areaDeps[cond.areaId] || 0) >= cond.value;
            },
            resource: function (cond, progress) {
                return (progress.resources && progress.resources[cond.resourceId] || 0) >= cond.value;
            },
            resource_total: function (cond, progress) {
                const total = (progress.achievements && progress.achievements.totalEarned &&
                    progress.achievements.totalEarned[cond.resourceId]) || 0;
                return total >= cond.value;
            },
            rocks_destroyed: function (cond, progress) {
                return ((progress.achievements && progress.achievements.rocks_destroyed) || 0) >= cond.value;
            },
            runs_completed: function (cond, progress) {
                return ((progress.achievements && progress.achievements.runs_completed) || 0) >= cond.value;
            },
            minit_owned: function (cond, progress) {
                return progress.unlockedMinits.includes(cond.minitId);
            }
        },

        evaluate(condition, progress, depth) {
            if (depth === undefined) depth = 0;
            if (!condition) return true;
            if (depth >= MAX_EVAL_DEPTH) {
                console.warn('[UnlockEvaluator] Max depth:', condition.type);
                return false;
            }
            const type = condition.type;

            if (type === 'all_of') {
                if (!Array.isArray(condition.conditions)) return false;
                for (const c of condition.conditions) {
                    if (!this.evaluate(c, progress, depth + 1)) return false;
                }
                return true;
            }
            if (type === 'any_of') {
                if (!Array.isArray(condition.conditions)) return false;
                for (const c of condition.conditions) {
                    if (this.evaluate(c, progress, depth + 1)) return true;
                }
                return false;
            }

            const fn = this._evaluators[type];
            if (!fn) {
                console.warn(`[UnlockEvaluator] Unknown: ${type}`);
                return false;
            }
            try { return fn.call(this, condition, progress); }
            catch (e) {
                console.warn(`[UnlockEvaluator] Error on ${type}:`, e);
                return false;
            }
        },

        checkAreaUnlocks(progress) {
            const newlyUnlocked = [];
            for (const areaId of Object.keys(AREA_REGISTRY)) {
                if (progress.unlockedAreas.includes(areaId)) continue;
                const area = AREA_REGISTRY[areaId];
                if (!area.unlock) { newlyUnlocked.push(areaId); continue; }
                if (this.evaluate(area.unlock, progress)) newlyUnlocked.push(areaId);
            }
            return newlyUnlocked;
        },

        checkMinitAchievementUnlocks(progress) {
            const newlyUnlocked = [];
            for (const minitId of Object.keys(MINIT_UNLOCK_REGISTRY)) {
                if (progress.unlockedMinits.includes(minitId)) continue;
                const unlock = MINIT_UNLOCK_REGISTRY[minitId];
                if (unlock.method !== 'achievement') continue;
                if (this.evaluate(unlock.condition, progress)) newlyUnlocked.push(minitId);
            }
            return newlyUnlocked;
        },

        checkAchievements(progress) {
            const newlyCompleted = [];
            for (const achId of Object.keys(ACHIEVEMENT_REGISTRY)) {
                if (progress.completedAchievements.includes(achId)) continue;
                const ach = ACHIEVEMENT_REGISTRY[achId];
                if (this.evaluate(ach.condition, progress)) newlyCompleted.push(achId);
            }
            return newlyCompleted;
        }
    };

    // ═══════════════════════════════════════════
    // AREA HELPERS
    // ═══════════════════════════════════════════
    const AreaHelpers = {
        getArea(id) { return AREA_REGISTRY[id] || null; },
        getAllAreas() { return Object.values(AREA_REGISTRY); },
        getAreaIds() { return Object.keys(AREA_REGISTRY); },
        getFirstUnlocked(progress) {
            for (const areaId of Object.keys(AREA_REGISTRY)) {
                if (progress.unlockedAreas.includes(areaId)) return areaId;
            }
            return 'common_vein';
        },
        getNextArea(currentId) {
            const ids = Object.keys(AREA_REGISTRY);
            const idx = ids.indexOf(currentId);
            return ids[(idx + 1) % ids.length];
        },
        getPrevArea(currentId) {
            const ids = Object.keys(AREA_REGISTRY);
            const idx = ids.indexOf(currentId);
            return ids[(idx - 1 + ids.length) % ids.length];
        },
        getUnlockDescription(area) {
            if (!area.unlock) return 'Always available';
            return this.describeCondition(area.unlock);
        },
        describeCondition(cond) {
            if (!cond) return 'Always available';
            switch (cond.type) {
                case 'depth':
                    return `Reach depth ${cond.value} in ${(AREA_REGISTRY[cond.areaId] && AREA_REGISTRY[cond.areaId].name) || cond.areaId}`;
                case 'resource':
                    return `Have ${cond.value} ${(RESOURCE_REGISTRY[cond.resourceId] && RESOURCE_REGISTRY[cond.resourceId].label) || cond.resourceId}`;
                case 'resource_total':
                    return `Collect ${cond.value} ${cond.resourceId} total`;
                case 'rocks_destroyed':
                    return `Destroy ${cond.value} rocks`;
                case 'runs_completed':
                    return `Complete ${cond.value} runs`;
                case 'minit_owned':
                    return `Own minit: ${cond.minitId}`;
                case 'all_of':
                    return cond.conditions.map(c => this.describeCondition(c)).join(' + ');
                case 'any_of':
                    return cond.conditions.map(c => this.describeCondition(c)).join(' OR ');
                default:
                    return 'Unknown condition';
            }
        }
    };

    MD.MM.Registry = {
        RESOURCE_REGISTRY,
        AREA_REGISTRY,
        MINIT_UNLOCK_REGISTRY,
        LOOTBOX_POOLS,
        ACHIEVEMENT_REGISTRY,
        UnlockEvaluator,
        AreaHelpers,
        ResourceRegistry,
        getArea: (id) => AreaHelpers.getArea(id),
        getResource: (id) => ResourceRegistry.get(id)
    };
})();