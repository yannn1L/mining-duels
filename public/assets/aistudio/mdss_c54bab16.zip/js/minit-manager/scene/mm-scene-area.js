// ==========================================
// MINIT MANAGER — AREA SELECT VIEW
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-scene-area] deps not met');
    if (!MD.MM || !MD.MM.Config || !MD.MM.Registry || !MD.MM.UI) throw new Error('[mm-scene-area] deps not met');

    const { CFG, PALETTE, FastMath, AudioSys, Textures, UI_STYLE } = MD;
    const { Config, Registry, ProgressService } = MD.MM;
    const { ResourceRegistry } = Registry;
    const { MMUI } = MD.MM.UI;
    const P = Config.PALETTE;
    const LC = Config.LAYOUT_CONST;

    // Static preview cache
    const _previewCache = {};

    class AreaSelectView extends PIXI.Container {
        constructor(scene) {
            super();
            this.scene = scene;
            this.currentAreaId = scene.progress.currentAreaId || 'common_vein';
            this._build();
        }

        _build() {
            this.removeChildren();
            const progress = this.scene.progress;
            const area = Registry.getArea(this.currentAreaId);
            if (!area) return;
            const isUnlocked = progress.unlockedAreas.includes(this.currentAreaId);

            const VEIN = Config.VEIN;
            const AC = LC.AREA_SELECT;
            const arenaW = VEIN.COLS * VEIN.TS;
            const arenaH = VEIN.ROWS * VEIN.TS;
            const previewScale = AC.PREVIEW_SCALE;
            const previewW = arenaW * previewScale;
            const previewH = arenaH * previewScale;
            const centerX = CFG.APP.W / 2;
            const previewY = AC.PREVIEW_Y;

            const previewBox = new PIXI.Graphics()
                .beginFill(P.PANEL_BG)
                .lineStyle(2, isUnlocked ? PALETTE.NEON : 0x555555)
                .drawRect(centerX - previewW / 2, previewY, previewW, previewH).endFill();
            this.addChild(previewBox);

            const previewInner = this._makePreview(area, previewW, previewH);
            previewInner.position.set(centerX - previewW / 2, previewY);
            this.addChild(previewInner);

            if (!isUnlocked && Textures['icon_lock']) {
                const lockIcon = new PIXI.Sprite(Textures['icon_lock']);
                lockIcon.anchor.set(0.5);
                lockIcon.position.set(centerX, previewY + previewH / 2);
                lockIcon.scale.set(2);
                this.addChild(lockIcon);
            }

            const swapY = previewY + previewH / 2 - AC.SWAP_BTN_SIZE / 2;
            this.prevBtn = MMUI.makeIconButton('icon_arrow_left', AC.SWAP_BTN_SIZE, AC.SWAP_BTN_SIZE,
                () => this._swap(-1), { borderColor: 0x00ccff });
            this.prevBtn.position.set(centerX - previewW / 2 - AC.SWAP_BTN_SIZE - AC.SWAP_BTN_GAP, swapY);
            this.addChild(this.prevBtn);

            this.nextBtn = MMUI.makeIconButton('icon_arrow_right', AC.SWAP_BTN_SIZE, AC.SWAP_BTN_SIZE,
                () => this._swap(1), { borderColor: 0x00ccff });
            this.nextBtn.position.set(centerX + previewW / 2 + AC.SWAP_BTN_GAP, swapY);
            this.addChild(this.nextBtn);

            const areaName = new PIXI.Text(area.name, UI_STYLE.MM_AREA_NAME);
            areaName.anchor.set(0.5, 0);
            areaName.position.set(centerX, previewY + AC.NAME_OFF_Y);
            this.addChild(areaName);

            const descY = previewY + previewH + AC.DESC_OFF_Y;
            const unlockDesc = Registry.AreaHelpers.getUnlockDescription(area);
            const dropsStr = (area.drops || []).map(d => {
                const r = ResourceRegistry.get(d.id);
                return r ? r.label : d.id;
            }).join(', ');
            const info = new PIXI.Text(
                `Unlock: ${unlockDesc}\n` +
                `Duration: ${area.duration}s · Max depth: ${area.maxDepth}\n` +
                `Drops: ${dropsStr}\n` +
                `${area.desc}`,
                UI_STYLE.MM_INFO_CENTERED
            );
            info.anchor.set(0.5, 0);
            info.position.set(centerX, descY);
            this.addChild(info);

            const playY = descY + AC.PLAY_OFF_Y;
            if (isUnlocked) {
                this.playBtn = MMUI.makeButton("PLAY", AC.PLAY_BTN_W, AC.PLAY_BTN_H,
                    () => this.scene.startRun(area),
                    { style: UI_STYLE.MM_BTN_PRIMARY, borderColor: 0x44ff88, fill: '#88ffaa', bgColor: 0x1a3a1a });
                if (Textures['icon_play']) {
                    const playIcon = new PIXI.Sprite(Textures['icon_play']);
                    playIcon.anchor.set(0.5);
                    playIcon.position.set(-55, AC.PLAY_BTN_H / 2);
                    playIcon.scale.set(0.8);
                    this.playBtn.addChild(playIcon);
                    this.playBtn._label.x = 12;
                }
            } else {
                this.playBtn = MMUI.makeButton("LOCKED", AC.PLAY_BTN_W, AC.PLAY_BTN_H,
                    () => { try { AudioSys.play('hit', 0.5); } catch (e) {} },
                    { style: UI_STYLE.MM_BTN_PRIMARY, borderColor: 0x555555, fill: '#888888', bgColor: 0x222222 });
            }
            this.playBtn.position.set(centerX - AC.PLAY_BTN_W / 2, playY);
            this.addChild(this.playBtn);
        }

        /**
         * Preview pakai rock texture asli dari AssetBaker.
         * Cached per area + size.
         */
        _makePreview(area, boxW, boxH) {
            const cacheKey = `${area.id}_${boxW}x${boxH}`;
            if (_previewCache[cacheKey]) {
                return new PIXI.Sprite(_previewCache[cacheKey]);
            }

            const cols = Config.VEIN.COLS;
            const rows = Config.VEIN.ROWS;
            const ts = boxW / cols;

            const tempCont = new PIXI.Container();

            // Deterministic RNG
            const seed = area.id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
            let s = seed;
            const rng = () => {
                s = (s * 1664525 + 1013904223) | 0;
                return ((s >>> 0) / 4294967296);
            };

            const density = (area.preset && area.preset.density) || 1.0;

            for (let y = 0; y < rows; y++) {
                for (let x = 0; x < cols; x++) {
                    if (rng() < density * 0.85) {
                        const rockIdx = Math.min(4, (y / 6) | 0);
                        const texKey = `rock_${area.id}_${rockIdx}`;
                        const tex = Textures[texKey] || Textures[`rock_${rockIdx}`];
                        if (!tex) continue;
                        const spr = new PIXI.Sprite(tex);
                        spr.x = x * ts;
                        spr.y = y * ts;
                        spr.width = ts;
                        spr.height = ts;
                        spr.alpha = 0.85 + rng() * 0.15;
                        tempCont.addChild(spr);
                    }
                }
            }

            // Render ke RenderTexture
            const rt = PIXI.RenderTexture.create({
                width: boxW,
                height: boxH,
                scaleMode: PIXI.SCALE_MODES.NEAREST
            });
            MD.app.renderer.render(tempCont, { renderTexture: rt });
            tempCont.destroy({ children: true });

            _previewCache[cacheKey] = rt;
            return new PIXI.Sprite(rt);
        }

        _swap(dir) {
            const ids = Registry.AreaHelpers.getAreaIds();
            let idx = ids.indexOf(this.currentAreaId);
            idx = (idx + dir + ids.length) % ids.length;
            this.currentAreaId = ids[idx];
            this.scene.progress.currentAreaId = this.currentAreaId;
            this.scene.progress.markDirty();
            ProgressService.scheduleAutosave();
            try { AudioSys.play('click'); } catch (e) {}
            this._build();
        }

        /**
         * Clear preview cache — call kalau rock texture berubah.
         */
        static clearCache() {
            for (const k of Object.keys(_previewCache)) {
                try { _previewCache[k].destroy(true); } catch (e) {}
                delete _previewCache[k];
            }
        }
    }

    MD.MM.AreaSelectView = AreaSelectView;
})();