// ==========================================
// MINIT MANAGER — SQUAD MODAL
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-scene-squad] deps not met');
    if (!MD.MM || !MD.MM.Config || !MD.MM.Registry || !MD.MM.UI) throw new Error('[mm-scene-squad] deps not met');

    const { CFG, PALETTE, AudioSys, Textures, MINIT_DB, UI_STYLE } = MD;
    const { Config, Registry, ProgressService, ProgressOps } = MD.MM;
    const { ResourceRegistry } = Registry;
    const { MMUI } = MD.MM.UI;
    const P = Config.PALETTE;
    const LC = Config.LAYOUT_CONST;

    /**
     * Buka squad modal.
     * @param {MinitsManagerScene} scene
     */
    function openSquadModal(scene) {
        if (scene._pickerOverlay) return;
        const overlay = new PIXI.Container();
        overlay.interactive = true;

        const backdrop = new PIXI.Graphics()
            .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
            .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
        backdrop.interactive = true;
        overlay.addChild(backdrop);

        const S = LC.MODAL_SQUAD;
        const panelX = (CFG.APP.W - S.W) / 2;
        const panelY = (CFG.APP.H - S.H) / 2;

        overlay.addChild(new PIXI.Graphics()
            .beginFill(P.PANEL_BG).lineStyle(2, 0x00ccff)
            .drawRect(panelX, panelY, S.W, S.H).endFill());

        const title = new PIXI.Text("SQUAD MANAGER", UI_STYLE.MM_MODAL_TITLE);
        title.anchor.set(0.5, 0);
        title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
        overlay.addChild(title);

        const slotPreviewY = panelY + S.SLOT_PREVIEW_Y;
        const slotPreviewCont = new PIXI.Container();
        overlay.addChild(slotPreviewCont);

        const info = new PIXI.Text("", UI_STYLE.MM_INFO);
        info.anchor.set(0.5, 0);
        info.position.set(CFG.APP.W / 2, slotPreviewY + S.SLOT_PREVIEW_H + 8);
        overlay.addChild(info);

        // Grid area
        const gridX = panelX + 20;
        const gridY = panelY + S.LIST_Y;
        const gridW = S.W - 40;
        const gridH = S.H - S.LIST_Y - 60;

        const scrollArea = MMUI.makeScrollArea(overlay, gridX, gridY, gridW, gridH);
        const gridContent = scrollArea.content;

        const renderSlotPreview = () => {
            slotPreviewCont.removeChildren();
            const count = scene.progress.slotCount;
            const gap = S.SLOT_PREVIEW_GAP;
            const totalW = count * S.SLOT_PREVIEW_W + (count - 1) * gap;
            const startX = CFG.APP.W / 2 - totalW / 2;

            for (let i = 0; i < count; i++) {
                const minitId = scene.progress.squad[i];
                const isActive = (i === scene.activeSlotIdx);
                const slot = new PIXI.Container();
                slot.position.set(startX + i * (S.SLOT_PREVIEW_W + gap), slotPreviewY);
                slot.interactive = slot.buttonMode = true;
                slot.hitArea = new PIXI.Rectangle(0, 0, S.SLOT_PREVIEW_W, S.SLOT_PREVIEW_H);

                const borderColor = isActive ? P.SLOT_ACTIVE : P.SLOT_IDLE;
                const bg = new PIXI.Graphics()
                    .beginFill(P.SLOT_BG)
                    .lineStyle(isActive ? 2 : 1, borderColor)
                    .drawRect(0, 0, S.SLOT_PREVIEW_W, S.SLOT_PREVIEW_H).endFill();
                slot.addChild(bg);

                if (minitId && Textures[`minit_${minitId}_base`]) {
                    const icon = new PIXI.Sprite(Textures[`minit_${minitId}_base`]);
                    icon.anchor.set(0.5);
                    icon.scale.set(2);
                    icon.position.set(S.SLOT_PREVIEW_W / 2, 30);
                    slot.addChild(icon);
                    const md = MINIT_DB[minitId];
                    const nm = new PIXI.Text(md ? md.name : minitId, UI_STYLE.MM_LABEL_TINY);
                    nm.anchor.set(0.5, 0);
                    nm.position.set(S.SLOT_PREVIEW_W / 2, 56);
                    slot.addChild(nm);
                } else if (Textures['icon_plus']) {
                    const plus = new PIXI.Sprite(Textures['icon_plus']);
                    plus.anchor.set(0.5);
                    plus.position.set(S.SLOT_PREVIEW_W / 2, S.SLOT_PREVIEW_H / 2 - 8);
                    plus.scale.set(1.2);
                    slot.addChild(plus);
                    const lbl = new PIXI.Text("EMPTY", UI_STYLE.MM_LABEL_TINY);
                    lbl.anchor.set(0.5, 0);
                    lbl.position.set(S.SLOT_PREVIEW_W / 2, 60);
                    slot.addChild(lbl);
                }

                slot.on('pointerdown', (e) => {
                    e.stopPropagation();
                    if (minitId) {
                        toggleMember(minitId);
                        renderSlotPreview();
                        renderGrid();
                        updateInfo();
                    }
                });

                slotPreviewCont.addChild(slot);
            }
        };

        const updateInfo = () => {
            info.text = `Slots: ${scene.progress.squad.length} / ${scene.progress.slotCount}` +
                `  ·  Unlocked: ${scene.progress.unlockedMinits.length}`;
        };

        const toggleMember = (minitId) => {
            const squad = scene.progress.squad.slice();
            const idx = squad.indexOf(minitId);
            if (idx >= 0) {
                squad.splice(idx, 1);
            } else {
                if (squad.length >= scene.progress.slotCount) {
                    try { AudioSys.play('hit', 0.5); } catch (e) {}
                    scene.toastMgr.push({
                        type: 'achievement',
                        title: 'SQUAD FULL',
                        subtitle: `Max ${scene.progress.slotCount} minits`
                    });
                    scene._bringToastToFront();
                    return;
                }
                squad.push(minitId);
            }
            scene.progress.squad = squad;
            scene.progress.markDirty();
            ProgressService.scheduleAutosave();
            scene._buildSquadSlots();
        };

        const renderGrid = () => {
            gridContent.removeChildren();
            const unlockedIds = scene.progress.unlockedMinits;
            const COLS = S.COLS;
            const cardW = (gridW - (COLS - 1) * S.ROW_GAP) / COLS;

            unlockedIds.forEach((minitId, i) => {
                const col = i % COLS;
                const row = Math.floor(i / COLS);
                const x = col * (cardW + S.ROW_GAP);
                const y = row * (S.ROW_H + S.ROW_GAP);
                const inSquad = scene.progress.squad.includes(minitId);

                const card = new PIXI.Container();
                card.position.set(x, y);

                const bg = new PIXI.Graphics()
                    .beginFill(inSquad ? P.SLOT_IN_SQUAD : P.SLOT_BG)
                    .lineStyle(inSquad ? 2 : 1, inSquad ? P.SLOT_ACTIVE : P.PANEL_BORDER)
                    .drawRect(0, 0, cardW, S.ROW_H).endFill();
                card.addChild(bg);

                const md = MINIT_DB[minitId];
                if (Textures[`minit_${minitId}_base`]) {
                    const icon = new PIXI.Sprite(Textures[`minit_${minitId}_base`]);
                    icon.anchor.set(0.5);
                    icon.scale.set(1.6);
                    icon.position.set(S.ICON_X, S.ROW_H / 2 - 4);
                    card.addChild(icon);
                }

                const name = new PIXI.Text(md ? md.name : minitId, {
                    ...UI_STYLE.MM_SECTION, fontSize: 9,
                    fill: inSquad ? '#00ccff' : PALETTE.TEXT
                });
                name.position.set(S.TEXT_X, 10);
                card.addChild(name);

                const desc = new PIXI.Text(md ? (md.desc || '').slice(0, 45) : '', {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 6,
                    wordWrap: true, wordWrapWidth: cardW - S.TEXT_X - 8
                });
                desc.position.set(S.TEXT_X, 26);
                card.addChild(desc);

                const btnText = inSquad ? "REMOVE" : "ADD";
                const btnColor = inSquad ? 0xff8866 : 0x44ff88;
                const btnFill = inSquad ? '#ffaa88' : '#88ffaa';
                const btnBg = inSquad ? 0x3a1a1a : 0x1a3a1a;

                const btn = MMUI.makeButton(btnText, cardW - 16, 24, () => {
                    toggleMember(minitId);
                    renderGrid();
                    renderSlotPreview();
                    updateInfo();
                }, {
                    style: UI_STYLE.MM_BTN_TINY,
                    fontSize: 8,
                    borderColor: btnColor,
                    fill: btnFill,
                    bgColor: btnBg
                });
                btn.position.set(8, S.ROW_H - 28);
                btn.on('pointerdown', (e) => e.stopPropagation());
                card.addChild(btn);

                gridContent.addChild(card);
            });

            const rows = Math.ceil(unlockedIds.length / COLS);
            const totalH = rows * (S.ROW_H + S.ROW_GAP);
            scrollArea.setMaxScroll(Math.max(0, totalH - gridH));
        };

        renderSlotPreview();
        updateInfo();
        renderGrid();

        // ── Tombol Upgrade Slot (top-right) ──
        const isSlotMaxed = scene.progress.slotCount >= Config.SQUAD.MAX_SIZE;
        if (!isSlotMaxed) {
            const nextSlotIdx = scene.progress.slotCount;
            const cost = Config.SLOT_UNLOCK_COSTS[nextSlotIdx];
            const canAfford = cost && ProgressOps.canAfford(scene.progress, cost);

            const slotBtn = MMUI.makeButton(
                `+ SLOT ${scene.progress.slotCount + 1}`,
                S.UPGRADE_SLOT_BTN_W, S.UPGRADE_SLOT_BTN_H,
                () => {
                    scene._onSlotClick(nextSlotIdx);
                    // Rebuild modal (full refresh)
                    if (overlay.parent) overlay.parent.removeChild(overlay);
                    overlay.destroy({ children: true });
                    scene._pickerOverlay = null;
                    openSquadModal(scene);
                },
                {
                    style: UI_STYLE.MM_BTN_TINY,
                    fontSize: 8,
                    borderColor: canAfford ? 0x44ff88 : 0x444444,
                    fill: canAfford ? '#88ffaa' : '#888888',
                    bgColor: canAfford ? 0x1a3a1a : 0x222222
                }
            );
            slotBtn.position.set(panelX + S.W - S.UPGRADE_SLOT_BTN_W - S.UPGRADE_SLOT_BTN_PAD,
                panelY + LC.MODAL.TITLE_Y - 4);
            overlay.addChild(slotBtn);
        }

        const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
            if (overlay.parent) overlay.parent.removeChild(overlay);
            overlay.destroy({ children: true });
            if (scene._pickerOverlay === overlay) scene._pickerOverlay = null;
        }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
        closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + S.H - LC.MODAL.CLOSE_BTN_BOTTOM);
        overlay.addChild(closeBtn);

        scene._pickerOverlay = overlay;
        scene.addChild(overlay);
        scene._bringToastToFront();
    }

    MD.MM.openSquadModal = openSquadModal;
})();