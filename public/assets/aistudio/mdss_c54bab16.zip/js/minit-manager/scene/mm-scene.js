// ==========================================
// MINIT MANAGER — SCENE (CORE)
// ==========================================
// Main scene: area select → running → summary loop.
// Modals di mm-scene-modals.js. Squad di mm-scene-squad.js.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-scene] deps not met');
    if (!MD.MM || !MD.MM.Config) throw new Error('[mm-scene] mm-config.js must load first');
    if (!MD.MM.Registry) throw new Error('[mm-scene] mm-registry.js must load first');
    if (!MD.MM.ProgressService) throw new Error('[mm-scene] mm-progress.js must load first');
    if (!MD.MM.UI) throw new Error('[mm-scene] mm-ui.js must load first');
    if (!MD.MM.AreaSelectView) throw new Error('[mm-scene] mm-scene-area.js must load first');

    const { CFG, PALETTE, FastMath, AudioSys, Textures, MINIT_DB, UI_STYLE } = MD;
    const { Config, Registry, ProgressService, ProgressOps, UpgradeApply } = MD.MM;
    const { ResourceRegistry } = Registry;
    const { MMUI, ToastManager } = MD.MM.UI;
    const P = Config.PALETTE;
    const LC = Config.LAYOUT_CONST;

    class MinitsManagerScene extends PIXI.Container {
        constructor() {
            super();

            const progress = ProgressService.tryGet();
            if (!progress) {
                console.error('[MinitsManagerScene] Progress not loaded — should use LoadingOverlayScene');
                const errorText = new PIXI.Text("ERROR: Progress not loaded", UI_STYLE.MM_TITLE);
                errorText.anchor.set(0.5);
                errorText.position.set(CFG.APP.W / 2, CFG.APP.H / 2);
                this.addChild(errorText);
                setTimeout(() => MD.setScene(new MD.MenuScene()), 1500);
                return;
            }
            this.progress = progress;

            this.state = 'idle';
            this.arena = null;
            this.arenaGroup = new PIXI.Container();
            this.uiGroup = new PIXI.Container();
            this.toastGroup = new PIXI.Container();
            this.addChild(this.arenaGroup, this.uiGroup, this.toastGroup);

            this.toastMgr = new ToastManager(this.toastGroup);
            this.runContext = null;
            this.activeSlotIdx = 0;
            this._summaryModal = null;
            this._upgOverlay = null;
            this._lootOverlay = null;
            this._craftOverlay = null;
            this._achOverlay = null;
            this._pickerOverlay = null;
            this._pendingUnlock = null;

            this._buildBaseUI();
            this._buildAreaSelect();

            this._onResize = () => this._layout();
            window.addEventListener('resize', this._onResize);
            this._layout();
        }

        _bringToastToFront() {
            if (this.children.indexOf(this.toastGroup) !== this.children.length - 1) {
                this.removeChild(this.toastGroup);
                this.addChild(this.toastGroup);
            }
        }

        // ═══ BASE UI ═══
        _buildBaseUI() {
            this.title = new PIXI.Text("MINITS MANAGER", UI_STYLE.MM_TITLE);
            this.title.anchor.set(0.5, 0);
            this.uiGroup.addChild(this.title);

            this.backBtn = MMUI.makeButton("MENU", 80, 22, async () => {
                this.state = 'idle';
                await ProgressService.saveNow();
                MD.setScene(new MD.MenuScene());
            }, { borderColor: 0x888888, fill: '#aaaaaa', style: UI_STYLE.MM_BTN_TINY });
            this.uiGroup.addChild(this.backBtn);

            this.timeBarBg = new PIXI.Graphics();
            this.timeBarFill = new PIXI.Graphics();
            this.timeText = new PIXI.Text("", UI_STYLE.MM_TIMER);
            this.timeText.anchor.set(0.5, 0);
            this.timeBarBg.visible = false;
            this.timeBarFill.visible = false;
            this.timeText.visible = false;
            this.uiGroup.addChild(this.timeBarBg, this.timeBarFill, this.timeText);

            this.resourcePanel = new PIXI.Container();
            this.uiGroup.addChild(this.resourcePanel);
            this._buildResourcePanel();

            this.rightPanel = new PIXI.Container();
            this.uiGroup.addChild(this.rightPanel);
            this._buildRightPanel();

            this.bottomPanel = new PIXI.Container();
            this.uiGroup.addChild(this.bottomPanel);
            this._buildBottomPanel();
        }

        _buildResourcePanel() {
            this.resourcePanel.removeChildren();
            const title = new PIXI.Text("RESOURCES", UI_STYLE.MM_SECTION);
            title.position.set(0, LC.LEFT_PANEL.TITLE_Y);
            this.resourcePanel.addChild(title);
            this.resourceRows = {};
            this.resourceIcons = {};
            // FIX: trigger update langsung
            this._updateResourcePanel();
        }

        _rebuildResourceRows() {
            if (!this.progress) return;
            const keepTitle = this.resourcePanel.children[0];
            this.resourcePanel.removeChildren();
            if (keepTitle) this.resourcePanel.addChild(keepTitle);
            this.resourceRows = {};
            this.resourceIcons = {};

            const discovered = ResourceRegistry.getDiscovered(this.progress);
            const maxPrimary = LC.LEFT_PANEL.MAX_PRIMARY;
            const toShow = discovered.slice(0, maxPrimary + 4);

            let y = LC.LEFT_PANEL.ROW_START;
            const R = LC.LEFT_PANEL;

            for (const res of toShow) {
                const iconTex = Textures[res.iconTexture];
                if (iconTex) {
                    const icon = new PIXI.Sprite(iconTex);
                    icon.anchor.set(0, 0);
                    icon.position.set(0, y);
                    icon.scale.set(R.ICON_SCALE);
                    this.resourcePanel.addChild(icon);
                    this.resourceIcons[res.id] = icon;
                }

                const label = new PIXI.Text(res.label, UI_STYLE.MM_LABEL_TINY);
                label.position.set(R.LABEL_X, y + R.LABEL_GAP);
                this.resourcePanel.addChild(label);

                const value = new PIXI.Text("0", {
                    ...UI_STYLE.MM_VALUE_MED,
                    fill: '#' + res.color.toString(16).padStart(6, '0')
                });
                value.position.set(R.LABEL_X, y + R.VALUE_Y_OFF);
                this.resourcePanel.addChild(value);

                this.resourceRows[res.id] = value;
                y += R.ROW_H;
            }
        }

        _updateResourcePanel() {
            if (!this.progress) return;
            const discovered = ResourceRegistry.getDiscovered(this.progress);
            const currentIds = Object.keys(this.resourceRows);
            const discoveredIds = discovered.slice(0, LC.LEFT_PANEL.MAX_PRIMARY + 4).map(r => r.id);
            if (currentIds.length !== discoveredIds.length ||
                !currentIds.every((id, i) => id === discoveredIds[i])) {
                this._rebuildResourceRows();
            }
            for (const key of Object.keys(this.resourceRows)) {
                const node = this.resourceRows[key];
                if (!node) continue;
                const v = (this.progress.resources[key] || 0) +
                    (this.runContext ? (this.runContext.sessionResources[key] || 0) : 0);
                const text = v < 100 ? v.toFixed(v < 10 ? 1 : 0) : String(Math.floor(v));
                if (node.text !== text) node.text = text;
            }
        }

        _buildRightPanel() {
            this.rightPanel.removeChildren();
            const R = LC.RIGHT_PANEL;
            let y = 0;
        
            const addBtn = (iconKey, labelText, onClick, borderColor) => {
                const btn = MMUI.makeIconButton(iconKey, R.BTN_W, R.BTN_H, onClick,
                    { borderColor: borderColor });
                btn.position.set(0, y);
                this.rightPanel.addChild(btn);
                const lbl = new PIXI.Text(labelText, UI_STYLE.MM_BTN_TINY);
                lbl.anchor.set(0.5, 0);
                // FIX: label pakai `y + R.BTN_H + R.LABEL_GAP`, bukan konstanta
                lbl.position.set(R.BTN_W / 2, y + R.BTN_H + R.LABEL_GAP);
                this.rightPanel.addChild(lbl);
                y += R.BTN_H + R.BTN_GAP + R.LABEL_GAP * 2;
            };

            addBtn('icon_hex', 'SQUAD', () => MD.MM.openSquadModal(this), 0x00ccff);
            addBtn('icon_lightning', 'UPGRADE', () => MD.MM.openUpgradeModal(this), 0x00ccff);
            addBtn('icon_hammer', 'CRAFT', () => MD.MM.openCraftModal(this), 0xcc88ff);
            addBtn('icon_box', 'LOOTBOX', () => MD.MM.openLootboxModal(this), 0xffcc00);
            addBtn('icon_trophy', 'TROPHY', () => MD.MM.openAchievementModal(this), 0xffcc44);
        }

        _buildBottomPanel() {
            this.bottomPanel.removeChildren();
            this.squadSlots = new PIXI.Container();
            this.bottomPanel.addChild(this.squadSlots);
            this._buildSquadSlots();
        }

        _buildSquadSlots() {
            if (!this.squadSlots || !this.progress) return;
            this.squadSlots.removeChildren();
            const B = LC.BOTTOM_BAR;
            const count = this.progress.slotCount;
            const totalW = count * B.SLOT_W + (count - 1) * B.SLOT_GAP;
            const startX = -totalW / 2;

            for (let i = 0; i < count; i++) {
                const minitId = this.progress.squad[i];
                const isActive = (i === this.activeSlotIdx);
                const slot = new PIXI.Container();
                slot.position.set(startX + i * (B.SLOT_W + B.SLOT_GAP), 0);
                slot.interactive = slot.buttonMode = true;
                slot.hitArea = new PIXI.Rectangle(0, 0, B.SLOT_W, B.SLOT_H);

                const borderColor = isActive ? P.SLOT_ACTIVE : P.SLOT_IDLE;
                const bg = new PIXI.Graphics()
                    .beginFill(P.SLOT_BG)
                    .lineStyle(isActive ? 2 : 1, borderColor)
                    .drawRect(0, 0, B.SLOT_W, B.SLOT_H).endFill();
                slot.addChild(bg);

                if (minitId && Textures[`minit_${minitId}_base`]) {
                    const icon = new PIXI.Sprite(Textures[`minit_${minitId}_base`]);
                    icon.anchor.set(0.5);
                    icon.scale.set(1.4);
                    icon.position.set(B.SLOT_W / 2, B.SLOT_H / 2);
                    slot.addChild(icon);
                } else if (Textures['icon_plus']) {
                    const plus = new PIXI.Sprite(Textures['icon_plus']);
                    plus.anchor.set(0.5);
                    plus.position.set(B.SLOT_W / 2, B.SLOT_H / 2);
                    slot.addChild(plus);
                }

                const num = new PIXI.Text(String(i + 1), UI_STYLE.MM_LABEL_TINY);
                num.position.set(B.SLOT_NUM_OFF, B.SLOT_NUM_OFF);
                slot.addChild(num);

                slot.on('pointerdown', () => this._onSlotClick(i));
                this.squadSlots.addChild(slot);
            }
        }

        _onSlotClick(idx) {
            if (!this.progress) return;
            if (idx >= this.progress.squad.length) {
                const cost = Config.SLOT_UNLOCK_COSTS[idx];
                if (cost && ProgressOps.canAfford(this.progress, cost)) {
                    if (this._pendingUnlock !== 'slot_' + idx) {
                        this._pendingUnlock = 'slot_' + idx;
                        const costStr = Object.keys(cost).map(k =>
                            `${cost[k]} ${(ResourceRegistry.get(k) || {}).label || k}`
                        ).join(' + ');
                        this.toastMgr.push({
                            type: 'achievement',
                            title: 'PRESS AGAIN TO UNLOCK',
                            subtitle: `Slot ${idx + 1}: ${costStr}`
                        });
                        return;
                    }
                    this._pendingUnlock = null;
                    if (ProgressOps.unlockSlot(this.progress)) {
                        ProgressOps.spend(this.progress, cost);
                        ProgressService.scheduleAutosave();
                        this._buildSquadSlots();
                        this.toastMgr.push({
                            type: 'achievement',
                            title: 'SLOT UNLOCKED',
                            subtitle: `Slot ${idx + 1}`
                        });
                    }
                } else {
                    try { AudioSys.play('hit', 0.5); } catch (e) {}
                }
                return;
            }
            this._pendingUnlock = null;
            this.activeSlotIdx = idx;
            if (this.arena && this.state === 'running') this.arena.setActiveSlot(idx);
            try { AudioSys.play('click'); } catch (e) {}
            this._buildSquadSlots();
        }

        // ═══ AREA SELECT ═══
        _buildAreaSelect() {
            this._destroyAreaSelect();
            this.areaSelect = new MD.MM.AreaSelectView(this);
            this.uiGroup.addChild(this.areaSelect);
        }
        _destroyAreaSelect() {
            if (this.areaSelect) {
                this.uiGroup.removeChild(this.areaSelect);
                this.areaSelect.destroy({ children: true });
                this.areaSelect = null;
            }
        }

        // ═══ RUN ═══
        startRun(area) {
            if (this.state === 'running') return;
            this.state = 'running';
            this._destroyAreaSelect();
            this.timeBarBg.visible = true;
            this.timeBarFill.visible = true;
            this.timeText.visible = true;

            const L = MD.MM.getLayout();
            const VEIN = Config.VEIN;

            const minitIds = this.progress.squad.filter(id => id && MINIT_DB[id]);
            if (minitIds.length === 0) {
                console.warn('[MinitsManager] No valid minits in squad');
                this.state = 'idle';
                this._buildAreaSelect();
                return;
            }

            const minitDataOverrides = {};
            for (const id of minitIds) {
                const baseMd = MINIT_DB[id];
                const upgradeState = this.progress.minitUpgrades[id] || {};
                minitDataOverrides[id] = UpgradeApply.applyToMinit(baseMd, upgradeState);
            }

            this.arena = new MD.Arena(minitIds, 2, {
                gridCols: VEIN.COLS,
                gridRows: VEIN.ROWS,
                tileSize: VEIN.TS,
                maxDepth: VEIN.MAX_DEPTH,
                cameraMode: 'active',
                showHUD: false,
                areaId: area.id,
                slotOptions: { minitScale: L.minitScale }
            });

            for (const slot of this.arena.slots) {
                const override = minitDataOverrides[slot.id];
                if (override) slot.md = override;
            }

            this._applyAreaPreset(area);

            const runContext = {
                areaId: area.id,
                duration: area.duration,
                elapsed: 0,
                sessionResources: {},
                rocksDestroyed: 0,
                maxDepthGlobal: 0
            };
            this.runContext = runContext;

            this.arena.onRockDestroyed = (x, y, creditSlot) => {
                if (this.state !== 'running') return;
                const depthMul = 1 + (y / 200);
                const drops = area.drops || [];
                for (const drop of drops) {
                    const res = ResourceRegistry.get(drop.id);
                    if (!res) continue;
                    const rate = (drop.baseRate || 0) + (drop.depthMul || 0) * depthMul;
                    if (rate <= 0) continue;
                    runContext.sessionResources[drop.id] =
                        (runContext.sessionResources[drop.id] || 0) + rate;
                }
                runContext.rocksDestroyed++;
            };

            this.arena.setActiveSlot(this.activeSlotIdx);
            this.arenaGroup.addChild(this.arena);
            this._layout();
            this._updateResourcePanel();
        }

        _applyAreaPreset(area) {
            if (!this.arena) return;
            const VEIN = Config.VEIN;
            const COLS = VEIN.COLS, MAX_DEPTH = VEIN.MAX_DEPTH;
            const preset = area.preset;
            for (let y = 0; y < MAX_DEPTH; y++) {
                for (let x = 0; x < COLS; x++) {
                    const base = preset.baseHP + (y * 3);
                    this.arena.gridHP[y * COLS + x] = Math.max(1, Math.floor(
                        base * preset.density * (0.5 + FastMath.rand() * 0.5)
                    ));
                }
            }
            const cx = (COLS / 2) | 0;
            for (let i = 0; i < this.arena.slots.length; i++) {
                const sx = cx + (i - 1) * 2;
                if (sx >= 0 && sx < COLS) {
                    this.arena.gridHP[0 * COLS + sx] = 0;
                    this.arena.gridHP[1 * COLS + sx] = 0;
                }
            }
            for (const vpb of this.arena.vpBlocks) {
                vpb.dirty = true;
                vpb.lastRockKey = -1;
            }
        }

        endRun(reason) {
            if (this.state !== 'running') return;
            this.state = 'summary';

            const runCtx = this.runContext;
            if (!runCtx) { this.state = 'idle'; return; }
            runCtx.stopReason = reason || 'timer';

            const discovered = ProgressOps.trackRun(this.progress, runCtx);

            const notifications = [];
            for (const resId of discovered) {
                const res = ResourceRegistry.get(resId);
                if (res) notifications.push({
                    type: 'achievement',
                    title: 'NEW RESOURCE',
                    subtitle: res.label
                });
            }
            const unlockNotifs = ProgressOps.processUnlocks(this.progress);
            notifications.push(...unlockNotifs);

            if (this.arena) {
                this.arenaGroup.removeChild(this.arena);
                this.arena.destroy({ children: true });
                this.arena = null;
            }

            ProgressService.scheduleAutosave();
            this._showSummary(runCtx, notifications);

            this.timeBarBg.visible = false;
            this.timeBarFill.visible = false;
            this.timeText.visible = false;
            this.runContext = null;
            this._updateResourcePanel();
        }

        _showSummary(runCtx, notifications) {
            for (const n of notifications) this.toastMgr.push(n);

            const modal = new PIXI.Container();
            modal.interactive = true;

            const backdrop = new PIXI.Graphics()
                .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
                .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
            backdrop.interactive = true;
            modal.addChild(backdrop);

            const panelW = 400, panelH = 320;
            const panelX = (CFG.APP.W - panelW) / 2;
            const panelY = (CFG.APP.H - panelH) / 2;

            const panel = new PIXI.Graphics()
                .beginFill(P.PANEL_BG)
                .lineStyle(2, PALETTE.NEON)
                .drawRect(panelX, panelY, panelW, panelH).endFill();
            modal.addChild(panel);

            const title = new PIXI.Text("RUN SUMMARY", UI_STYLE.MM_MODAL_TITLE);
            title.anchor.set(0.5, 0);
            title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
            modal.addChild(title);

            const lines = [];
            lines.push(`Duration: ${Math.floor(runCtx.elapsed)}s / ${runCtx.duration}s`);
            lines.push(`Stopped: ${runCtx.stopReason}`);
            lines.push('');
            lines.push('Resources earned:');
            for (const key of Object.keys(runCtx.sessionResources)) {
                const res = ResourceRegistry.get(key);
                const v = runCtx.sessionResources[key];
                lines.push(`  ${res ? res.label : key}: +${v.toFixed(1)}`);
            }
            lines.push('');
            lines.push(`Rocks destroyed: ${runCtx.rocksDestroyed}`);
            lines.push(`Max depth: ${runCtx.maxDepthGlobal}`);

            const summary = new PIXI.Text(lines.join('\n'), {
                ...UI_STYLE.MM_INFO, fontSize: 9, lineHeight: 16
            });
            summary.position.set(panelX + 30, panelY + 60);
            modal.addChild(summary);

            const closeBtn = MMUI.makeButton("CONTINUE", 140, 34, () => {
                if (modal.parent) modal.parent.removeChild(modal);
                modal.destroy({ children: true });
                if (this._summaryModal === modal) this._summaryModal = null;
                this.state = 'idle';
                this._buildAreaSelect();
                this._layout();
            }, {
                style: UI_STYLE.MM_BTN_STANDARD,
                borderColor: 0x44ff88, fill: '#88ffaa', bgColor: 0x1a3a1a
            });
            closeBtn.position.set(CFG.APP.W / 2 - 70, panelY + panelH - 50);
            modal.addChild(closeBtn);

            this.addChild(modal);
            this._summaryModal = modal;
            this._bringToastToFront();
        }

        // ═══ LAYOUT ═══
        _layout() {
            if (!this.progress) return;
            const W = CFG.APP.W, H = CFG.APP.H;
            const L = MD.MM.getLayout();

            this.title.position.set(L.title.x, L.title.y);
            this.backBtn.position.set(8, 8);

            this.resourcePanel.position.set(LC.LEFT_PANEL.X, LC.LEFT_PANEL.Y);

            const rightX = W - LC.RIGHT_PANEL.X_OFFSET;
            const rightY = LC.RIGHT_PANEL.Y_START;
            this.rightPanel.position.set(rightX, rightY);

            this.bottomPanel.position.set(0, LC.BOTTOM_BAR.Y);
            if (this.squadSlots) {
                this.squadSlots.position.set(W / 2, LC.BOTTOM_BAR.SQUAD_Y);
            }

            const tbW = L.timer.w, tbH = L.timer.h;
            const tbX = L.timer.x - tbW / 2;
            const tbY = L.timer.y;
            this.timeBarBg.clear()
                .beginFill(0x111111).lineStyle(1, 0x333333)
                .drawRect(tbX, tbY, tbW, tbH).endFill();
            this._tbX = tbX; this._tbY = tbY; this._tbW = tbW; this._tbH = tbH;
            this.timeText.position.set(L.timer.x, tbY + tbH + 4);

            if (this.arena) {
                const VEIN = Config.VEIN;
                const AW = VEIN.COLS * VEIN.TS;
                const AH = VEIN.ROWS * VEIN.TS;
                const scale = L.veinScale;
                this.arena.scale.set(scale);
                let offsetX, offsetY;
                if (L.vein.anchor === 'topcenter') {
                    offsetX = L.vein.x - (AW * scale) / 2;
                    offsetY = L.vein.y;
                } else {
                    offsetX = L.vein.x;
                    offsetY = L.vein.y;
                }
                this.arena.position.set(offsetX, offsetY);
            }
        }

        // ═══ UPDATE ═══
        update(delta) {
            if (this.state !== 'running') return;
            if (!this.runContext || !this.progress) return;

            const dt = delta / 60;
            this.runContext.elapsed += dt;

            const progress = Math.min(1, this.runContext.elapsed / this.runContext.duration);
            const fillW = this._tbW * progress;
            this.timeBarFill.clear()
                .beginFill(PALETTE.NEON)
                .drawRect(this._tbX, this._tbY, fillW, this._tbH).endFill();

            const m = Math.floor(this.runContext.elapsed / 60);
            const s = Math.floor(this.runContext.elapsed % 60);
            const tm = Math.floor(this.runContext.duration / 60);
            const ts = Math.floor(this.runContext.duration % 60);
            this.timeText.text = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')} / ${String(tm).padStart(2, '0')}:${String(ts).padStart(2, '0')}`;

            if (this.arena) {
                this.arena.update(delta, true, delta);
                const agg = this.arena.stats;
                if (agg && agg.maxDp > this.runContext.maxDepthGlobal) {
                    this.runContext.maxDepthGlobal = agg.maxDp;
                }
            }

            this._updateResourcePanel();

            if (this.runContext.elapsed >= this.runContext.duration) {
                this.endRun('timer');
            }
        }

        destroy(options) {
            window.removeEventListener('resize', this._onResize);
            if (this.toastMgr) this.toastMgr.destroy();
            if (this.arena) {
                try { this.arena.destroy({ children: true }); } catch (e) {}
                this.arena = null;
            }
            try {
                if (MD.MM.ProgressService && MD.MM.ProgressService.progress) {
                    MD.MM.ProgressService.saveNow();
                }
            } catch (e) {}
            super.destroy(options);
        }
    }

    MD.MinitsManagerScene = MinitsManagerScene;
})();