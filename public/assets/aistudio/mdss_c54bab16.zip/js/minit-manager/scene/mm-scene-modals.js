// ==========================================
// MINIT MANAGER — UPGRADE / LOOTBOX / CRAFT / ACH MODALS
// ==========================================
// FIX: pakai MMUI.makeScrollArea (wrapper interactive) supaya drag
// dari atas card / tab button tetap bisa scroll.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-scene-modals] deps not met');
    if (!MD.MM || !MD.MM.Config || !MD.MM.Registry || !MD.MM.UI) throw new Error('[mm-scene-modals] deps not met');

    const { CFG, PALETTE, AudioSys, Textures, MINIT_DB, UI_STYLE } = MD;
    const { Config, Registry, ProgressService, ProgressOps, UpgradeApply, StatOps, TreeOps } = MD.MM;
    const { ResourceRegistry } = Registry;
    const { MMUI } = MD.MM.UI;
    const P = Config.PALETTE;
    const LC = Config.LAYOUT_CONST;

    // ═══════════════════════════════════════════
    // UPGRADE MODAL
    // ═══════════════════════════════════════════
    function openUpgradeModal(scene) {
        if (scene._upgOverlay) return;
        const overlay = new PIXI.Container();
        overlay.interactive = true;

        const backdrop = new PIXI.Graphics()
            .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
            .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
        backdrop.interactive = true;
        overlay.addChild(backdrop);

        const U = LC.MODAL_UPGRADE;
        const panelX = (CFG.APP.W - U.W) / 2;
        const panelY = (CFG.APP.H - U.H) / 2;

        overlay.addChild(new PIXI.Graphics()
            .beginFill(P.PANEL_BG).lineStyle(2, PALETTE.NEON)
            .drawRect(panelX, panelY, U.W, U.H).endFill());

        const title = new PIXI.Text("UPGRADES", UI_STYLE.MM_MODAL_TITLE);
        title.anchor.set(0.5, 0);
        title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
        overlay.addChild(title);

        // Pakai semua unlockedMinits
        const minitIds = scene.progress.unlockedMinits.filter(id => id && MINIT_DB[id]);
        if (minitIds.length === 0) {
            const empty = new PIXI.Text("No minits unlocked", UI_STYLE.MM_INFO);
            empty.anchor.set(0.5);
            empty.position.set(CFG.APP.W / 2, panelY + U.H / 2);
            overlay.addChild(empty);

            const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
                if (overlay.parent) overlay.parent.removeChild(overlay);
                overlay.destroy({ children: true });
                if (scene._upgOverlay === overlay) scene._upgOverlay = null;
            }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
            closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + U.H - LC.MODAL.CLOSE_BTN_BOTTOM);
            overlay.addChild(closeBtn);

            scene._upgOverlay = overlay;
            scene.addChild(overlay);
            scene._bringToastToFront();
            return;
        }

        let selectedIdx = 0;
        const squadIdx = minitIds.indexOf(scene.progress.squad[0]);
        if (squadIdx >= 0) selectedIdx = squadIdx;
        let twoTapState = null;

        // ═══════════════════════════════════════════
        // MINIT TABS — horizontal scrollable
        // FIX: pakai MMUI.makeScrollArea('horizontal') — wrapper interactive,
        // event dari tab button bubble ke wrapper → drag works dari atas button.
        // ═══════════════════════════════════════════
        const tabMaskW = U.W - 40;
        const tabMaskH = U.TAB_H + 4;
        const tabScrollArea = MMUI.makeScrollArea(
            overlay,
            panelX + 20, panelY + U.TAB_Y,
            tabMaskW, tabMaskH,
            'horizontal'
        );
        const tabContent = tabScrollArea.content;

        // ── Content area (vertical scroll) ──
        const contentY = panelY + U.STATS_Y;
        const contentH = U.H - U.STATS_Y - 60;
        const scrollArea = MMUI.makeScrollArea(
            overlay,
            panelX + 20, contentY,
            U.W - 40, contentH,
            'vertical'
        );
        const contentCont = scrollArea.content;

        const renderMinitTabs = () => {
            tabContent.removeChildren();
            let x = 0;
            minitIds.forEach((id, i) => {
                const isSel = (i === selectedIdx);
                const inSquad = scene.progress.squad.includes(id);
                const tabBtn = MMUI.makeMinitTab(id, U.TAB_W, U.TAB_H, isSel, () => {
                    selectedIdx = i;
                    twoTapState = null;
                    scrollArea.resetScroll();
                    renderContent();
                    renderMinitTabs();
                });
                tabBtn.position.set(x, 0);

                // Indicator dot kalau tidak di squad
                if (!inSquad) {
                    const dot = new PIXI.Graphics()
                        .beginFill(0x888888, 0.8)
                        .drawCircle(U.TAB_W - 6, 6, 3).endFill();
                    tabBtn.addChild(dot);
                }

                tabContent.addChild(tabBtn);
                x += U.TAB_W + U.TAB_GAP;
            });
            tabScrollArea.setMaxScroll(Math.max(0, x - tabMaskW));
        };

        const refreshContent = () => {
            const saved = scrollArea.getScroll();
            renderContent();
            scrollArea.setScroll(saved);
        };

        const renderContent = () => {
            contentCont.removeChildren();

            const minitId = minitIds[selectedIdx];
            const md = MINIT_DB[minitId];
            if (!md) return;

            let y = 0;
            const rowH = U.STAT_ROW_H;

            const inSquad = scene.progress.squad.includes(minitId);
            if (!inSquad) {
                const hint = new PIXI.Text("(not in squad — add via SQUAD menu)", {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 6, fill: '#ffcc44'
                });
                hint.position.set(0, y);
                contentCont.addChild(hint);
                y += 14;
            }

            const upgradeable = UpgradeApply.getUpgradeableStats(minitId, md);
            const statFields = upgradeable.map(s => s.field);

            const statsHeader = new PIXI.Text("STATS", UI_STYLE.MM_SECTION);
            statsHeader.position.set(0, y);
            contentCont.addChild(statsHeader);
            y += 20;

            statFields.forEach((field) => {
                const ry = y;
                const level = StatOps.getStatLevel(scene.progress, minitId, field);
                const maxLv = StatOps.MAX_LEVEL;
                const cost = StatOps.getStatCost(scene.progress, minitId, field);

                const rowBg = new PIXI.Graphics()
                    .beginFill(P.SLOT_BG).lineStyle(1, P.PANEL_BORDER)
                    .drawRect(0, ry, U.W - 40, rowH - 3).endFill();
                contentCont.addChild(rowBg);

                const label = new PIXI.Text(field.toUpperCase(), {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 7, fill: PALETTE.TEXT
                });
                label.position.set(8, ry + 5);
                contentCont.addChild(label);

                const barX = 120, barW = 80, barY = ry + 7;
                const barBg = new PIXI.Graphics()
                    .beginFill(0x111111).lineStyle(1, 0x333333)
                    .drawRect(barX, barY, barW, 8).endFill();
                contentCont.addChild(barBg);
                if (level > 0) {
                    const barFill = new PIXI.Graphics()
                        .beginFill(PALETTE.NEON)
                        .drawRect(barX, barY, barW * (level / maxLv), 8).endFill();
                    contentCont.addChild(barFill);
                }

                const lvText = new PIXI.Text(`Lv ${level}/${maxLv}`, {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 7, fill: PALETTE.NEON
                });
                lvText.position.set(210, ry + 5);
                contentCont.addChild(lvText);

                if (cost && level < maxLv) {
                    const costStr = Object.keys(cost).map(k =>
                        `${cost[k]}${(ResourceRegistry.get(k) || {}).label?.[0] || '?'}`
                    ).join(' ');
                    const costText = new PIXI.Text(costStr, {
                        ...UI_STYLE.MM_LABEL_TINY, fontSize: 6
                    });
                    costText.position.set(310, ry + 6);
                    contentCont.addChild(costText);

                    const canBuy = ProgressOps.canAfford(scene.progress, cost);
                    const buyBtn = MMUI.makeButton("+", 30, 18, () => {
                        const key = `stat_${minitId}_${field}`;
                        if (twoTapState && twoTapState.key === key) {
                            twoTapState = null;
                            if (StatOps.applyStatUpgrade(scene.progress, minitId, field, ProgressOps)) {
                                ProgressService.scheduleAutosave();
                                scene._updateResourcePanel();
                                refreshContent();
                                try { AudioSys.play('start'); } catch (e) {}
                            } else {
                                try { AudioSys.play('hit', 0.5); } catch (e) {}
                            }
                        } else {
                            twoTapState = { type: 'stat', key, cost };
                            const cStr = Object.keys(cost).map(k =>
                                `${cost[k]} ${(ResourceRegistry.get(k) || {}).label || k}`
                            ).join(' + ');
                            scene.toastMgr.push({
                                type: 'achievement',
                                title: 'PRESS AGAIN',
                                subtitle: `Cost: ${cStr}`
                            });
                            scene._bringToastToFront();
                        }
                    }, {
                        style: UI_STYLE.MM_BTN_TINY,
                        borderColor: canBuy ? 0x44ff88 : 0x444444,
                        fill: canBuy ? '#88ffaa' : '#888888',
                        bgColor: canBuy ? 0x1a3a1a : 0x222222
                    });
                    buyBtn.position.set(U.W - 90, ry + 1);
                    contentCont.addChild(buyBtn);
                } else if (level >= maxLv) {
                    const maxText = new PIXI.Text("MAX", {
                        ...UI_STYLE.MM_LABEL_TINY, fontSize: 7, fill: 0xffcc00
                    });
                    maxText.position.set(U.W - 80, ry + 6);
                    contentCont.addChild(maxText);
                }

                y += rowH;
            });

            // Tree section
            y += U.TREE_Y_GAP;
            const treeHeader = new PIXI.Text("SKILL TREE", UI_STYLE.MM_SECTION);
            treeHeader.position.set(0, y);
            contentCont.addChild(treeHeader);
            y += 20;

            const branches = UpgradeApply.getBranches(minitId);
            const branchW = U.W - 40;

            branches.forEach((branch) => {
                const branchY = y;

                const bTitle = new PIXI.Text(branch.name, {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 8, fill: PALETTE.NEON
                });
                bTitle.position.set(0, branchY);
                contentCont.addChild(bTitle);

                const currentTier = TreeOps.getBranchTier(scene.progress, minitId, branch.id);

                const tierW = (branchW - 2 * 8) / 3;
                branch.tiers.forEach((tier, ti) => {
                    const tx = ti * (tierW + 8);
                    const ty = branchY + U.TIER_START_Y;
                    const tierNum = ti + 1;
                    const isUnlocked = currentTier >= tierNum;
                    const canUnlock = TreeOps.canUnlockTier(scene.progress, minitId, branch.id, tierNum);
                    const cost = TreeOps.getTierCost(scene.progress, minitId, branch.id, tierNum);

                    const tierBg = new PIXI.Graphics()
                        .beginFill(isUnlocked ? 0x1a2a3a : P.SLOT_BG)
                        .lineStyle(1, isUnlocked ? 0x00ccff : P.PANEL_BORDER)
                        .drawRect(tx, ty, tierW, U.TIER_H).endFill();
                    contentCont.addChild(tierBg);

                    const desc = new PIXI.Text(tier.desc, {
                        ...UI_STYLE.MM_LABEL_TINY, fontSize: 6,
                        fill: isUnlocked ? '#00ccff' : PALETTE.TEXT,
                        wordWrap: true, wordWrapWidth: tierW - 12
                    });
                    desc.position.set(tx + 6, ty + 4);
                    contentCont.addChild(desc);

                    if (!isUnlocked && canUnlock && cost) {
                        const costStr = Object.keys(cost).map(k =>
                            `${cost[k]}${(ResourceRegistry.get(k) || {}).label?.[0] || '?'}`
                        ).join(' ');
                        const cText = new PIXI.Text(costStr, {
                            ...UI_STYLE.MM_LABEL_TINY, fontSize: 5
                        });
                        cText.position.set(tx + 6, ty + 24);
                        contentCont.addChild(cText);

                        const buyBtn = MMUI.makeButton("UNLOCK", tierW - 12, U.UNLOCK_BTN_H, () => {
                            const key = `tree_${minitId}_${branch.id}_${tierNum}`;
                            if (twoTapState && twoTapState.key === key) {
                                twoTapState = null;
                                if (TreeOps.applyTreeUpgrade(scene.progress, minitId, branch.id, ProgressOps)) {
                                    ProgressService.scheduleAutosave();
                                    scene._updateResourcePanel();
                                    refreshContent();
                                    try { AudioSys.play('start'); } catch (e) {}
                                } else {
                                    try { AudioSys.play('hit', 0.5); } catch (e) {}
                                }
                            } else {
                                twoTapState = { type: 'tree', key, cost };
                                const cStr = Object.keys(cost).map(k =>
                                    `${cost[k]} ${(ResourceRegistry.get(k) || {}).label || k}`
                                ).join(' + ');
                                scene.toastMgr.push({
                                    type: 'achievement',
                                    title: 'PRESS AGAIN',
                                    subtitle: `Cost: ${cStr}`
                                });
                                scene._bringToastToFront();
                            }
                        }, {
                            style: UI_STYLE.MM_BTN_TINY,
                            fontSize: 6,
                            borderColor: 0x44ff88, fill: '#88ffaa', bgColor: 0x1a3a1a
                        });
                        buyBtn.position.set(tx + 6, ty + U.TIER_H - 18);
                        contentCont.addChild(buyBtn);
                    }
                });

                y += U.TIER_START_Y + U.TIER_H + 12;
            });

            scrollArea.setMaxScroll(Math.max(0, y - contentH));
        };

        renderMinitTabs();
        renderContent();

        const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
            if (overlay.parent) overlay.parent.removeChild(overlay);
            overlay.destroy({ children: true });
            if (scene._upgOverlay === overlay) scene._upgOverlay = null;
        }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
        closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + U.H - LC.MODAL.CLOSE_BTN_BOTTOM);
        overlay.addChild(closeBtn);

        scene._upgOverlay = overlay;
        scene.addChild(overlay);
        scene._bringToastToFront();
    }

    // ═══════════════════════════════════════════
    // LOOTBOX MODAL
    // ═══════════════════════════════════════════
    function openLootboxModal(scene) {
        if (scene._lootOverlay) return;
        if (!MD.MM.LootboxSystem) return;
        const overlay = new PIXI.Container();
        overlay.interactive = true;

        const backdrop = new PIXI.Graphics()
            .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
            .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
        backdrop.interactive = true;
        overlay.addChild(backdrop);

        const L = LC.MODAL_LOOTBOX;
        const panelX = (CFG.APP.W - L.W) / 2;
        const panelY = (CFG.APP.H - L.H) / 2;

        overlay.addChild(new PIXI.Graphics()
            .beginFill(P.PANEL_BG).lineStyle(2, 0xffcc00)
            .drawRect(panelX, panelY, L.W, L.H).endFill());

        const title = new PIXI.Text("LOOTBOX", {
            ...UI_STYLE.MM_MODAL_TITLE, fill: '#ffcc00'
        });
        title.anchor.set(0.5, 0);
        title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
        overlay.addChild(title);

        const cost = MD.MM.LootboxSystem.getCost();
        const info = new PIXI.Text(
            `Cost: ${cost.gems} ${(ResourceRegistry.get('gems') || {}).label || 'GEMS'}\n\n` +
            `Drops: Minit unlock OR resource bundle.\n` +
            `Pulls since rare: ${scene.progress.lootbox.pityCounter || 0} / ${Config.LOOTBOX.PITY_THRESHOLD}\n` +
            `(Guaranteed rare every ${Config.LOOTBOX.PITY_THRESHOLD} pulls)`,
            { ...UI_STYLE.MM_INFO, align: 'center' }
        );
        info.anchor.set(0.5, 0);
        info.position.set(CFG.APP.W / 2, panelY + L.INFO_Y);
        overlay.addChild(info);

        const resultText = new PIXI.Text("", {
            ...UI_STYLE.MM_INFO, align: 'center', fontSize: 10, fill: '#ffcc00'
        });
        resultText.anchor.set(0.5, 0);
        resultText.position.set(CFG.APP.W / 2, panelY + L.RESULT_Y);
        overlay.addChild(resultText);

        const canAfford = ProgressOps.canAfford(scene.progress, cost);
        const pullBtn = MMUI.makeButton("PULL", L.BTN_W, L.BTN_H, () => {
            const result = MD.MM.LootboxSystem.open(scene.progress, ProgressOps);
            if (result) {
                ProgressService.scheduleAutosave();
                scene._updateResourcePanel();

                if (result.type === 'minit') {
                    const md = MINIT_DB[result.minitId];
                    scene.toastMgr.push({
                        type: 'minit',
                        id: result.minitId,
                        title: `${(result.rarity || 'COMMON').toUpperCase()} MINIT!`,
                        subtitle: (md && md.name) || result.minitId
                    });
                    resultText.text = `→ Got minit: ${(md && md.name) || result.minitId} [${(result.rarity || '').toUpperCase()}]`;
                } else if (result.type === 'resource') {
                    const res = ResourceRegistry.get(result.resourceId);
                    scene.toastMgr.push({
                        type: 'achievement',
                        title: `${(result.rarity || 'COMMON').toUpperCase()} DROP`,
                        subtitle: `${result.amount} ${res ? res.label : result.resourceId}`
                    });
                    resultText.text = `→ Got: ${result.amount} ${res ? res.label : result.resourceId} [${(result.rarity || '').toUpperCase()}]`;
                }
                scene._bringToastToFront();

                // Rebuild untuk refresh pity counter
                if (overlay.parent) overlay.parent.removeChild(overlay);
                overlay.destroy({ children: true });
                scene._lootOverlay = null;
                openLootboxModal(scene);
            } else {
                try { AudioSys.play('hit', 0.5); } catch (e) {}
            }
        }, {
            style: UI_STYLE.MM_BTN_PRIMARY,
            borderColor: canAfford ? 0xffcc00 : 0x444444,
            fill: canAfford ? '#ffdd44' : '#888888',
            bgColor: canAfford ? 0x3a2a00 : 0x222222
        });
        pullBtn.position.set(CFG.APP.W / 2 - L.BTN_W / 2, panelY + L.BTN_Y);
        overlay.addChild(pullBtn);

        const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
            if (overlay.parent) overlay.parent.removeChild(overlay);
            overlay.destroy({ children: true });
            if (scene._lootOverlay === overlay) scene._lootOverlay = null;
        }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
        closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + L.H - LC.MODAL.CLOSE_BTN_BOTTOM);
        overlay.addChild(closeBtn);

        scene._lootOverlay = overlay;
        scene.addChild(overlay);
        scene._bringToastToFront();
    }

    // ═══════════════════════════════════════════
    // CRAFTING MODAL
    // ═══════════════════════════════════════════
    function openCraftModal(scene) {
        if (scene._craftOverlay) return;
        if (!MD.MM.CraftingSystem) return;
        const overlay = new PIXI.Container();
        overlay.interactive = true;

        const backdrop = new PIXI.Graphics()
            .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
            .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
        backdrop.interactive = true;
        overlay.addChild(backdrop);

        const C = LC.MODAL_CRAFT;
        const panelX = (CFG.APP.W - C.W) / 2;
        const panelY = (CFG.APP.H - C.H) / 2;

        overlay.addChild(new PIXI.Graphics()
            .beginFill(P.PANEL_BG).lineStyle(2, 0xcc88ff)
            .drawRect(panelX, panelY, C.W, C.H).endFill());

        const title = new PIXI.Text("CRAFTING", {
            ...UI_STYLE.MM_MODAL_TITLE, fill: '#ddaaff'
        });
        title.anchor.set(0.5, 0);
        title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
        overlay.addChild(title);

        const craftable = MD.MM.CraftingSystem.getCraftable(scene.progress);
        if (craftable.length === 0) {
            const empty = new PIXI.Text("No minits available for crafting.",
                { ...UI_STYLE.MM_INFO, align: 'center' });
            empty.anchor.set(0.5);
            empty.position.set(CFG.APP.W / 2, panelY + C.H / 2);
            overlay.addChild(empty);
        } else {
            let twoTapState = null;
            craftable.forEach((item, i) => {
                const ry = panelY + C.LIST_Y + i * C.ROW_H;
                const md = MINIT_DB[item.minitId];
                if (!md) return;

                const rowBg = new PIXI.Graphics()
                    .beginFill(P.SLOT_BG).lineStyle(1, P.PANEL_BORDER)
                    .drawRect(panelX + 20, ry, C.W - 40, C.ROW_H - 6).endFill();
                overlay.addChild(rowBg);

                if (Textures[`minit_${item.minitId}_base`]) {
                    const icon = new PIXI.Sprite(Textures[`minit_${item.minitId}_base`]);
                    icon.anchor.set(0.5);
                    icon.scale.set(1.6);
                    icon.position.set(panelX + C.ICON_X, ry + C.ROW_H / 2 - 3);
                    overlay.addChild(icon);
                }

                const name = new PIXI.Text(md.name, {
                    ...UI_STYLE.MM_SECTION, fontSize: 10
                });
                name.position.set(panelX + C.TEXT_X, ry + 12);
                overlay.addChild(name);

                const costStr = Object.keys(item.cost).map(k =>
                    `${item.cost[k]} ${(ResourceRegistry.get(k) || {}).label || k}`
                ).join(' + ');
                const costText = new PIXI.Text(costStr, {
                    ...UI_STYLE.MM_LABEL_TINY, fontSize: 8
                });
                costText.position.set(panelX + C.TEXT_X, ry + 32);
                overlay.addChild(costText);

                const canAfford = ProgressOps.canAfford(scene.progress, item.cost);
                const craftBtn = MMUI.makeButton("CRAFT", 90, 26, () => {
                    const key = `craft_${item.minitId}`;
                    if (twoTapState && twoTapState.key === key) {
                        twoTapState = null;
                        if (MD.MM.CraftingSystem.craft(scene.progress, item.minitId, ProgressOps)) {
                            ProgressService.scheduleAutosave();
                            scene._updateResourcePanel();
                            scene.toastMgr.push({
                                type: 'minit',
                                id: item.minitId,
                                title: 'CRAFTED!',
                                subtitle: md.name
                            });
                            if (overlay.parent) overlay.parent.removeChild(overlay);
                            overlay.destroy({ children: true });
                            scene._craftOverlay = null;
                        } else {
                            try { AudioSys.play('hit', 0.5); } catch (e) {}
                        }
                    } else {
                        twoTapState = { type: 'craft', key };
                        scene.toastMgr.push({
                            type: 'achievement',
                            title: 'PRESS AGAIN',
                            subtitle: `Cost: ${costStr}`
                        });
                        scene._bringToastToFront();
                    }
                }, {
                    style: UI_STYLE.MM_BTN_TINY,
                    fontSize: 9,
                    borderColor: canAfford ? 0x44ff88 : 0x444444,
                    fill: canAfford ? '#88ffaa' : '#888888',
                    bgColor: canAfford ? 0x1a3a1a : 0x222222
                });
                craftBtn.position.set(panelX + C.W - C.BTN_W_OFF, ry + C.BTN_Y_OFF);
                overlay.addChild(craftBtn);
            });
        }

        const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
            if (overlay.parent) overlay.parent.removeChild(overlay);
            overlay.destroy({ children: true });
            if (scene._craftOverlay === overlay) scene._craftOverlay = null;
        }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
        closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + C.H - LC.MODAL.CLOSE_BTN_BOTTOM);
        overlay.addChild(closeBtn);

        scene._craftOverlay = overlay;
        scene.addChild(overlay);
        scene._bringToastToFront();
    }

    // ═══════════════════════════════════════════
    // ACHIEVEMENT MODAL
    // ═══════════════════════════════════════════
    function openAchievementModal(scene) {
        if (scene._achOverlay) return;
        if (!MD.MM.AchievementSystem) return;
        const overlay = new PIXI.Container();
        overlay.interactive = true;

        const backdrop = new PIXI.Graphics()
            .beginFill(0x000000, LC.MODAL.BACKDROP_ALPHA)
            .drawRect(0, 0, CFG.APP.W, CFG.APP.H).endFill();
        backdrop.interactive = true;
        overlay.addChild(backdrop);

        const A = LC.MODAL_ACHIEVEMENT;
        const panelX = (CFG.APP.W - A.W) / 2;
        const panelY = (CFG.APP.H - A.H) / 2;

        overlay.addChild(new PIXI.Graphics()
            .beginFill(P.PANEL_BG).lineStyle(2, 0xffcc44)
            .drawRect(panelX, panelY, A.W, A.H).endFill());

        const title = new PIXI.Text("ACHIEVEMENTS", {
            ...UI_STYLE.MM_MODAL_TITLE, fill: '#ffcc44'
        });
        title.anchor.set(0.5, 0);
        title.position.set(CFG.APP.W / 2, panelY + LC.MODAL.TITLE_Y);
        overlay.addChild(title);

        const achs = MD.MM.AchievementSystem.getAll(scene.progress);
        achs.forEach((ach, i) => {
            const ry = panelY + A.LIST_Y + i * A.ROW_H;
            if (ry + A.ROW_H > panelY + A.H - 50) return;

            const rowBg = new PIXI.Graphics()
                .beginFill(ach.completed ? 0x1a3a1a : P.SLOT_BG)
                .lineStyle(1, ach.completed ? 0x44ff88 : P.PANEL_BORDER)
                .drawRect(panelX + 20, ry, A.W - 40, A.ROW_H - 6).endFill();
            overlay.addChild(rowBg);

            if (Textures['icon_trophy']) {
                const icon = new PIXI.Sprite(Textures['icon_trophy']);
                icon.anchor.set(0.5);
                icon.position.set(panelX + A.ICON_X, ry + A.ROW_H / 2 - 3);
                icon.tint = ach.completed ? 0xffffff : 0x555555;
                overlay.addChild(icon);
            }

            const name = new PIXI.Text(ach.name, {
                ...UI_STYLE.MM_LABEL_TINY, fontSize: 9,
                fill: ach.completed ? '#88ffaa' : PALETTE.TEXT
            });
            name.position.set(panelX + A.TEXT_X, ry + 8);
            overlay.addChild(name);

            const desc = new PIXI.Text(ach.desc, {
                ...UI_STYLE.MM_LABEL_TINY, fontSize: 6
            });
            desc.position.set(panelX + A.TEXT_X, ry + 24);
            overlay.addChild(desc);

            const prog = MD.MM.AchievementSystem.progressFor(scene.progress, ach.id);
            const barW = A.PROGRESS_BAR_W;
            const barX = panelX + A.W - barW - A.BAR_RIGHT_PAD;
            const barY = ry + 22;
            const barBg = new PIXI.Graphics()
                .beginFill(0x111111).lineStyle(1, 0x333333)
                .drawRect(barX, barY, barW, A.PROGRESS_BAR_H).endFill();
            overlay.addChild(barBg);
            const barFill = new PIXI.Graphics()
                .beginFill(ach.completed ? 0x44ff88 : 0xffcc44)
                .drawRect(barX, barY, barW * prog.pct, A.PROGRESS_BAR_H).endFill();
            overlay.addChild(barFill);

            const pText = new PIXI.Text(`${prog.current} / ${prog.target}`, {
                ...UI_STYLE.MM_LABEL_TINY, fontSize: 6
            });
            pText.anchor.set(1, 0);
            pText.position.set(barX + barW, barY - 12);
            overlay.addChild(pText);
        });

        const closeBtn = MMUI.makeButton("CLOSE", LC.MODAL.CLOSE_BTN_W, LC.MODAL.CLOSE_BTN_H, () => {
            if (overlay.parent) overlay.parent.removeChild(overlay);
            overlay.destroy({ children: true });
            if (scene._achOverlay === overlay) scene._achOverlay = null;
        }, { style: UI_STYLE.MM_BTN_TINY, borderColor: 0xff0055, fill: '#ff0055' });
        closeBtn.position.set(CFG.APP.W / 2 - LC.MODAL.CLOSE_BTN_W / 2, panelY + A.H - LC.MODAL.CLOSE_BTN_BOTTOM);
        overlay.addChild(closeBtn);

        scene._achOverlay = overlay;
        scene.addChild(overlay);
        scene._bringToastToFront();
    }

    MD.MM.openUpgradeModal = openUpgradeModal;
    MD.MM.openLootboxModal = openLootboxModal;
    MD.MM.openCraftModal = openCraftModal;
    MD.MM.openAchievementModal = openAchievementModal;
})();