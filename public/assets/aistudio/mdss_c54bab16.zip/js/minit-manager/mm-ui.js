// ==========================================
// MINIT MANAGER — UI HELPERS
// ==========================================
// FIX: wrapper interactive (bukan scrollLayer) supaya drag dari atas
// card/button tetap bisa scroll lewat event bubbling.
// ==========================================

(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[mm-ui] deps not met');
    if (!MD.MM || !MD.MM.Config) throw new Error('[mm-ui] config not loaded');

    const { CFG, PALETTE, AudioSys, Textures, MINIT_DB, UI_STYLE } = MD;
    const { Config } = MD.MM;
    const P = Config.PALETTE;
    const LC = Config.LAYOUT_CONST;

    const DRAG_THRESHOLD = 5;

    // ═══════════════════════════════════════════
    // MMUI — Button & scroll builders
    // ═══════════════════════════════════════════
    const MMUI = {
        /**
         * Button dengan drag-threshold click detection.
         * PENTING: TIDAK pakai stopPropagation di pointerdown — biar event
         * bubble ke wrapper (scroll area) dan drag works.
         */
        makeButton(text, w, h, onClick, opts = {}) {
            const btn = new PIXI.Container();
            btn.interactive = btn.buttonMode = true;
            btn.hitArea = new PIXI.Rectangle(0, 0, w, h);

            const bgColor = opts.bgColor ?? 0x1a1a22;
            const borderColor = opts.borderColor ?? PALETTE.NEON;
            const fillColor = opts.fill ?? PALETTE.TEXT;
            const style = opts.style ?? UI_STYLE.MM_BTN_STANDARD;

            const bg = new PIXI.Graphics()
                .beginFill(bgColor).lineStyle(1, borderColor)
                .drawRect(0, 0, w, h).endFill();
            btn.addChild(bg);

            const label = new PIXI.Text(text, { ...style, fill: fillColor });
            label.anchor.set(0.5);
            label.position.set(w / 2, h / 2);
            btn.addChild(label);

            let downX = 0, downY = 0, isDrag = false;

            btn.on('pointerdown', (e) => {
                downX = e.global.x;
                downY = e.global.y;
                isDrag = false;
                // JANGAN stopPropagation — biar wrapper scroll bisa track
            });
            btn.on('pointermove', (e) => {
                const dx = e.global.x - downX;
                const dy = e.global.y - downY;
                if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
                    isDrag = true;
                }
            });
            btn.on('pointerup', (e) => {
                if (!isDrag) {
                    try { AudioSys.init(); AudioSys.play('click'); } catch (err) {}
                    onClick();
                }
                isDrag = false;
            });
            btn.on('pointerupoutside', () => { isDrag = false; });
            btn.on('pointerover', () => bg.tint = 0x888899);
            btn.on('pointerout', () => bg.tint = 0xffffff);

            btn._bg = bg;
            btn._label = label;
            return btn;
        },

        makeIconButton(iconKey, w, h, onClick, opts = {}) {
            const btn = new PIXI.Container();
            btn.interactive = btn.buttonMode = true;
            btn.hitArea = new PIXI.Rectangle(0, 0, w, h);

            const bgColor = opts.bgColor ?? 0x1a1a22;
            const borderColor = opts.borderColor ?? PALETTE.NEON;

            const bg = new PIXI.Graphics()
                .beginFill(bgColor).lineStyle(1, borderColor)
                .drawRect(0, 0, w, h).endFill();
            btn.addChild(bg);

            if (Textures[iconKey]) {
                const icon = new PIXI.Sprite(Textures[iconKey]);
                icon.anchor.set(0.5);
                icon.position.set(w / 2, h / 2);
                icon.scale.set(0.9);
                btn.addChild(icon);
            }

            let downX = 0, downY = 0, isDrag = false;

            btn.on('pointerdown', (e) => {
                downX = e.global.x;
                downY = e.global.y;
                isDrag = false;
            });
            btn.on('pointermove', (e) => {
                const dx = e.global.x - downX;
                const dy = e.global.y - downY;
                if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
                    isDrag = true;
                }
            });
            btn.on('pointerup', (e) => {
                if (!isDrag) {
                    try { AudioSys.init(); AudioSys.play('click'); } catch (err) {}
                    onClick();
                }
                isDrag = false;
            });
            btn.on('pointerupoutside', () => { isDrag = false; });
            btn.on('pointerover', () => bg.tint = 0x888899);
            btn.on('pointerout', () => bg.tint = 0xffffff);

            btn._bg = bg;
            return btn;
        },

        /**
         * Minit tab — icon + text. Drag-threshold click detection.
         */
        makeMinitTab(minitId, w, h, isSelected, onClick) {
            const tab = new PIXI.Container();
            tab.interactive = tab.buttonMode = true;
            tab.hitArea = new PIXI.Rectangle(0, 0, w, h);

            const bgColor = isSelected ? 0x1a2a3a : 0x1a1a22;
            const borderColor = isSelected ? 0x00ccff : 0x444455;
            const fillColor = isSelected ? '#00ccff' : PALETTE.TEXT;

            const bg = new PIXI.Graphics()
                .beginFill(bgColor).lineStyle(1, borderColor)
                .drawRect(0, 0, w, h).endFill();
            tab.addChild(bg);

            const iconKey = `minit_${minitId}_base`;
            let textX = w / 2;
            if (Textures[iconKey]) {
                const icon = new PIXI.Sprite(Textures[iconKey]);
                icon.anchor.set(0.5);
                icon.scale.set(0.7);
                icon.position.set(14, h / 2);
                tab.addChild(icon);
                textX = 14 + 14 + (w - 28 - 14) / 2 + 4;
            }

            const md = MINIT_DB[minitId];
            const label = new PIXI.Text(md ? md.name : minitId, {
                ...UI_STYLE.MM_BTN_TINY, fontSize: 7, fill: fillColor
            });
            label.anchor.set(0.5);
            label.position.set(textX, h / 2);
            tab.addChild(label);

            let downX = 0, downY = 0, isDrag = false;

            tab.on('pointerdown', (e) => {
                downX = e.global.x;
                downY = e.global.y;
                isDrag = false;
            });
            tab.on('pointermove', (e) => {
                const dx = e.global.x - downX;
                const dy = e.global.y - downY;
                if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
                    isDrag = true;
                }
            });
            tab.on('pointerup', () => {
                if (!isDrag) {
                    try { AudioSys.init(); AudioSys.play('click'); } catch (err) {}
                    onClick();
                }
                isDrag = false;
            });
            tab.on('pointerupoutside', () => { isDrag = false; });
            tab.on('pointerover', () => bg.tint = 0x888899);
            tab.on('pointerout', () => bg.tint = 0xffffff);

            tab._bg = bg;
            return tab;
        },

        /**
         * Scroll area — FIX: wrapper interactive.
         *
         * Struktur:
         *   wrapper (interactive, hitArea = full area, eventMode = static)
         *     ├── content (children: cards/buttons, not interactive as container)
         *     └── mask
         *
         * Karena wrapper = ancestor dari cards/buttons, semua pointer
         * events dari card/button akan BUBBLE ke wrapper. Wrapper track
         * drag. Cards/buttons tetap dapat click karena mereka
         * interactive sendiri (event fire ke mereka dulu, baru bubble).
         *
         * @param {'vertical'|'horizontal'} direction
         */
        makeScrollArea(parent, x, y, w, h, direction = 'vertical') {
            const wrapper = new PIXI.Container();
            wrapper.position.set(x, y);
            // FIX: wrapper sendiri interactive, bukan scrollLayer terpisah
            wrapper.interactive = true;
            wrapper.eventMode = 'static';
            wrapper.hitArea = new PIXI.Rectangle(0, 0, w, h);
            parent.addChild(wrapper);

            const content = new PIXI.Container();
            wrapper.addChild(content);

            const mask = new PIXI.Graphics()
                .beginFill(0xffffff)
                .drawRect(0, 0, w, h).endFill();
            wrapper.addChild(mask);
            content.mask = mask;

            const isH = direction === 'horizontal';
            let scrollPos = 0;
            let maxScroll = 0;
            let dragging = false;
            let dragMoved = false;
            let dragStart = 0;
            let dragStartScroll = 0;

            const setPos = () => {
                if (isH) content.x = scrollPos;
                else content.y = scrollPos;
            };

            const onDown = (e) => {
                dragging = true;
                dragMoved = false;
                dragStart = isH ? e.global.x : e.global.y;
                dragStartScroll = scrollPos;
            };

            const onMove = (e) => {
                if (!dragging) return;
                const d = (isH ? e.global.x : e.global.y) - dragStart;
                if (Math.abs(d) > DRAG_THRESHOLD) dragMoved = true;
                scrollPos = Math.max(-maxScroll, Math.min(0, dragStartScroll + d));
                setPos();
            };

            const onUp = () => {
                dragging = false;
                dragMoved = false;
            };

            wrapper.on('pointerdown', onDown);
            wrapper.on('pointermove', onMove);
            wrapper.on('pointermoveoutside', onMove);  // track drag yang keluar area
            wrapper.on('pointerup', onUp);
            wrapper.on('pointerupoutside', onUp);
            wrapper.on('pointercancel', onUp);
            wrapper.on('wheel', (e) => {
                const d = isH ? (e.deltaX || e.deltaY) : e.deltaY;
                scrollPos = Math.max(-maxScroll, Math.min(0, scrollPos - d * 0.5));
                setPos();
            });

            return {
                wrapper,
                content,
                getScroll() { return scrollPos; },
                setMaxScroll(v) {
                    maxScroll = Math.max(0, v);
                    scrollPos = Math.max(-maxScroll, Math.min(0, scrollPos));
                    setPos();
                },
                setScroll(v) {
                    scrollPos = Math.max(-maxScroll, Math.min(0, v));
                    setPos();
                },
                resetScroll() {
                    scrollPos = 0;
                    setPos();
                },
                isDragging() { return dragging && dragMoved; }
            };
        }
    };

    // ═══════════════════════════════════════════
    // TOAST MANAGER
    // ═══════════════════════════════════════════
    class ToastManager {
        constructor(container) {
            this.container = container;
            this.queue = [];
            this.active = null;
        }
        push(n) {
            if (!n) return;
            if (this.queue.length >= LC.TOAST.QUEUE_MAX) return;
            this.queue.push(n);
            this._tick();
        }
        _tick() {
            if (this.active || this.queue.length === 0) return;
            this._show(this.queue.shift());
        }
        _show(n) {
            const cont = new PIXI.Container();
            cont.position.set(CFG.APP.W / 2, LC.TOAST.Y_POSITION);
            const T = LC.TOAST;

            const bg = new PIXI.Graphics()
                .beginFill(P.PANEL_BG)
                .lineStyle(2, PALETTE.NEON)
                .drawRect(T.BG_X, T.BG_Y, T.BG_W, T.BG_H).endFill();
            cont.addChild(bg);

            const title = new PIXI.Text(n.title || 'UNLOCKED', UI_STYLE.MM_TOAST_TITLE);
            title.anchor.set(0.5, 0);
            title.position.set(0, T.TITLE_Y);
            cont.addChild(title);

            if (n.type === 'minit' && n.id && Textures[`minit_${n.id}_base`]) {
                const icon = new PIXI.Sprite(Textures[`minit_${n.id}_base`]);
                icon.anchor.set(0.5);
                icon.scale.set(1.4);
                icon.position.set(T.ICON_OFFSET_X, T.TEXT_OFFSET_Y);
                cont.addChild(icon);
                const name = new PIXI.Text(n.subtitle || '', UI_STYLE.MM_TOAST_BODY);
                name.anchor.set(0, 0.5);
                name.position.set(T.TEXT_OFFSET_X, T.TEXT_OFFSET_Y);
                cont.addChild(name);
            } else {
                const fillColor = n.type === 'area' ? '#ffcc88' : PALETTE.TEXT;
                const name = new PIXI.Text(n.subtitle || '',
                    { ...UI_STYLE.MM_TOAST_BODY, fill: fillColor });
                name.anchor.set(0.5);
                name.position.set(0, 8);
                cont.addChild(name);
            }

            this.container.addChild(cont);

            const startY = T.Y_POSITION + T.SLIDE_IN_OFFSET;
            const endY = T.Y_POSITION;
            cont.y = startY;
            cont.alpha = 0;

            const startTime = performance.now();
            const fadeIn = T.FADE_IN_MS;
            const hold = T.DURATION_MS - fadeIn - T.FADE_OUT_MS;
            const fadeOut = T.FADE_OUT_MS;

            const animFn = () => {
                if (cont.destroyed) {
                    MD.app.ticker.remove(animFn);
                    this.active = null;
                    setTimeout(() => this._tick(), 50);
                    return;
                }
                const elapsed = performance.now() - startTime;
                if (elapsed < fadeIn) {
                    const t = elapsed / fadeIn;
                    cont.y = startY + (endY - startY) * t;
                    cont.alpha = t;
                } else if (elapsed < fadeIn + hold) {
                    cont.y = endY;
                    cont.alpha = 1;
                } else if (elapsed < fadeIn + hold + fadeOut) {
                    const t = (elapsed - fadeIn - hold) / fadeOut;
                    cont.y = endY - 40 * t;
                    cont.alpha = 1 - t;
                } else {
                    MD.app.ticker.remove(animFn);
                    if (cont.parent) cont.parent.removeChild(cont);
                    cont.destroy({ children: true });
                    this.active = null;
                    setTimeout(() => this._tick(), 100);
                    return;
                }
            };

            this.active = { cont, animFn };
            MD.app.ticker.add(animFn);
        }
        destroy() {
            if (this.active) {
                MD.app.ticker.remove(this.active.animFn);
                if (this.active.cont && this.active.cont.parent) {
                    this.active.cont.parent.removeChild(this.active.cont);
                    this.active.cont.destroy({ children: true });
                }
                this.active = null;
            }
            this.queue.length = 0;
        }
    }

    MD.MM.UI = { MMUI, ToastManager };
})();