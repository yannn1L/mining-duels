// ==========================================
// BEHAVIORS + MinitBehaviorBuilder
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG) throw new Error('[behaviors.js] deps not met');

    MD.BEHAVIORS = {
        beam: {
            vertical: ({ dmg = 30, length = 5, color = 0x00ccff, shake = 3, duration = 25, sound = 'laser' } = {}) => ({
                traits: ['ageLife', 'beamDamage'],
                p: { length, dmg, color, shake }, l: duration, sound
            }),
            lightning: ({ dmg = 25, length = 6, color = 0xffff00, duration = 25, sound = 'laser' } = {}) => ({
                traits: ['ageLife', 'lightningDamage'],
                p: { length, dmg, color }, l: duration, sound
            })
        },
        projectile: {
            straight: ({ dmg = 20, color = 0xffffff, trailTex = 'fx_nano', trailVy = -0.5, life = 30, vx = 0, vy = 0.8, shake = 0 } = {}) => ({
                traits: ['moveDirection', 'ageLife', 'damageOnHit', 'trailParticles'],
                p: { dmg, color, trailTex, trailVy, shake }, l: life, dx: vx, dy: vy
            }),
            bouncing: ({ dmg = 15, color = 0xffff00, trailTex = 'fx_shrapnel', trailVy = -0.5, life = 25, vx = 0, vy = 1, shake = 2 } = {}) => ({
                traits: ['moveDirection', 'bounceX', 'ageLife', 'damageOnHit', 'trailParticles'],
                p: { dmg, color, trailTex, trailVy, shake }, l: life, dx: vx, dy: vy
            }),
            gravity: ({ dmg = 250, color = 0xff0055, radius = 2, shake = 15, fuse = 8, expSound = 'explosion', shockRad = 100 } = {}) => ({
                traits: ['gravityFall', 'fuseTimer', 'explodeOnDeath'],
                p: { dmg, radius, color, shake, expSound, shockRad }, f: fuse
            }),
            targeted: ({ dmg = 500, radius = 3, color = 0x88ffcc, trailTex = 'fx_acid', trailVy = -1, trailDragX = 0.92, trailDragY = 0.92, trailSwirl = true, shake = 15, flash = 0.6, expSound = 'nuke', shockRad = 120, life = 30, tx = 0, ty = 0 } = {}) => ({
                traits: ['moveToTarget', 'trailParticles', 'ageLife', 'explodeOnDeath'],
                p: { dmg, radius, color, shake, flash, expSound, shockRad, trailTex, trailVy, trailDragX, trailDragY, trailSwirl },
                tx, ty, l: life, maxL: life
            })
        },
        pull: {
            toward: ({ targetRef = null, color = 0x00ccff, trailTex = 'fx_nano', life = 15 } = {}) => ({
                traits: ['moveToTarget', 'ageLife', 'trailParticles'],
                p: { targetRef, color, trailTex }, l: life, maxL: life
            })
        },
        orbit: {
            satellite: ({ targetRef = null, radius = 2, speed = 0.08, startAngle = 0, spriteTex = 'fx_flash', castInterval = 35, castSound = 'laser', castPayload = null, randomCast = false, life = 99999 } = {}) => ({
                traits: randomCast ? ['orbitAnchor', 'renderSprite', 'intervalRandomCast'] : ['orbitAnchor', 'renderSprite', 'intervalCast'],
                p: { targetRef, orbitRadius: radius, orbitSpeed: speed, spriteTex, castInterval, castSound, castPayload },
                l: life, ang: startAngle
            })
        },
        
        area: {
            randomDamage: ({ range = 8, dmg = 50, color = 0x88aaff, targetsPerTick = 4, life = 20, onDestroy = null } = {}) => ({
                traits: ['randomAreaDamage', 'ageLife'],
                p: { range, dmg, color, targetsPerTick, onDestroy }, l: life
            }),
            shockwave: ({ baseDmg = 20, maxRadius = 5, speed = 0.5, color = 0xffaa00 } = {}) => ({
                traits: ['shockwaveExpand'],
                p: { baseDmg, maxRadius, speed, color }
            })
        },
        ultimate: {
            snap: ({ delay = 10, range = 4, dmg = 999, color = 0xffaa44, shake = 12, flash = 0.6 } = {}) => ({
                traits: ['ultimateSnap'],
                p: { delay, range, dmg, color, shake, flash }, l: 1
            })
        },
        vfx: {
            trail: ({ tex = 'fx_nano', vx = 0, vy = -1, dragX = 0.92, dragY = 0.92, swirl = false } = {}) => ({
                trailTex: tex, trailVx: vx, trailVy: vy, trailDragX: dragX, trailDragY: dragY, trailSwirl: swirl
            })
        },
    };

    // ═══ MinitBehaviorBuilder ═══
    MD.MinitBehaviorBuilder = class MinitBehaviorBuilder {
        constructor(minit, arena) {
            MD.assert(minit && minit.id, '[MinitBehaviorBuilder] minit required');
            MD.assert(arena && arena.spawnEnt, '[MinitBehaviorBuilder] arena required');
            this.minit = minit; this.arena = arena; this.id = minit.id;
            this.owner = null;
        }
        setOwner(slot) { this.owner = slot; return this; }
        tex(name) {
            if (!name || name.startsWith('minit_') || !this.minit.vfx) return name;
            const short = name.replace(/^fx_/, '');
            return this.minit.vfx[short] ? `minit_${this.id}_vfx_${short}` : name;
        }
        _scopeP(p) {
            if (!p) return p;
            const s = { ...p };
            if (s.trailTex) s.trailTex = this.tex(s.trailTex);
            if (s.spriteTex) s.spriteTex = this.tex(s.spriteTex);
            if (s.preBurnTex) s.preBurnTex = this.tex(s.preBurnTex);
            if (s.castPayload && s.castPayload.p) s.castPayload = { ...s.castPayload, p: this._scopeP(s.castPayload.p) };
            if (Array.isArray(s.spawnOnDeath)) s.spawnOnDeath = s.spawnOnDeath.map(sub => ({ ...sub, p: this._scopeP(sub.p) }));
            return s;
        }
        spawn(behaviorProps, overrides = {}) {
            const merged = { ...behaviorProps, ...overrides, p: { ...(behaviorProps.p || {}), ...(overrides.p || {}) } };
            merged.p = this._scopeP(merged.p);
            if (merged.owner === undefined && this.owner) merged.owner = this.owner;
            if (behaviorProps.sound && MD.AudioSys) MD.AudioSys.play(behaviorProps.sound);
            return this.arena.spawnEnt(merged);
        }
        spawnMany(items) { for (const { behavior, overrides } of items) this.spawn(behavior, overrides); }
    };
})();