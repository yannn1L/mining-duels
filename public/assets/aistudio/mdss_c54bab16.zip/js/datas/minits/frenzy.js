// ==========================================
// MINIT: FRENZY — Risk-Reward Berserker
// Behaviors: area.randomDamage (onDestroy callback)
// Effects: frenzy (self-buff), blind (self-debuff), momentum (decay)
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    MINIT_DB.frenzy = {
        id: 'frenzy',
        name: "FRENZY",
        color: 0xff2244,
        roam: 0.4,
        cd: 5,
        desc: "Grows stronger with each rocks destroyed.",
        ability: {
            dmg: 30,
            radius: 6,
            targetsPerTick: 4,
            aoeLife: 12,
            killsPerFury: 5,
            maxFury: 5,
            furyDuration: 300,
            furyMagnitude: 0.25,
            decayTriggers: 8,
            blindDuration: 30,
            furyPulseDmg: 200,
            furyPulseRadius: 5
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/R:${ab.radius}/MAX:${ab.maxFury}`,

        // ═══════════════════════════════════════
        // TEXTURE — predator merah
        // =======================================
        textures: {
            base: (g, c) => {
                // Body: segitiga runcing ke atas (agresif)
                g.beginFill(0x220000, 1);
                g.moveTo(0, -12);
                g.lineTo(10, 8);
                g.lineTo(-10, 8);
                g.lineTo(0, -12);
                g.endFill();
                // Outline merah
                g.lineStyle(2, c, 1);
                g.moveTo(0, -12);
                g.lineTo(10, 8);
                g.lineTo(-10, 8);
                g.lineTo(0, -12);
                // Duri di sisi (spikes)
                g.lineStyle(2, c, 0.9);
                g.moveTo(-10, 8);  g.lineTo(-14, 10);
                g.moveTo(10, 8);   g.lineTo(14, 10);
                g.moveTo(-6, -2);  g.lineTo(-11, -1);
                g.moveTo(6, -2);   g.lineTo(11, -1);
                // Mata tunggal besar
                g.beginFill(0xffffff, 1).drawCircle(0, -2, 4).endFill();
                g.beginFill(c, 1).drawCircle(0, -2, 2.5).endFill();
                g.beginFill(0x000000, 1).drawCircle(0, -2, 1.2).endFill();
                g.beginFill(0xffffff, 0.9).drawCircle(-1, -3, 0.6).endFill();
                // Mulut bergerigi
                g.beginFill(0xffffff, 0.9);
                g.moveTo(-6, 5);
                g.lineTo(-3, 8); g.lineTo(0, 5);
                g.lineTo(3, 8);  g.lineTo(6, 5);
                g.lineTo(6, 6);  g.lineTo(-6, 6);
                g.lineTo(-6, 5);
                g.endFill();
            }
        },

        // ═══════════════════════════════════════
        // VFX SCOPED
        // =======================================
        vfx: {
            fury_aura: (g, c) => {
                g.lineStyle(1, c, 0.7).drawCircle(0, 0, 6);
                g.lineStyle(1, 0xffffff, 0.9).drawCircle(0, 0, 3);
                g.beginFill(c, 0.4).drawCircle(0, 0, 4).endFill();
            },
            kill_burst: (g, c) => {
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 2).endFill();
                g.beginFill(c, 0.9).drawCircle(0, 0, 4).endFill();
                g.lineStyle(1, c, 0.8);
                for (let i = 0; i < 4; i++) {
                    const ang = (i / 4) * Math.PI * 2;
                    g.moveTo(0, 0);
                    g.lineTo(Math.cos(ang) * 7, Math.sin(ang) * 7);
                }
            },
            fury_pulse: (g, c) => {
                g.beginFill(0xffaa00, 0.9).drawCircle(0, 0, 8).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 4).endFill();
                g.lineStyle(2, 0xff2200, 0.9);
                for (let i = 0; i < 8; i++) {
                    const ang = (i / 8) * Math.PI * 2;
                    g.moveTo(0, 0);
                    g.lineTo(Math.cos(ang) * 14, Math.sin(ang) * 14);
                }
            }
        },

        // ═══════════════════════════════════════
        // INIT
        // =======================================
        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);
            s.fury = 0;
            s.killCount = 0;
            s.triggersSinceKill = 0;
            s._wasBlind = false;
        },

        // ═══════════════════════════════════════
        // TRIGGER
        // =======================================
        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            const dmgMul = slot.modifiers.dmgMul || 1;
            s.triggersSinceKill++;

            // ═══ Spawn AoE damage dengan onDestroy callback ═══
            // Closure `self` untuk capture `s`
            const self = s;
            const aoeDmg = s.builder.spawn(
                BEHAVIORS.area.randomDamage({
                    range: ab.radius,
                    dmg: ab.dmg * dmgMul,
                    color: slot.md.color,
                    targetsPerTick: ab.targetsPerTick,
                    life: ab.aoeLife,
                    onDestroy: (x, y, arena, owner) => {
                        // Rock hancur → increment killCount
                        self.killCount++;
                        self.triggersSinceKill = 0;

                        // VFX kill burst
                        const p = arena.getPixelCoords(x, y);
                        arena.fxPool.spawnPhysics('minit_frenzy_vfx_kill_burst',
                            p.px, p.py,
                            FastMath.randRange(-1, 1),
                            FastMath.randRange(-2, -0.5),
                            15, 0.9, 0.9, 1);
                    }
                }),
                { x: slot.log.x, y: slot.log.y }
            );

            // ═══ Cek naik fury ═══
            if (s.killCount >= ab.killsPerFury && s.fury < ab.maxFury) {
                s.killCount = 0;
                s.fury++;
                _applyFury(s, slot, a);
                AudioSys.play('swarm', 0.6);
            }

            // ═══ Cek fury max → pulse + blind ═══
            if (s.fury >= ab.maxFury) {
                _fireFuryPulse(s, slot, a);
            }

            // ═══ Cek decay (tidak ada kill selama N trigger) ═══
            if (s.triggersSinceKill >= ab.decayTriggers && s.fury > 0) {
                s.fury--;
                s.triggersSinceKill = 0;
                s.killCount = 0;
                _applyFury(s, slot, a);
                AudioSys.play('click', 0.5);
            }
        },

        // ═══════════════════════════════════════
        // UPDATE — visual berdasarkan fury
        // =======================================
        onUpdate: (s, a, spr, slot) => {
            const ab = slot.md.ability;
            const furyPct = s.fury / ab.maxFury;

            // Aura pulse
            const pulse = 0.5 + Math.sin(a.simTicks * (0.08 + furyPct * 0.15)) * 0.5;
            slot.animScale.tX = 1 + pulse * (0.05 + furyPct * 0.15);
            slot.animScale.tY = 1 - pulse * (0.03 + furyPct * 0.1);

            // Warna bertransisi merah → kuning berdasarkan fury
            if (s.fury === 0) {
                spr.tint = 0xffffff;
            } else if (s.fury >= ab.maxFury) {
                spr.tint = (a.simTicks % 6 < 3) ? 0xffff00 : 0xffaa00;
            } else {
                // Interpolasi merah → oranye → kuning
                const t = furyPct;
                const r = 0xff;
                const g = Math.floor(0x22 + (0xdd - 0x22) * t);
                const b = Math.floor(0x44 + (0x00 - 0x44) * t);
                spr.tint = (r << 16) | (g << 8) | b;
            }

            // Aura di sekitar minit (berdasarkan fury)
            if (s.fury > 0 && a.simTicks % Math.max(3, 10 - s.fury) === 0) {
                const p = a.getPixelCoords(slot.log.x, slot.log.y);
                const ang = (a.simTicks * 0.08) % (Math.PI * 2);
                const rad = 10 + s.fury * 2;
                a.fxPool.spawnPhysics('minit_frenzy_vfx_fury_aura',
                    p.px + Math.cos(ang) * rad,
                    p.py + Math.sin(ang) * rad,
                    0, -0.5, 12, 0.92, 0.92, 1);
            }
        }
    };

    // ═══════════════════════════════════════
    // HELPER — apply/update frenzy effect
    // =======================================
    function _applyFury(s, slot, a) {
        const ab = slot.md.ability;

        // Remove dulu, biar onRemove revert dmgMul
        slot.removeEffect('frenzy');

        if (s.fury > 0) {
            slot.addEffect('frenzy', {
                duration: ab.furyDuration,
                magnitude: 1 + s.fury * ab.furyMagnitude,
                source: slot
            });
        }

        // Feedback visual
        const p = a.getPixelCoords(slot.log.x, slot.log.y);
        a.fxPool.spawnShockwave(p.px, p.py, 0xff2244, 40 + s.fury * 20, 3);
    }

    // ═══════════════════════════════════════
    // HELPER — fury pulse (AoE besar + blind)
    // =======================================
    function _fireFuryPulse(s, slot, a) {
        const ab = slot.md.ability;
        const dmgMul = slot.modifiers.dmgMul || 1;

        // Apply blind ke diri sendiri (downside)
        if (!s._wasBlind) {
            slot.addEffect('blind', {
                duration: ab.blindDuration,
                magnitude: 1,
                source: slot
            });
            s._wasBlind = true;
            AudioSys.play('devour', 0.8);
        }

        // AoE pulse
        const cx = slot.log.x;
        const cy = slot.log.y;
        const R = ab.furyPulseRadius;
        for (let dy = -R; dy <= R; dy++) {
            for (let dx = -R; dx <= R; dx++) {
                const dist = Math.hypot(dx, dy);
                if (dist > R) continue;
                a.dmg(cx + dx, cy + dy, ab.furyPulseDmg * dmgMul, true, 0xffaa00, slot);
            }
        }

        // VFX
        const p = a.getPixelCoords(cx, cy);
        a.fxPool.spawnShockwave(p.px, p.py, 0xffaa00, 200, 8);
        for (let i = 0; i < 20; i++) {
            const ang = (i / 20) * Math.PI * 2;
            a.fxPool.spawnPhysics('minit_frenzy_vfx_fury_pulse',
                p.px + Math.cos(ang) * 20,
                p.py + Math.sin(ang) * 20,
                Math.cos(ang) * 4,
                Math.sin(ang) * 4,
                25, 0.9, 0.9, 1);
        }

        a.shake = Math.max(a.shake, 10);
        a.triggerFlash(0.4);

        // Reset fury + blind flag
        s.fury = 0;
        s.killCount = 0;
        s.triggersSinceKill = 0;
        s._wasBlind = false;

        // Remove frenzy effect (karena fury reset)
        slot.removeEffect('frenzy');
    }
})();