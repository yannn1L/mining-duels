(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder, Textures } = MD;

    MINIT_DB.moth = {
        id: 'moth', name: "MOTH", color: 0x88ffcc, roam: 0.8, cd: 45,
        desc: "Incubates, then hatches to drop nuke spores.",
        ability: { dmg: 500, range: 3, shake: 15, flash: 0.6, hatchTime: 480 },
        getStatsStr: (ab) => `SPORE:${ab.dmg}/7x7`,
        textures: {
            base: (g,c)=>(g.lineStyle(0),[[-2,-7,4,0x88ffcc,1.00],[-3,-6,1,0x9cddc5,1.00],[-2,-6,5,0x88ffcc,1.00],[-4,-5,2,0x88ffcc,1.00],[-2,-5,1,0x9cddc5,1.00],[-1,-5,5,0x88ffcc,1.00],[-4,-4,3,0x88ffcc,1.00],[-1,-4,1,0x9cddc5,1.00],[0,-4,4,0x88ffcc,1.00],[-5,-3,2,0x9cddc5,1.00],[-3,-3,3,0x88ffcc,1.00],[0,-3,2,0x9cddc5,1.00],[2,-3,3,0x88ffcc,1.00],[-5,-2,1,0x88ffcc,1.00],[-4,-2,2,0x9cddc5,1.00],[-2,-2,4,0x88ffcc,1.00],[2,-2,1,0x9cddc5,1.00],[3,-2,2,0x88ffcc,1.00],[-5,-1,1,0x88ffcc,1.00],[-4,-1,2,0x9cddc5,1.00],[-2,-1,5,0x88ffcc,1.00],[3,-1,1,0x9cddc5,1.00],[4,-1,1,0x88ffcc,1.00],[-5,0,2,0x88ffcc,1.00],[-3,0,2,0x9cddc5,1.00],[-1,0,5,0x88ffcc,1.00],[4,0,1,0x9cddc5,1.00],[-5,1,3,0x88ffcc,1.00],[-2,1,2,0x9cddc5,1.00],[0,1,5,0x88ffcc,1.00],[-5,2,3,0x88ffcc,1.00],[-2,2,2,0x9cddc5,1.00],[0,2,5,0x88ffcc,1.00],[-4,3,3,0x88ffcc,1.00],[-1,3,2,0x9cddc5,1.00],[1,3,3,0x88ffcc,1.00],[-4,4,4,0x88ffcc,1.00],[0,4,1,0x9cddc5,1.00],[1,4,3,0x88ffcc,1.00],[-3,5,3,0x88ffcc,1.00],[0,5,2,0x9cddc5,1.00],[2,5,1,0x88ffcc,1.00],[-2,6,3,0x88ffcc,1.00],[1,6,1,0x9cddc5,1.00]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill())),
            hatched: (g,c)=>(g.lineStyle(0),[[-4,-7,1,0x88ffcc,0.80],[3,-7,1,0x88ffcc,0.80],[-9,-6,1,0x000000,1.00],[-3,-6,1,0x88ffcc,0.80],[2,-6,1,0x88ffcc,0.80],[8,-6,1,0x000000,1.00],[-8,-5,2,0x000000,1.00],[-4,-5,1,0x88ffcc,0.80],[-3,-5,1,0x88ffcc,0.96],[2,-5,1,0x88ffcc,0.96],[3,-5,1,0x88ffcc,0.80],[6,-5,2,0x000000,1.00],[-8,-4,1,0x000000,1.00],[-7,-4,1,0x88ffcc,1.00],[-6,-4,3,0x000000,1.00],[-2,-4,1,0x88ffcc,0.80],[1,-4,1,0x88ffcc,0.80],[3,-4,3,0x000000,1.00],[6,-4,1,0x88ffcc,1.00],[7,-4,1,0x000000,1.00],[-8,-3,1,0x000000,1.00],[-7,-3,4,0x88ffcc,1.00],[-3,-3,6,0x000000,1.00],[3,-3,4,0x88ffcc,1.00],[7,-3,1,0x000000,1.00],[-8,-2,2,0x000000,1.00],[-6,-2,4,0x88ffcc,1.00],[-2,-2,4,0xff0055,1.00],[2,-2,4,0x88ffcc,1.00],[6,-2,2,0x000000,1.00],[-7,-1,1,0x000000,1.00],[-6,-1,4,0x88ffcc,1.00],[-2,-1,4,0xff0055,1.00],[2,-1,4,0x88ffcc,1.00],[6,-1,1,0x000000,1.00],[-7,0,1,0x000000,1.00],[-6,0,4,0x88ffcc,1.00],[-2,0,1,0x000000,1.00],[-1,0,2,0xffffff,1.00],[1,0,1,0x000000,1.00],[2,0,4,0x88ffcc,1.00],[6,0,1,0x000000,1.00],[-7,1,6,0x000000,1.00],[-1,1,2,0xffffff,1.00],[1,1,6,0x000000,1.00],[-3,2,2,0x000000,1.00],[-1,2,2,0xffffff,1.00],[1,2,2,0x000000,1.00],[-3,3,2,0x000000,1.00],[-1,3,2,0xffffff,1.00],[1,3,2,0x000000,1.00],[-4,4,1,0x000000,1.00],[-3,4,1,0x88ffcc,1.00],[-2,4,4,0x000000,1.00],[2,4,1,0x88ffcc,1.00],[3,4,1,0x000000,1.00],[-4,5,3,0x000000,1.00],[1,5,3,0x000000,1.00],[-5,6,1,0x000000,1.00],[4,6,1,0x000000,1.00]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill()))
        },
        vfx: {
            acid: (g,c)=>(g.lineStyle(0),[[2,-8,1,0x8800cd,0.90],[0,-7,2,0x8800cd,0.90],[2,-7,1,0x58009c,0.97],[3,-7,2,0x8800cd,0.90],[-1,-6,1,0x8800cd,0.90],[0,-6,5,0x58009c,0.97],[5,-6,1,0x8800cd,0.90],[-1,-5,1,0x8800cd,0.90],[0,-5,2,0x58009c,0.97],[2,-5,1,0xffffff,1.00],[3,-5,2,0x58009c,0.97],[5,-5,1,0x8800cd,0.90],[-2,-4,1,0x8800cd,0.90],[-1,-4,2,0x58009c,0.97],[1,-4,3,0xffffff,1.00],[4,-4,2,0x58009c,0.97],[6,-4,1,0x8800cd,0.90],[-3,-3,1,0x8800cd,0.90],[-1,-3,1,0x8800cd,0.90],[0,-3,2,0x58009c,0.97],[2,-3,1,0xffffff,1.00],[3,-3,2,0x58009c,0.97],[5,-3,1,0x8800cd,0.90],[-5,-2,2,0x8800cd,0.90],[-3,-2,1,0x58009c,0.97],[-2,-2,2,0x8800cd,0.90],[0,-2,5,0x58009c,0.97],[5,-2,1,0x8800cd,0.90],[-6,-1,1,0x8800cd,0.90],[-5,-1,5,0x58009c,0.97],[0,-1,2,0x8800cd,0.90],[2,-1,1,0x58009c,0.97],[3,-1,2,0x8800cd,0.90],[-6,0,1,0x8800cd,0.90],[-5,0,2,0x58009c,0.97],[-3,0,1,0xffffff,1.00],[-2,0,2,0x58009c,0.97],[0,0,1,0x8800cd,0.90],[2,0,4,0x8800cd,0.90],[-7,1,1,0x8800cd,0.90],[-6,1,2,0x58009c,0.97],[-4,1,3,0xffffff,1.00],[-1,1,2,0x58009c,0.97],[1,1,1,0x8800cd,0.90],[2,1,4,0x58009c,0.97],[6,1,1,0x8800cd,0.90],[-6,2,1,0x8800cd,0.90],[-5,2,2,0x58009c,0.97],[-3,2,1,0xffffff,1.00],[-2,2,2,0x58009c,0.97],[0,2,1,0x8800cd,0.90],[1,2,6,0x58009c,0.97],[7,2,1,0x8800cd,0.90],[-6,3,1,0x8800cd,0.90],[-5,3,5,0x58009c,0.97],[0,3,1,0x8800cd,0.90],[1,3,2,0x58009c,0.97],[3,3,2,0xffffff,1.00],[5,3,2,0x58009c,0.97],[7,3,1,0x8800cd,0.90],[-5,4,2,0x8800cd,0.90],[-3,4,1,0x58009c,0.97],[-2,4,3,0x8800cd,0.90],[1,4,2,0x58009c,0.97],[3,4,2,0xffffff,1.00],[5,4,2,0x58009c,0.97],[7,4,1,0x8800cd,0.90],[-3,5,1,0x8800cd,0.90],[0,5,1,0x8800cd,0.90],[1,5,6,0x58009c,0.97],[7,5,1,0x8800cd,0.90],[1,6,1,0x8800cd,0.90],[2,6,4,0x58009c,0.97],[6,6,1,0x8800cd,0.90],[2,7,4,0x8800cd,0.90]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill()))
        },
        onInit: (s, a, slot) => {
            const md = slot ? slot.md : a.md;
            s.isHatched = false; s.ticks = 0;
            s.builder = new MinitBehaviorBuilder(md, a);
            if (slot) s.builder.setOwner(slot);
        },
        onUpdate: (s, a, spr, slot) => {
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            if (s.isHatched) return;
            if (++s.ticks % 10 === 0) {
                a.shake = 1;
                const as = slot ? slot.animScale : a.animScale;
                as.tX = 1.1; as.tY = 0.9;
            }
            if (s.ticks >= ab.hatchTime - 10 && s.ticks % 2 === 0) a.triggerFlash(0.2);
            if (s.ticks >= ab.hatchTime) {
                s.isHatched = true;
                AudioSys.play('win', 1.5);
                a.triggerFlash(1);
                spr.texture = Textures[`minit_${md.id}_hatched`];
                const log = slot ? slot.log : a.mLog;
                const p = a.getPixelCoords(log.x, log.y);
                a.fxPool.spawnShockwave(p.px, p.py, md.color, 150, 8);
                for (let i = 0; i < 12; i++) {
                    const ang = FastMath.rand() * Math.PI * 2;
                    a.fxPool.spawnPhysics(`minit_${md.id}_vfx_acid`,
                        p.px + Math.cos(ang) * 6, p.py + Math.sin(ang) * 6,
                        Math.cos(ang) * FastMath.randRange(1, 3),
                        Math.sin(ang) * FastMath.randRange(1, 3),
                        25, 0.92, 0.92, 1);
                }
            }
        },
        onTrigger: (s, a, slot) => {
            if (!s.isHatched) return;
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            AudioSys.play('swarm');
            const log = slot ? slot.log : a.mLog;
            const tx = FastMath.randRange(3, CFG.GRID.COLS - 4) | 0;
            const ty = Math.min(log.y + FastMath.randRange(2, 7) | 0, CFG.GRID.MAX_DEPTH - 1);
            s.builder.spawn(
                BEHAVIORS.projectile.targeted({
                    dmg: ab.dmg, radius: ab.range, color: md.color,
                    shake: ab.shake, flash: ab.flash,
                    trailTex: 'fx_acid', trailSwirl: true, tx, ty
                }),
                { x: log.x, y: log.y }
            );
        }
    };
})();