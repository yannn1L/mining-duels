// ==========================================
// MINIT: TURRET
// Deploys static sentries that fire fan spread below
// Behaviors: projectile.straight (payload)
// Traits: renderSprite, multiCast, ageLife (existing + new generic)
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    Object.assign(MD.AUDIO_PROFS, {
        turret_deploy: {
            t: 'square', f0: 300, f1: 800, v: 0.04, d: 0.3, ramp: 'exp'
        },
        turret_fire: {
            t: 'sawtooth', f0: 900, f1: 200, v: 0.06, d: 0.15, ramp: 'exp'
        }
    });

    MINIT_DB.turret = {
        id: 'turret',
        name: "TURRET",
        color: 0x88ff44,
        roam: 0.5,
        cd: 25,
        desc: "Deploys sentries that fire fan spreads below.",
        ability: {
            dmg: 25,
            boltSpeed: 1.5,
            turretLife: 300,
            castInterval: 25,
            castCount: 6,
            castSpread: 0.8,
            maxTurrets: 30
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/N:${ab.castCount}/MAX:${ab.maxTurrets}`,

        textures: {
            base: (g, c) => {
                g.beginFill(0x1a1a1a, 1).drawRect(-7, -3, 14, 9).endFill();
                g.lineStyle(1, c, 1).drawRect(-7, -3, 14, 9);
                g.beginFill(c, 1);
                g.moveTo(-5, -3);
                g.lineTo(-3, -8);
                g.lineTo(3, -8);
                g.lineTo(5, -3);
                g.closePath();
                g.endFill();
                g.beginFill(0xff2222, 1).drawCircle(0, -8, 1.5).endFill();
                // Laras kipas (3 laras)
                g.beginFill(0x555555, 1);
                g.drawRect(-3, 6, 1.5, 3);
                g.drawRect(-0.75, 6, 1.5, 3);
                g.drawRect(1.5, 6, 1.5, 3);
                g.endFill();
            }
        },

        vfx: {
            turret_body: (g, c) => {
                g.beginFill(0x1a1a1a, 1).drawRect(-5, -3, 10, 7).endFill();
                g.lineStyle(1, c, 1).drawRect(-5, -3, 10, 7);
                g.beginFill(c, 1);
                g.moveTo(-3, -3);
                g.lineTo(-2, -6);
                g.lineTo(2, -6);
                g.lineTo(3, -3);
                g.closePath();
                g.endFill();
                g.beginFill(0xff2222, 1).drawCircle(0, -6, 1).endFill();
            },
            laser_bolt: (g, c) => {
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1.5).endFill();
                g.beginFill(c, 0.9).drawCircle(0, 0, 3).endFill();
                g.beginFill(c, 0.4).drawCircle(0, 0, 5).endFill();
            },
            turret_deploy: (g, c) => {
                g.lineStyle(2, c, 1).drawCircle(0, 0, 5);
                g.beginFill(c, 0.5).drawCircle(0, 0, 3).endFill();
            }
        },

        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);
            s.turrets = [];
        },

        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            const dmgMul = slot.modifiers.dmgMul || 1;

            s.turrets = s.turrets.filter(t => t && t.active && !t.dead);

            if (s.turrets.length >= ab.maxTurrets) {
                const oldest = s.turrets[0];
                if (oldest) {
                    oldest.l = ab.turretLife;
                    oldest.maxL = ab.turretLife;
                }
                return;
            }

            // ═══ Payload: proyektil tunggal (multiCast akan spawn banyak) ═══
            const boltPayload = {
                traits: ['moveDirection', 'ageLife', 'damageOnHit', 'trailParticles'],
                p: {
                    dmg: ab.dmg * dmgMul,
                    color: 0x88ff44,
                    trailTex: 'laser_bolt',
                    trailVy: -0.3,
                    shake: 0
                },
                l: 20,
                dx: 0, dy: ab.boltSpeed       // default ke bawah, akan di-override multiCast
            };

            // ═══ DEPLOY turret ═══
            const turret = s.builder.spawn({
                traits: ['renderSprite', 'multiCast', 'ageLife'],
                p: {
                    spriteTex: 'turret_body',
                    castInterval: ab.castInterval,
                    castCount: ab.castCount,
                    castSpread: ab.castSpread,
                    castBaseAngle: Math.PI / 2,       // ke bawah
                    castSpeed: ab.boltSpeed,
                    castPayload: boltPayload,
                    castSound: 'turret_fire'
                },
                l: ab.turretLife
            }, { x: slot.log.x, y: slot.log.y });

            if (turret) s.turrets.push(turret);

            const p = a.getPixelCoords(slot.log.x, slot.log.y);
            a.fxPool.spawnShockwave(p.px, p.py, 0x88ff44, 50, 3);
            for (let i = 0; i < 8; i++) {
                const ang = (i / 8) * Math.PI * 2;
                a.fxPool.spawnPhysics('minit_turret_vfx_turret_deploy',
                    p.px + Math.cos(ang) * 8,
                    p.py + Math.sin(ang) * 8,
                    Math.cos(ang) * 1.5,
                    Math.sin(ang) * 1.5,
                    18, 0.9, 0.9, 1);
            }
            a.shake = Math.max(a.shake, 3);
            AudioSys.play('turret_deploy', 0.7);
        },

        onUpdate: (s, a, spr, slot) => {
            const bob = Math.sin(a.simTicks * 0.12) * 0.05;
            slot.animScale.tX = 1 + bob;
            slot.animScale.tY = 1 - bob;

            const cd = slot.md.cd / (slot.modifiers.speedMul || 1);
            if (slot.log.t >= cd - 8) {
                spr.tint = (a.simTicks % 6 < 3) ? 0xaaffaa : 0xffffff;
            } else {
                spr.tint = 0xffffff;
            }

            if (a.simTicks % 60 === 0) {
                s.turrets = s.turrets.filter(t => t && t.active && !t.dead);
            }
        }
    };
})();