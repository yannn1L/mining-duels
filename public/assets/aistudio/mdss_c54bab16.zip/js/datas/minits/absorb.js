(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    MINIT_DB.absorb = {
        id: 'absorb', name: "ABSORB", color: 0xff4422, roam: 0.05, cd: 15,
        desc: "Inhales blocks like 02.",
        ability: {
            baseDmg: 20, scaling: 1.5, shake: 3, flash: 0.1,
            baseRange: 1, rangeScale: 0.025,
            baseTargets: 3, targetScale: 0.027, maxTargets: 30,
            pullLife: 15, pullTrail: 'fx_nano'
        },
        getStatsStr: (ab) => `DMG:${ab.baseDmg}+|SCL:${ab.scaling}`,

        // ===== SPRITE: VORTEX (spiral merah-hitam) =====
        textures: {
            base: (g,c)=>(g.lineStyle(0),[[-3,-9,6,0x000000,0.90],[-5,-8,10,0x000000,0.90],[-6,-7,3,0x000000,0.90],[-2,-7,5,0xff4422,1.00],[3,-7,3,0x000000,0.90],[-7,-6,3,0x000000,0.90],[-4,-6,2,0xff4422,1.00],[-2,-6,2,0xffc8bd,1.00],[0,-6,1,0x000000,0.70],[1,-6,3,0xff4422,1.00],[4,-6,3,0x000000,0.90],[-8,-5,3,0x000000,0.90],[-5,-5,3,0xff4422,1.00],[-2,-5,2,0x000000,0.91],[0,-5,2,0x000000,0.70],[2,-5,3,0xff4422,1.00],[5,-5,3,0x000000,0.90],[-8,-4,2,0x000000,0.90],[-6,-4,3,0xff4422,1.00],[-3,-4,3,0x000000,0.91],[0,-4,4,0x000000,0.70],[4,-4,2,0xff4422,1.00],[6,-4,2,0x000000,0.90],[-9,-3,2,0x000000,0.90],[-7,-3,3,0xff4422,1.00],[-4,-3,2,0x000000,0.91],[-2,-3,1,0x000000,0.99],[-1,-3,1,0x000000,0.91],[0,-3,1,0x000000,0.70],[1,-3,1,0x000000,0.91],[2,-3,2,0x000000,0.70],[4,-3,3,0xff4422,1.00],[7,-3,2,0x000000,0.90],[-9,-2,2,0x000000,0.90],[-7,-2,2,0xff4422,1.00],[-5,-2,1,0x000000,0.70],[-4,-2,1,0x000000,0.91],[-3,-2,1,0x000000,0.99],[-2,-2,1,0x000000,1.00],[-1,-2,1,0xfefefe,1.00],[0,-2,1,0xe9e9e9,1.00],[1,-2,1,0xb3b3b3,1.00],[2,-2,1,0x000000,0.91],[3,-2,2,0x000000,0.70],[5,-2,2,0xff4422,1.00],[7,-2,2,0x000000,0.90],[-9,-1,2,0x000000,0.90],[-7,-1,2,0xff4422,1.00],[-5,-1,2,0x000000,0.91],[-3,-1,1,0x000000,0.97],[-2,-1,1,0xfefefe,1.00],[-1,-1,1,0xf8f8f8,1.00],[0,-1,2,0xb3b3b3,1.00],[2,-1,3,0x000000,0.70],[5,-1,2,0xff4422,1.00],[7,-1,2,0x000000,0.90],[-9,0,2,0x000000,0.90],[-7,0,2,0xff4422,1.00],[-5,0,2,0x000000,0.91],[-3,0,1,0x000000,0.70],[-2,0,1,0xe9e9e9,1.00],[-1,0,1,0xb3b3b3,1.00],[0,0,1,0x000000,1.00],[1,0,1,0xb3b3b3,1.00],[2,0,3,0x000000,0.70],[5,0,2,0xff4422,1.00],[7,0,2,0x000000,0.90],[-9,1,2,0x000000,0.90],[-7,1,1,0xff4422,1.00],[-6,1,1,0xffc8bd,1.00],[-5,1,1,0x000000,0.91],[-3,1,1,0x000000,0.70],[-2,1,4,0xb3b3b3,1.00],[2,1,1,0x000000,0.91],[3,1,2,0x000000,0.70],[5,1,2,0xff4422,1.00],[7,1,2,0x000000,0.90],[-9,2,2,0x000000,0.90],[-6,2,2,0xffefec,1.00],[-2,2,3,0x000000,0.70],[1,2,1,0x000000,0.91],[2,2,2,0x000000,0.70],[4,2,2,0xff4422,1.00],[7,2,2,0x000000,0.90],[-8,3,2,0x000000,0.90],[-6,3,1,0xffefec,1.00],[-5,3,1,0xff4422,1.00],[0,3,3,0x000000,0.70],[3,3,3,0xff4422,1.00],[6,3,2,0x000000,0.90],[-8,4,3,0x000000,0.90],[-5,4,2,0xff4422,1.00],[0,4,2,0x000000,0.70],[3,4,2,0xff4422,1.00],[5,4,3,0x000000,0.90],[-7,5,1,0x000000,1.00],[-6,5,2,0x000000,0.90],[-4,5,2,0xff4422,1.00],[3,5,1,0xff4422,1.00],[4,5,3,0x000000,0.90],[-6,6,3,0x000000,0.90],[-2,6,1,0xff4422,1.00],[2,6,1,0xff4422,1.00],[3,6,3,0x000000,0.90],[-5,7,3,0x000000,0.90],[2,7,3,0x000000,0.90]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill()))
        },
    
        vfx: {
            vortex_ring: (g,c)=>(g.lineStyle(0),[[-5,-14,10,0x030303,0.30],[-7,-13,2,0x030303,0.30],[5,-13,2,0x030303,0.30],[-9,-12,2,0x030303,0.30],[7,-12,2,0x030303,0.30],[-10,-11,2,0x030303,0.30],[8,-11,2,0x030303,0.30],[-11,-10,1,0x030303,0.30],[-4,-10,8,0xff4421,0.60],[10,-10,1,0x030303,0.30],[-12,-9,2,0x030303,0.30],[-6,-9,2,0xff4421,0.60],[4,-9,2,0xff4421,0.60],[10,-9,2,0x030303,0.30],[-12,-8,1,0x030303,0.30],[-7,-8,1,0xff4421,0.60],[6,-8,1,0xff4421,0.60],[11,-8,1,0x030303,0.30],[-13,-7,1,0x030303,0.30],[-8,-7,1,0xff4421,0.60],[7,-7,1,0xff4421,0.60],[12,-7,1,0x030303,0.30],[-13,-6,1,0x030303,0.30],[-9,-6,1,0xff4421,0.60],[8,-6,1,0xff4421,0.60],[12,-6,1,0x030303,0.30],[-14,-5,1,0x030303,0.30],[-9,-5,1,0xff4421,0.60],[8,-5,1,0xff4421,0.60],[13,-5,1,0x030303,0.30],[-14,-4,1,0x030303,0.30],[-10,-4,1,0xff4421,0.60],[9,-4,1,0xff4421,0.60],[13,-4,1,0x030303,0.30],[-14,-3,1,0x030303,0.30],[-10,-3,1,0xff4421,0.60],[9,-3,1,0xff4421,0.60],[13,-3,1,0x030303,0.30],[-14,-2,1,0x030303,0.30],[-10,-2,1,0xff4421,0.60],[9,-2,1,0xff4421,0.60],[13,-2,1,0x030303,0.30],[-14,-1,1,0x030303,0.30],[-10,-1,1,0xff4421,0.60],[9,-1,1,0xff4421,0.60],[13,-1,1,0x030303,0.30],[-14,0,1,0x030303,0.30],[-10,0,1,0xff4421,0.60],[9,0,1,0xff4421,0.60],[13,0,1,0x030303,0.30],[-14,1,1,0x030303,0.30],[-10,1,1,0xff4421,0.60],[9,1,1,0xff4421,0.60],[13,1,1,0x030303,0.30],[-14,2,1,0x030303,0.30],[-10,2,1,0xff4421,0.60],[9,2,1,0xff4421,0.60],[13,2,1,0x030303,0.30],[-14,3,1,0x030303,0.30],[-10,3,1,0xff4421,0.60],[9,3,1,0xff4421,0.60],[13,3,1,0x030303,0.30],[-14,4,1,0x030303,0.30],[-9,4,1,0xff4421,0.60],[8,4,1,0xff4421,0.60],[13,4,1,0x030303,0.30],[-13,5,1,0x030303,0.30],[-9,5,1,0xff4421,0.60],[8,5,1,0xff4421,0.60],[12,5,1,0x030303,0.30],[-13,6,1,0x030303,0.30],[-8,6,1,0xff4421,0.60],[7,6,1,0xff4421,0.60],[12,6,1,0x030303,0.30],[-12,7,1,0x030303,0.30],[-7,7,1,0xff4421,0.60],[6,7,1,0xff4421,0.60],[11,7,1,0x030303,0.30],[-12,8,2,0x030303,0.30],[-6,8,2,0xff4421,0.60],[4,8,2,0xff4421,0.60],[10,8,2,0x030303,0.30],[-11,9,1,0x030303,0.30],[-4,9,8,0xff4421,0.60],[10,9,1,0x030303,0.30],[-10,10,2,0x030303,0.30],[8,10,2,0x030303,0.30],[-9,11,2,0x030303,0.30],[7,11,2,0x030303,0.30],[-7,12,2,0x030303,0.30],[5,12,2,0x030303,0.30],[-5,13,10,0x030303,0.30]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill())),
            pull_dot: (g,c)=>(g.lineStyle(0),[[-2,-3,4,0xff4422,1.00],[-3,-2,2,0xff4422,1.00],[-1,-2,2,0x4488ff,1.00],[1,-2,2,0xff4422,1.00],[-3,-1,1,0xff4422,1.00],[-2,-1,4,0x4488ff,1.00],[2,-1,1,0xff4422,1.00],[-3,0,1,0xff4422,1.00],[-2,0,4,0x4488ff,1.00],[2,0,1,0xff4422,1.00],[-3,1,2,0xff4422,1.00],[-1,1,2,0x4488ff,1.00],[1,1,2,0xff4422,1.00],[-2,2,4,0xff4422,1.00]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill())),
            devour_burst: (g,c)=>(g.lineStyle(0),[[-2,-5,4,0xff4322,0.80],[-4,-4,8,0xff4322,0.80],[-4,-3,2,0xff4322,0.80],[-2,-3,4,0xff694e,1.00],[2,-3,2,0xff4322,0.80],[-5,-2,2,0xff4322,0.80],[-3,-2,6,0xff694e,1.00],[3,-2,2,0xff4322,0.80],[-5,-1,2,0xff4322,0.80],[-3,-1,6,0xff694e,1.00],[3,-1,2,0xff4322,0.80],[-5,0,2,0xff4322,0.80],[-3,0,6,0xff694e,1.00],[3,0,2,0xff4322,0.80],[-5,1,2,0xff4322,0.80],[-3,1,6,0xff694e,1.00],[3,1,2,0xff4322,0.80],[-4,2,2,0xff4322,0.80],[-2,2,4,0xff694e,1.00],[2,2,2,0xff4322,0.80],[-4,3,8,0xff4322,0.80],[-2,4,4,0xff4322,0.80]].forEach(d=>g.beginFill(d[3],d[4]).drawRect(d[0],d[1],d[2],1).endFill()))
        },

        onInit: (s, a, slot) => {
            const md = slot ? slot.md : a.md;
            s.builder = new MinitBehaviorBuilder(md, a);
            if (slot) s.builder.setOwner(slot);
            s.ringPhase = 0;
        },

        onUpdate: (s, a, spr, slot) => {
            const md = slot ? slot.md : a.md;
            s.ringPhase += 0.08;
            // Ambient vortex ring tiap 6 tick
            if (a.simTicks % 6 === 0) {
                const log = slot ? slot.log : a.mLog;
                const p = a.getPixelCoords(log.x, log.y);
                const ang = s.ringPhase;
                const r = 12 + Math.sin(s.ringPhase) * 3;
                a.fxPool.spawnPhysics(`minit_${md.id}_vfx_vortex_ring`,
                    p.px + Math.cos(ang) * r,
                    p.py + Math.sin(ang) * r,
                    0, 0, 12, 0.9, 0.9, true);
            }
        },

        onTrigger: (s, a, slot) => {
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            const log = slot ? slot.log : a.mLog;

            const range = Math.min(CFG.GRID.COLS, Math.floor(ab.baseRange + a.stats.d * ab.rangeScale));
            const targets = [];
            const minX = a.clampX(log.x - range), maxX = a.clampX(log.x + range);
            const minY = a.clampY(log.y), maxY = a.clampY(log.y + range);
            for (let tx = minX; tx <= maxX; tx++)
                for (let ty = minY; ty <= maxY; ty++) {
                    const hp = a.getHP(tx, ty);
                    if (hp > 0 && hp !== 9999) targets.push({ x: tx, y: ty });
                }

            const maxT = Math.min(ab.maxTargets, targets.length,
                Math.floor(ab.baseTargets + a.stats.d * ab.targetScale));
            for (let i = 0; i < maxT; i++) {
                const j = i + ((FastMath.rand() * (targets.length - i)) | 0);
                const tmp = targets[i]; targets[i] = targets[j]; targets[j] = tmp;
            }

            const dmg = ab.baseDmg + a.stats.d * ab.scaling;
            let hitAny = false;

            for (let i = 0; i < maxT; i++) {
                const t = targets[i];
                if (a.dmg(t.x, t.y, dmg, true, md.color, slot)) {
                    hitAny = true;
                    // Pull particle dengan trail khusus absorb
                    s.builder.spawn(
                        BEHAVIORS.pull.toward({
                            targetRef: log, color: md.color,
                            trailTex: 'pull_dot', life: ab.pullLife
                        }),
                        { x: t.x, y: t.y }
                    );
                }
            }

            if (hitAny) {
                AudioSys.play('devour');
                a.shake = Math.min(15, ab.shake + a.stats.d / 20);
                const target = slot || a;
                target.baseScale = Math.min(3, 1 + a.stats.d / 80);
                if (target.animScale) { target.animScale.tX = 1.4; target.animScale.tY = 0.6; }

                // Burst devour di sprite
                const p = a.getPixelCoords(log.x, log.y);
                for (let i = 0; i < 8; i++) {
                    const ang = FastMath.rand() * Math.PI * 2;
                    a.fxPool.spawnPhysics(`minit_${md.id}_vfx_devour_burst`,
                        p.px + Math.cos(ang) * 4,
                        p.py + Math.sin(ang) * 4,
                        Math.cos(ang) * 1.5, Math.sin(ang) * 1.5,
                        18, 0.9, 0.9, true);
                }
                a.fxPool.spawnShockwave(p.px, p.py, md.color, 70, 3);
            } else if (targets.length) {
                AudioSys.play('hit');
            }
        }
    };
})();