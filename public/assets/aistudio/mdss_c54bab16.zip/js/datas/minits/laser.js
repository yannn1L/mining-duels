(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    MINIT_DB.laser = {
        id: 'laser', name: "LASER", color: 0x00ccff, roam: 0, cd: 24,
        desc: "Fires a piercing beam with devastating impact.",
        ability: {
            length: 5, dmg: 35, duration: 20, shake: 4, flash: 0.15,
            chargeFrames: 18,
            beamColors: { outer: 0x0088cc, core: 0x00ccff, hot: 0xffffff },
            beamWidths: { outer: 8, core: 4, hot: 2 },
            impactShrapnel: 10,
            postSmoke: 6,
            electric: {
                chargeArcCount: 4,
                chargeArcRate: 3,
                beamArcRate: 2,
                beamArcJitter: 20,
                impactArcCount: 6,
                impactArcRange: 40
            }
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}|CHG:${ab.chargeFrames}f`,

        textures: {
            base: (g, c) => {
                g.beginFill(0x1a1a2a).drawRect(-7, -7, 14, 14).endFill();
                g.beginFill(c).moveTo(0, -7).lineTo(7, 0).lineTo(0, 7).lineTo(-7, 0).endFill();
                g.beginFill(0xffffff).drawRect(-2, -2, 4, 4).endFill();
                g.lineStyle(1, 0xffffff, 0.6).drawCircle(0, 0, 3);
            }
        },

        vfx: {
            charge_ring: (g, c) => {
                g.lineStyle(2, c, 0.9).drawCircle(0, 0, 12);
                g.lineStyle(1, 0xffffff, 0.6).drawCircle(0, 0, 16);
            },
            charge_core: (g, c) => {
                g.beginFill(c, 1).drawCircle(0, 0, 3).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1.5).endFill();
            },
            electric_arc: (g, c) => {
                g.lineStyle(2, c, 1);
                g.moveTo(-4, -6).lineTo(-1, -2).lineTo(-3, 2).lineTo(2, 6);
                g.lineStyle(1, 0xffffff, 0.9);
                g.moveTo(-3, -5).lineTo(-2, -1).lineTo(0, 1).lineTo(3, 5);
                g.beginFill(0xffffff, 1).drawCircle(-1, -2, 1).drawCircle(2, 6, 1).endFill();
            },
            electric_spark: (g, c) => {
                g.beginFill(c, 1).drawCircle(0, 0, 2).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1).endFill();
                g.lineStyle(1, c, 0.8);
                for (let i = 0; i < 4; i++) {
                    const a = i * Math.PI / 2;
                    g.moveTo(0, 0).lineTo(Math.cos(a) * 5, Math.sin(a) * 5);
                }
            },
            beam_outer: (g, c) => {
                g.beginFill(c, 0.4).drawRect(-4, -8, 8, 16).endFill();
            },
            beam_core: (g, c) => {
                g.beginFill(c, 0.9).drawRect(-2, -8, 4, 16).endFill();
            },
            beam_hot: (g) => {
                g.beginFill(0xffffff, 1).drawRect(-1, -8, 2, 16).endFill();
            },
            impact_burst: (g, c) => {
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 4).endFill();
                g.beginFill(c, 0.8).drawCircle(0, 0, 7).endFill();
            },
            post_smoke: (g) => {
                g.beginFill(0xaaaaaa, 0.6).drawRect(-2, -2, 4, 4).endFill();
            }
        },

        onInit: (s, a, slot) => {
            const md = slot ? slot.md : a.md;
            s.builder = new MinitBehaviorBuilder(md, a);
            if (slot) s.builder.setOwner(slot);
            s.charging = false;
            s.chargeTicks = 0;
            s.chargeRings = 0;
        },

        onUpdate: (s, a, spr, slot) => {
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            const log = slot ? slot.log : a.mLog;
            const p = a.getPixelCoords(log.x, log.y);
            const el = ab.electric;

            if (s.charging) {
                s.chargeTicks++;
                const pulse = 1 + Math.sin(s.chargeTicks * 0.5) * 0.12;
                const as = slot ? slot.animScale : a.animScale;
                as.tX = pulse; as.tY = pulse;

                if (s.chargeTicks % 6 === 0) {
                    s.chargeRings++;
                    a.fxPool.spawnPhysics(`minit_${md.id}_vfx_charge_ring`,
                        p.px, p.py, 0, 0, 15, 0.95, 0.95, true);
                    AudioSys.play('click', 0.1);
                }

                if (s.chargeTicks % 3 === 0) {
                    a.fxPool.spawnPhysics(`minit_${md.id}_vfx_charge_core`,
                        p.px + FastMath.randRange(-6, 6),
                        p.py + FastMath.randRange(-6, 6),
                        0, -1, 8, 0.95, 0.95, true);
                }

                // ⚡ ELECTRIC ARCS around charging sprite
                if (s.chargeTicks % el.chargeArcRate === 0) {
                    for (let i = 0; i < el.chargeArcCount; i++) {
                        const ang = FastMath.rand() * Math.PI * 2;
                        const dist = FastMath.randRange(8, 16);
                        a.fxPool.spawnPhysics(`minit_${md.id}_vfx_electric_arc`,
                            p.px + Math.cos(ang) * dist,
                            p.py + Math.sin(ang) * dist,
                            FastMath.randRange(-1, 1), FastMath.randRange(-1, 1),
                            8, 0.92, 0.92, true);
                    }
                    // Spark burst kecil
                    a.fxPool.spawnPhysics(`minit_${md.id}_vfx_electric_spark`,
                        p.px + FastMath.randRange(-8, 8),
                        p.py + FastMath.randRange(-8, 8),
                        0, 0, 6, 1, 1, true);
                }

                if (s.chargeTicks >= ab.chargeFrames) {
                    fireBeam(s, a, slot);
                }
            }
        },

        onTrigger: (s, a, slot) => {
            if (s.charging) return;
            const md = slot ? slot.md : a.md;
            s.charging = true;
            s.chargeTicks = 0;
            s.chargeRings = 0;
            AudioSys.play('laser', 0.03);
            a.triggerFlash(0.1);
        }
    };

    function fireBeam(s, a, slot) {
        const md = slot ? slot.md : a.md;
        const ab = md.ability;
        const log = slot ? slot.log : a.mLog;
        const el = ab.electric;

        s.charging = false;
        s.chargeTicks = 0;

        AudioSys.play('laser', 1.0);
        a.triggerFlash(ab.flash);
        a.shake = ab.shake;

        const p = a.getPixelCoords(log.x, log.y);

        // Beam inti (damage)
        s.builder.spawn(
            BEHAVIORS.beam.vertical({
                dmg: ab.dmg, length: ab.length, color: md.color,
                shake: ab.shake, duration: ab.duration
            }),
            { x: log.x, y: log.y }
        );

        const endY = Math.min(log.y + ab.length, CFG.GRID.MAX_DEPTH - 1);
        const pEnd = a.getPixelCoords(log.x, endY);

        // 3-layer beam
        a.fxPool.spawnLaser(p.px, p.py, pEnd.px, pEnd.py,
            ab.beamColors.outer, ab.beamWidths.outer, ab.duration, false);
        a.fxPool.spawnLaser(p.px, p.py, pEnd.px, pEnd.py,
            ab.beamColors.core, ab.beamWidths.core, ab.duration, false);
        a.fxPool.spawnLaser(p.px, p.py, pEnd.px, pEnd.py,
            ab.beamColors.hot, ab.beamWidths.hot, ab.duration, false);

        // ⚡ ELECTRIC ARCS along the beam
        const arcCount = Math.ceil(ab.length * 2 * a.vfxLod);
        for (let i = 0; i < arcCount; i++) {
            const t = FastMath.rand();
            const ax = p.px + (pEnd.px - p.px) * t;
            const ay = p.py + (pEnd.py - p.py) * t;
            setTimeout(() => {
                a.fxPool.spawnPhysics(`minit_${md.id}_vfx_electric_arc`,
                    ax + FastMath.randRange(-el.beamArcJitter, el.beamArcJitter),
                    ay,
                    FastMath.randRange(-2, 2), FastMath.randRange(-1, 1),
                    8, 0.9, 0.9, true);
            }, i * 15);
        }

        // ⚡ ELECTRIC SPARKS at emitter muzzle
        for (let i = 0; i < 6; i++) {
            const ang = FastMath.rand() * Math.PI * 2;
            a.fxPool.spawnPhysics(`minit_${md.id}_vfx_electric_spark`,
                p.px + Math.cos(ang) * 4,
                p.py + Math.sin(ang) * 4,
                Math.cos(ang) * FastMath.randRange(1, 3),
                Math.sin(ang) * FastMath.randRange(1, 3),
                12, 0.92, 0.92, true);
        }

        // Impact burst + electric arcs di ujung beam
        setTimeout(() => {
            a.fxPool.spawnShockwave(pEnd.px, pEnd.py, md.color, 80, 5);
            a.fxPool.spawnPhysics(`minit_${md.id}_vfx_impact_burst`,
                pEnd.px, pEnd.py, 0, 0, 12, 1, 1, true);

            // ⚡ Lightning arcs radiating from impact point
            for (let i = 0; i < el.impactArcCount; i++) {
                const ang = FastMath.rand() * Math.PI * 2;
                const rad = FastMath.randRange(10, el.impactArcRange);
                a.fxPool.spawnPhysics(`minit_${md.id}_vfx_electric_arc`,
                    pEnd.px + Math.cos(ang) * rad,
                    pEnd.py + Math.sin(ang) * rad,
                    Math.cos(ang) * FastMath.randRange(-1, 1),
                    Math.sin(ang) * FastMath.randRange(-1, 1),
                    15, 0.9, 0.9, true);
            }

            // Shrapnel fisik
            for (let i = 0; i < ab.impactShrapnel; i++) {
                const ang = FastMath.rand() * Math.PI * 2;
                a.fxPool.spawnPhysics('fx_shrapnel',
                    pEnd.px + Math.cos(ang) * 4,
                    pEnd.py + Math.sin(ang) * 4,
                    Math.cos(ang) * FastMath.randRange(1, 3),
                    Math.sin(ang) * FastMath.randRange(1, 3),
                    20, 0.9, 0.9, true);
            }
            AudioSys.play('crush', 0.5);
        }, 60);

        // Post smoke
        for (let i = 0; i < ab.postSmoke; i++) {
            const smokeY = p.py + (i / ab.postSmoke) * (pEnd.py - p.py);
            setTimeout(() => {
                a.fxPool.spawnPhysics(`minit_${md.id}_vfx_post_smoke`,
                    p.px + FastMath.randRange(-4, 4),
                    smokeY,
                    FastMath.randRange(-0.5, 0.5),
                    FastMath.randRange(-1, -0.3),
                    25, 0.94, 0.97, true);
            }, i * 30);
        }
    }
})();