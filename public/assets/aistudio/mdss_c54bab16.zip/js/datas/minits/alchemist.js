// ==========================================
// MINIT: ALCHEMIST
// Throws potions directly below (moth-style)
// 5 potion types with unique payload effects
// Behaviors: projectile.targeted (moth-style)
// Effects: poison, slow (enemy), frenzy (self)
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    // ═══════════════════════════════════════
    // POTION DEFINITIONS (weighted random)
    // =======================================
    const POTIONS = [
        { type: 'acid',      weight: 30 },
        { type: 'lightning', weight: 25 },
        { type: 'fire',      weight: 25 },
        { type: 'frost',     weight: 15 },
        { type: 'void',      weight: 5 }
    ];
    const TOTAL_WEIGHT = POTIONS.reduce((s, p) => s + p.weight, 0);

    function rollPotion() {
        let r = FastMath.rand() * TOTAL_WEIGHT;
        for (const p of POTIONS) {
            r -= p.weight;
            if (r <= 0) return p.type;
        }
        return 'acid';
    }
    
    // ═══ LOCAL SFX ═══
    Object.assign(MD.AUDIO_PROFS, {
        alch_throw: {
            t: 'triangle',
            f0: 300,
            f1: 700,
            v: 0.1,
            d: 0.15,
            ramp: 'exp'
        },
        alch_pot_acid: {
            noise: true,
            d: 0.25,
            fType: 'bandpass',
            f0: 900,
            f1: 300,
            fQ: 2,
            v: 0.1,
            oF0: 250,
            oF1: 60
        },
        alch_pot_lightning: {
            t: 'square',
            f0: 1200,
            f1: 200,
            f2: 800,
            v: 0.1,
            d: 0.25,
            ramp: 'lin_exp'
        },
        alch_pot_fire: {
            noise: true,
            d: 0.35,
            fType: 'lowpass',
            f0: 1500,
            f1: 80,
            v: 0.3,
            oF0: 200,
            oF1: 50
        },
        alch_pot_frost: {
            noise: true,
            d: 0.3,
            fType: 'highpass',
            f0: 1500,
            f1: 800,
            v: 0.08
        },
        alch_pot_void: {
            t: 'sine',
            f0: 400,
            f1: 150,
            f2: 800,
            v: 0.15,
            d: 0.6,
            ramp: 'lin_exp'
        }
    });
    
    MINIT_DB.alchemist = {
        id: 'alchemist',
        name: "ALCHEMIST",
        color: 0xaa66ff,
        roam: 0,
        cd: 15,
        desc: "Throws random potions with varying effects.",
        ability: {
            dmg: 60,
            radius: 2,
            // Throw params (moth-style)
            throwRangeX: 5,        // horizontal random offset dari minit
            throwRangeY: 4,        // jarak ke bawah
            throwLife: 60,         // lifetime proyektil sebelum meledak
            // Effect params
            poisonDur: 300,
            poisonMag: 0.4,
            slowDur: 300,
            slowMag: 0.5,
            voidDelay: 60,
            voidRange: 4,
            voidDmg: 250
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/R:${ab.radius}/POT:5`,

        // ═══════════════════════════════════════
        // TEXTURE — labu alkemis 16×16
        // =======================================
        textures: {
            base: (g, c) => {
                // Badan bulat
                g.beginFill(c, 1).drawCircle(0, 2, 6).endFill();
                // Leher botol
                g.beginFill(c, 1).drawRect(-2.5, -7, 5, 5).endFill();
                // Tutup gabus
                g.beginFill(0x553322, 1).drawRect(-3, -9, 6, 2).endFill();
                // Cairan highlight
                g.beginFill(0xffffff, 0.3).drawCircle(0, 2, 4).endFill();
                // Bubble
                g.beginFill(0xffffff, 0.8).drawCircle(-1.5, 0, 0.8).endFill();
                // Kilap kaca
                g.beginFill(0xffffff, 0.9).drawCircle(-3, -1, 1).endFill();
            }
        },

        // ═══════════════════════════════════════
        // VFX SCOPED — 5 ramuan
        // =======================================
        vfx: {
            potion_acid: (g, c) => {
                g.beginFill(0x88ff44, 1).drawCircle(0, 0, 4).endFill();
                g.beginFill(0xffffff, 0.8).drawCircle(-1, -1, 1.5).endFill();
                g.beginFill(0x336611, 0.6).drawCircle(1, 1, 2).endFill();
            },
            potion_lightning: (g, c) => {
                g.beginFill(0xffff00, 1).drawCircle(0, 0, 4).endFill();
                g.lineStyle(1, 0xffffff, 1);
                g.moveTo(-3, -3).lineTo(0, 0).lineTo(3, -3);
                g.moveTo(-3, 3).lineTo(0, 0).lineTo(3, 3);
            },
            potion_fire: (g, c) => {
                g.beginFill(0xff4422, 1).drawCircle(0, 0, 4).endFill();
                g.beginFill(0xffaa00, 0.9).drawCircle(0, -1, 3).endFill();
                g.beginFill(0xffff00, 1).drawCircle(0, -2, 1.5).endFill();
            },
            potion_frost: (g, c) => {
                g.beginFill(0x00ccff, 1).drawCircle(0, 0, 4).endFill();
                g.lineStyle(1, 0xffffff, 0.9);
                g.moveTo(0, -4).lineTo(0, 4);
                g.moveTo(-4, 0).lineTo(4, 0);
            },
            potion_void: (g, c) => {
                g.beginFill(0x220044, 1).drawCircle(0, 0, 5).endFill();
                g.beginFill(0x8844ff, 0.9).drawCircle(0, 0, 3.5).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1).endFill();
            },
            potion_trail: (g, c) => {
                g.beginFill(c, 0.9).drawCircle(0, 0, 3).endFill();
                g.beginFill(0xffffff, 0.6).drawCircle(0, 0, 1.5).endFill();
            }
        },

        // ═══════════════════════════════════════
        // INIT
        // =======================================
        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);
            s.lastPotion = null;
            s.potionCounts = { acid: 0, lightning: 0, fire: 0, frost: 0, void: 0 };
        },

        // ═══════════════════════════════════════
        // TRIGGER
        // =======================================
        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            const dmgMul = slot.modifiers.dmgMul || 1;

            // Pilih ramuan random
            let potionType = rollPotion();
            if (potionType === s.lastPotion && FastMath.rand() < 0.5) {
                potionType = rollPotion();
            }
            s.lastPotion = potionType;
            s.potionCounts[potionType]++;

            // Random target (moth-style: langsung ke bawah + offset horizontal)
            const tx = a.clampX(slot.log.x + (FastMath.randRange(-ab.throwRangeX, ab.throwRangeX) | 0));
            const ty = a.clampY(slot.log.y + ab.throwRangeY);

            // Feedback throw
            const p = a.getPixelCoords(slot.log.x, slot.log.y);
            a.fxPool.spawnShockwave(p.px, p.py, slot.md.color, 30, 3);
            AudioSys.play('alch_throw', 0.7);

            // Dispatch
            switch (potionType) {
                case 'acid':      throwAcid(s, a, slot, ab, dmgMul, tx, ty); break;
                case 'lightning': throwLightning(s, a, slot, ab, dmgMul, tx, ty); break;
                case 'fire':      throwFire(s, a, slot, ab, dmgMul, tx, ty); break;
                case 'frost':     throwFrost(s, a, slot, ab, dmgMul, tx, ty); break;
                case 'void':      throwVoid(s, a, slot, ab, dmgMul, tx, ty); break;
            }
        },

        // ═══════════════════════════════════════
        // UPDATE
        // =======================================
        onUpdate: (s, a, spr, slot) => {
            const bob = Math.sin(a.simTicks * 0.12) * 0.06;
            slot.animScale.tX = 1 + bob;
            slot.animScale.tY = 1 - bob;

            const cd = slot.md.cd / (slot.modifiers.speedMul || 1);
            if (slot.log.t >= cd - 8) {
                spr.tint = (a.simTicks % 6 < 3) ? 0xddbbff : 0xffffff;
            } else {
                spr.tint = 0xffffff;
            }

            // Aura ungu
            if (a.simTicks % 20 === 0) {
                const p = a.getPixelCoords(slot.log.x, slot.log.y);
                const ang = (a.simTicks * 0.05) % (Math.PI * 2);
                a.fxPool.spawnPhysics('minit_alchemist_vfx_potion_trail',
                    p.px + Math.cos(ang) * 12,
                    p.py + Math.sin(ang) * 12,
                    0, -0.5, 12, 0.92, 0.92, 1);
            }
        }
    };

    // ═══════════════════════════════════════
    // HELPER — spawn projectile (moth-style)
    // =======================================
    function spawnProjectile(s, a, slot, ab, props, tx, ty) {
        return s.builder.spawn({
            traits: ['moveToTarget', 'trailParticles', 'ageLife', 'explodeOnDeath'],
            p: {
                dmg: props.dmg,
                radius: props.radius || ab.radius,
                color: props.color,
                shake: props.shake || 5,
                expSound: props.expSound || 'explosion',
                shockRad: props.shockRad || 80,
                trailTex: props.trailTex,
                trailVy: props.trailVy ?? -1,
                trailDragX: 0.92,
                trailDragY: 0.92,
                trailSwirl: false,
                spawnOnDeath: props.spawnOnDeath || null
            },
            tx, ty,
            l: ab.throwLife,
            maxL: ab.throwLife
        }, { x: slot.log.x, y: slot.log.y });
    }

    // ═══════════════════════════════════════
    // HANDLER: ACID — poison
    // =======================================
    function throwAcid(s, a, slot, ab, dmgMul, tx, ty) {
        spawnProjectile(s, a, slot, ab, {
            dmg: ab.dmg * 0.7 * dmgMul,
            radius: 2,
            color: 0x88ff44,
            trailTex: 'potion_acid',
            trailVy: -0.5,
            expSound: 'alch_pot_acid',
            shockRad: 70,
            shake: 4
        }, tx, ty);

        // Apply poison ke lawan
        const enemy = a.slots.find(x => x !== slot);
        if (enemy && !enemy.disabled) {
            enemy.addEffect('poison', {
                duration: ab.poisonDur,
                magnitude: ab.poisonMag,
                source: slot
            });
        }
    }

    // ═══════════════════════════════════════
    // HANDLER: LIGHTNING — spawn lightning saat mendarat
    // =======================================
    function throwLightning(s, a, slot, ab, dmgMul, tx, ty) {
        spawnProjectile(s, a, slot, ab, {
            dmg: ab.dmg * 0.4 * dmgMul,
            radius: 1,
            color: 0xffff00,
            trailTex: 'potion_lightning',
            trailVy: -0.5,
            expSound: 'alch_pot_lighting',
            shockRad: 60,
            shake: 5,
            spawnOnDeath: [{
                traits: ['ageLife', 'lightningDamage'],
                p: {
                    length: 5,
                    dmg: ab.dmg * 0.6 * dmgMul,
                    color: 0xffff00
                },
                l: 20,
                offsetX: 0,
                offsetY: 0
            }]
        }, tx, ty);
    }

    // ═══════════════════════════════════════
    // HANDLER: FIRE — self frenzy + big AoE
    // =======================================
    function throwFire(s, a, slot, ab, dmgMul, tx, ty) {
        spawnProjectile(s, a, slot, ab, {
            dmg: ab.dmg * 1.4 * dmgMul,
            radius: ab.radius + 1,
            color: 0xff4422,
            trailTex: 'alch_pot_fire',
            trailVy: -1.5,
            expSound: 'explosion',
            shockRad: 100,
            shake: 10
        }, tx, ty);
    }

    // ═══════════════════════════════════════
    // HANDLER: FROST — shockwave + slow
    // =======================================
    function throwFrost(s, a, slot, ab, dmgMul, tx, ty) {
        spawnProjectile(s, a, slot, ab, {
            dmg: ab.dmg * 0.3 * dmgMul,
            radius: 2,
            color: 0x00ccff,
            trailTex: 'potion_frost',
            trailVy: -0.5,
            expSound: 'alch_pot_frost',
            shockRad: 60,
            shake: 3,
            spawnOnDeath: [{
                traits: ['shockwaveExpand'],
                p: {
                    baseDmg: ab.dmg * 0.25 * dmgMul,
                    maxRadius: 4,
                    speed: 0.4,
                    color: 0x00ccff
                },
                offsetX: 0,
                offsetY: 0
            }]
        }, tx, ty);

        // Apply slow ke lawan
        const enemy = a.slots.find(x => x !== slot);
        if (enemy && !enemy.disabled) {
            enemy.addEffect('slow', {
                duration: ab.slowDur,
                magnitude: ab.slowMag,
                source: slot
            });
        }
    }

    // ═══════════════════════════════════════
    // HANDLER: VOID — ultimate snap saat mendarat
    // =======================================
    function throwVoid(s, a, slot, ab, dmgMul, tx, ty) {
        spawnProjectile(s, a, slot, ab, {
            dmg: ab.dmg * 0.2 * dmgMul,
            radius: 1,
            color: 0x8844ff,
            trailTex: 'potion_void',
            trailVy: -1,
            expSound: 'alch_pot_void',
            shockRad: 50,
            shake: 4,
            spawnOnDeath: [{
                traits: ['ultimateSnap'],
                p: {
                    delay: ab.voidDelay,
                    range: ab.voidRange,
                    dmg: ab.voidDmg * dmgMul,
                    color: 0x8844ff,
                    shake: 12,
                    flash: 0.5
                },
                l: 1,
                offsetX: 0,
                offsetY: 0
            }]
        }, tx, ty);
    }
})();