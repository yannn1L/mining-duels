// ==========================================
// MINIT: SYMBIOTE — Infestation Mechanic
// Behaviors: area.randomDamage (seed), spawn tendril entity
// Custom: infestation registry di s state
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;
    
    // ═══ LOCAL SFX ═══
    Object.assign(MD.AUDIO_PROFS, {
        symbiote_infect: {
            t: 'sine',
            f0: () => 300 + MD.FastMath.rand() * 100,
            f1: 80,
            v: 0.08,
            d: 0.2,
            ramp: 'exp'
        },
        symbiote_tendril: {
            noise: true,
            d: 0.15,
            fType: 'bandpass',
            f0: () => 800 + MD.FastMath.rand() * 400,
            f1: 200,
            fQ: 3,
            v: 0.06,
            oF0: 400,
            oF1: 100
        },
        symbiote_infest: {
            noise: true,
            d: 0.4,
            fType: 'lowpass',
            f0: 1200,
            f1: 100,
            v: 0.15,
            oF0: 200,
            oF1: 40
        }
    });
    
    MINIT_DB.symbiote = {
        id: 'symbiote',
        name: "SYMBIOTE",
        color: 0x66ff88,
        roam: 0.5,
        cd: 10,
        desc: "Infects blocks. Infested rocks spawn tendrils.",
        ability: {
            dmg: 15,
            infectRadius: 6,
            infectPerTrigger: 2,
            stacksToTentacle: 3,
            tentacleDmg: 2,
            tentacleLife: 200,
            spreadChance: 1,
            parasiteEffectDur: 240
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/INF:${ab.infectPerTrigger}/T:${ab.stacksToTentacle}`,

        textures: {
            base: (g, c) => {
                // Sel hidup hijau dengan inti merah
                g.beginFill(0x000000, 0.8).drawCircle(0, 0, 7).endFill();
                g.beginFill(c, 0.9).drawCircle(0, 0, 6).endFill();
                g.beginFill(0x440000, 0.9).drawCircle(0, 0, 3).endFill();
                g.beginFill(0xff2222, 1).drawCircle(0, 0, 2).endFill();
                // Tentakel kecil
                g.lineStyle(1, c, 0.9);
                for (let i = 0; i < 6; i++) {
                    const a = i * Math.PI / 3;
                    g.moveTo(Math.cos(a) * 5, Math.sin(a) * 5);
                    g.lineTo(Math.cos(a) * 8, Math.sin(a) * 8);
                }
                // Highlight putih
                g.beginFill(0xffffff, 0.7).drawCircle(-1, -1, 1).endFill();
            }
        },

        vfx: {
            parasite_glow: (g, c) => {
                g.beginFill(c, 0.8).drawCircle(0, 0, 5).endFill();
                g.beginFill(0xff2244, 1).drawCircle(0, 0, 2).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1).endFill();
            },
            tendril: (g, c) => {
                g.lineStyle(2, 0x331144, 1);
                g.moveTo(-5, 2).lineTo(-2, -3).lineTo(2, -3).lineTo(5, 2);
                g.lineStyle(1, c, 0.9);
                g.moveTo(-5, 2).lineTo(-2, -3).lineTo(2, -3).lineTo(5, 2);
                g.beginFill(0xff2244, 1).drawCircle(0, -3, 2.5).endFill();
            },
            infest_burst: (g, c) => {
                g.beginFill(0x331144, 0.9).drawCircle(0, 0, 7).endFill();
                g.beginFill(c, 0.7).drawCircle(0, 0, 5).endFill();
                g.beginFill(0xff2244, 1).drawCircle(0, 0, 2).endFill();
            }
        },

        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);

            // Registry blok terinfeksi: Map<"x,y", {stacks, lastTouch}>
            s.infested = new Map();

            // Tendril entities yang aktif (referensi entity di arena)
            s.tentacles = [];

            s.triggerCounter = 0;
        },

        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            const dmgMul = slot.modifiers.dmgMul || 1;
            s.triggerCounter++;

            // ═══ 1. INFECT blok sekitar minit ═══
            const candidates = [];
            const R = ab.infectRadius;
            for (let dy = 0; dy <= R; dy++) {
                for (let dx = -R; dx <= R; dx++) {
                    const rx = slot.log.x + dx;
                    const ry = slot.log.y + dy;
                    if (rx < 0 || rx >= CFG.GRID.COLS) continue;
                    const hp = a.getHP(rx, ry);
                    if (hp > 0 && hp !== 9999) candidates.push({ x: rx, y: ry });
                }
            }
            // Acak & ambil sebagian
            for (let i = candidates.length - 1; i > 0; i--) {
                const j = (FastMath.rand() * (i + 1)) | 0;
                [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
            }
            const picks = candidates.slice(0, ab.infectPerTrigger);

            for (const t of picks) {
                const key = t.x + ',' + t.y;
                const cur = s.infested.get(key) || { stacks: 0 };
                cur.stacks++;
                cur.lastTouch = a.simTicks;
                s.infested.set(key, cur);

                // Damage kecil + VFX parasite
                a.dmg(t.x, t.y, ab.dmg * dmgMul, false, slot.md.color, slot);
                const p = a.getPixelCoords(t.x, t.y);
                a.fxPool.spawnPhysics('minit_symbiote_vfx_parasite_glow',
                    p.px, p.py,
                    FastMath.randRange(-1, 1), FastMath.randRange(-2, -0.5),
                    25, 0.92, 0.92, 1);

                // Cukup stack? → spawn TENTACLE
                if (cur.stacks >= ab.stacksToTentacle) {
                    s.infested.delete(key);
                    a.fxPool.spawnShockwave(p.px, p.py, 0x331144, 50, 4);
                    for (let j = 0; j < 8; j++) {
                        a.fxPool.spawnPhysics('minit_symbiote_vfx_infest_burst',
                            p.px + FastMath.randRange(-10, 10),
                            p.py + FastMath.randRange(-10, 10),
                            FastMath.randRange(-2, 2), FastMath.randRange(-3, 1),
                            30, 0.9, 0.9, 1);
                    }
                    AudioSys.play('symbiote_infect', 0.8);

                    // Spawn tentacle ENTITY yang menyebar
                    const ent = s.builder.spawn({
                        traits: ['ageLife', 'spreadOnDestroy', 'tendrilLash', 'trailParticles'],
                        p: {
                            dmg: ab.tentacleDmg * dmgMul,
                            color: slot.md.color,
                            spreadLifeDecay: 30,
                            spreadOffsets: [[1,0],[-1,0],[0,1],[0,-1]],
                            spreadChance: ab.spreadChance,
                            spreadSound: 'symbiote_tendril',
                            trailTex: 'tendril',
                            trailVy: -0.5,
                            lashSpeed: 0.15,
                            tendrilDmg: ab.tentacleDmg * dmgMul,
                            tendrilColor: 0xff2244,
                            tentacleLife: ab.tentacleLife
                        },
                        l: ab.tentacleLife
                    }, { x: t.x, y: t.y });

                    if (ent) s.tentacles.push(ent);
                }
            }

            // ═══ 2. APPLY parasite effect ke lawan (setiap 5 trigger) ═══
            if (s.triggerCounter % 5 === 0) {
                const enemy = a.slots.find(x => x !== slot);
                if (enemy && !enemy.disabled) {
                    enemy.addEffect('parasite', {
                        duration: ab.parasiteEffectDur,
                        magnitude: 0.5,
                        source: slot
                    });
                }
            }

            // ═══ 3. Visual feedback ═══
            const p = a.getPixelCoords(slot.log.x, slot.log.y);
            a.fxPool.spawnShockwave(p.px, p.py, slot.md.color, 40, 3);
            AudioSys.play('symbiote_tendril', 0.6);
        },

        onUpdate: (s, a, spr, slot) => {
            // ═══ Bersihkan registry blok yang sudah hilang ═══
            if (a.simTicks % 30 === 0) {
                const toRemove = [];
                for (const [key, val] of s.infested) {
                    const [x, y] = key.split(',').map(Number);
                    const hp = a.getHP(x, y);
                    if (hp <= 0 || hp === 9999) toRemove.push(key);
                    else if (a.simTicks - val.lastTouch > 180) toRemove.push(key);
                }
                for (const k of toRemove) s.infested.delete(k);
            }

            // ═══ Bersihkan tentacles yang sudah mati ═══
            s.tentacles = s.tentacles.filter(t => t.active && !t.dead);

            // ═══ Visual: pulsing + tint sesuai jumlah infeksi ═══
            const pulse = 0.5 + Math.sin(a.simTicks * 0.15) * 0.5;
            slot.animScale.tX = 1 + pulse * 0.1;
            slot.animScale.tY = 1 - pulse * 0.1;

            if (s.tentacles.length > 0) {
                spr.tint = (a.simTicks % 10 < 5) ? 0xffaaaa : 0xffffff;
            } else if (s.infested.size > 5) {
                spr.tint = 0xccffcc;
            } else {
                spr.tint = 0xffffff;
            }

            // ═══ Visual: glow di blok terinfeksi ═══
            if (a.simTicks % 20 === 0) {
                for (const [key, val] of s.infested) {
                    const [x, y] = key.split(',').map(Number);
                    const p = a.getPixelCoords(x, y);
                    a.fxPool.spawnPhysics('minit_symbiote_vfx_parasite_glow',
                        p.px + FastMath.randRange(-4, 4),
                        p.py + FastMath.randRange(-4, 4),
                        0, -0.5, 10, 0.92, 0.92, 1);
                }
            }
        }
    };
})();