// ==========================================
// MINIT: SENTINEL — Orbital Bombardment
// Behaviors: orbit.satellite + projectile.gravity (castPayload)
// Traits: orbitAnchor, renderSprite, intervalCast, ageLife,
//         gravityFall, fuseTimer, explodeOnDeath, trailParticles
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    MINIT_DB.sentinel = {
        id: 'sentinel',
        name: "SENTINEL",
        color: 0xffaa44,
        roam: 0.25,
        cd: 120,
        desc: "Deploys orbital bombers that rain AoE strikes.",
        ability: {
            dmg: 25,
            radius: 3,
            maxSatellites: 8,
            castInterval: 39,
            orbitRadius: 3.2,
            orbitSpeed: 0.08,
            satLife: 600,
            bombLife: 30,
            fallSpeed: 1.2
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/R:${ab.radius}/SAT:${ab.maxSatellites}`,

        // ═══════════════════════════════════════
        // TEXTURE — hexagon eye (tetap sama)
        // ═══════════════════════════════════════
        textures: {
            base: (g, c) => {
                const R = 10;
                const pts = [];
                for (let i = 0; i < 6; i++) {
                    const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
                    pts.push([Math.cos(a) * R, Math.sin(a) * R]);
                }
                // Body
                g.beginFill(0x1a1a1a, 1);
                g.moveTo(pts[0][0], pts[0][1]);
                for (let i = 1; i < 6; i++) g.lineTo(pts[i][0], pts[i][1]);
                g.lineTo(pts[0][0], pts[0][1]);
                g.endFill();
                // Outline
                g.lineStyle(2, c, 1);
                g.moveTo(pts[0][0], pts[0][1]);
                for (let i = 1; i < 6; i++) g.lineTo(pts[i][0], pts[i][1]);
                g.lineTo(pts[0][0], pts[0][1]);
                // Core glow
                g.beginFill(c, 0.3).drawCircle(0, 0, 6).endFill();
                // Eye
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 3.5).endFill();
                g.beginFill(0xff2222, 1).drawCircle(0, 0, 2).endFill();
                g.beginFill(0xffffff, 1).drawCircle(-0.8, -0.8, 0.8).endFill();
                // Tripod
                g.lineStyle(2, 0x555555, 1);
                for (let i = 0; i < 3; i++) {
                    const a = (i / 3) * Math.PI * 2 + Math.PI / 6;
                    const lx = Math.cos(a) * R;
                    const ly = Math.sin(a) * R;
                    g.moveTo(lx * 0.85, ly * 0.85);
                    g.lineTo(lx * 1.25, ly * 1.25);
                }
                // Antena
                g.lineStyle(1, c, 1);
                g.moveTo(0, -R);
                g.lineTo(0, -R - 4);
                g.beginFill(0xff2222, 1).drawCircle(0, -R - 5, 1.5).endFill();
            }
        },

        // ═══════════════════════════════════════
        // VFX SCOPED — redesign untuk bombing
        // ═══════════════════════════════════════
        vfx: {
            // Aura satelit — pulsing amber
            satellite_aura: (g, c) => {
                g.lineStyle(1, c, 0.7).drawCircle(0, 0, 5);
                g.lineStyle(1, 0xffffff, 1).drawCircle(0, 0, 3);
                g.beginFill(0xffdd00, 0.5).drawCircle(0, 0, 4).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 1).endFill();
            },
            // Bom jatuh — kuning-oranye dengan core merah
            bomb_drop: (g, c) => {
                g.beginFill(0x222222, 1).drawCircle(0, 0, 4).endFill();
                g.beginFill(c, 1).drawCircle(0, 0, 3).endFill();
                g.beginFill(0xff2222, 1).drawCircle(0, 0, 1.5).endFill();
                // Spark tail kecil
                g.beginFill(0xffdd00, 0.7).drawCircle(0, -4, 1.5).endFill();
            },
            // Explosion — lebih besar dari fx_explosion biasa
            bomb_explosion: (g, c) => {
                g.beginFill(0xff8800, 0.9).drawCircle(0, 0, 8).endFill();
                g.beginFill(0xffdd00, 0.8).drawCircle(0, 0, 5).endFill();
                g.beginFill(0xffffff, 1).drawCircle(0, 0, 2).endFill();
                g.lineStyle(2, 0xffffff, 0.9);
                for (let i = 0; i < 6; i++) {
                    const ang = (i / 6) * Math.PI * 2;
                    g.moveTo(0, 0);
                    g.lineTo(Math.cos(ang) * 12, Math.sin(ang) * 12);
                }
            },
            // Deploy pulse
            deploy_pulse: (g, c) => {
                g.lineStyle(2, 0xffffff, 1).drawCircle(0, 0, 5);
                g.lineStyle(1, c, 0.7).drawCircle(0, 0, 8);
                g.beginFill(0xffdd00, 0.6).drawCircle(0, 0, 2).endFill();
            }
        },

        // ═══════════════════════════════════════
        // INIT
        // ═══════════════════════════════════════
        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);

            s.satellites = [];
            s.startAngle = FastMath.rand() * Math.PI * 2;
            s.deployCount = 0;
        },

        // ═══════════════════════════════════════
        // TRIGGER — deploy satelit baru
        // ═══════════════════════════════════════
        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            const dmgMul = slot.modifiers.dmgMul || 1;

            s.satellites = s.satellites.filter(x => x && x.active && !x.dead);

            if (s.satellites.length >= ab.maxSatellites) {
                // Refresh satelit tertua + feedback "reload"
                const oldest = s.satellites[0];
                if (oldest) {
                    oldest.l = ab.satLife;
                    oldest.maxL = ab.satLife;
                }
                const p = a.getPixelCoords(slot.log.x, slot.log.y);
                a.fxPool.spawnPhysics('minit_sentinel_vfx_deploy_pulse',
                    p.px, p.py, 0, -0.5, 15, 0.9, 0.9, 1);
                return;
            }

            // ═══ BOMB PAYLOAD — projectile gravity kecil ═══
            // Bom jatuh, saat hit ground → explode AoE + random splash
            const bombBehavior = {
                traits: ['gravityFall', 'fuseTimer', 'explodeOnDeath', 'trailParticles'],
                p: {
                    dmg: ab.dmg * dmgMul,
                    radius: ab.radius,
                    color: 0xffaa44,
                    shake: 6,
                    expSound: 'explosion',
                    shockRad: 100,
                    // Random splash damage di sekitar ledakan
                    spawnOnDeath: [
                        {
                            traits: ['ageLife', 'randomAreaDamage'],
                            p: {
                                range: ab.radius + 1,
                                dmg: Math.floor(ab.dmg * 0.4 * dmgMul),
                                color: 0xffdd00,
                                targetsPerTick: 3
                            },
                            l: 15,
                            offsetX: 0,
                            offsetY: 0
                        }
                    ],
                    trailTex: 'bomb_drop',
                    trailVy: -1.5,
                    trailVx: 0
                },
                f: ab.bombLife
            };

            // ═══ SPAWN SATELIT dengan payload bom ═══
            const sat = s.builder.spawn(
                BEHAVIORS.orbit.satellite({
                    targetRef: slot.log,
                    radius: ab.orbitRadius,
                    speed: ab.orbitSpeed,
                    startAngle: s.startAngle + s.deployCount * (Math.PI * 2 / ab.maxSatellites),
                    spriteTex: 'satellite_aura',
                    castInterval: ab.castInterval,
                    castSound: 'thruster',
                    castPayload: bombBehavior,
                    randomCast: true,   // ← offset random biar tidak sinkron
                    life: ab.satLife
                }),
                { x: slot.log.x, y: slot.log.y }
            );

            if (sat) {
                s.satellites.push(sat);
                s.deployCount++;
            }

            // ═══ Visual deploy ═══
            const p = a.getPixelCoords(slot.log.x, slot.log.y);
            a.fxPool.spawnShockwave(p.px, p.py, 0xffaa44, 80, 4);

            for (let i = 0; i < 12; i++) {
                const ang = (i / 12) * Math.PI * 2;
                a.fxPool.spawnPhysics('minit_sentinel_vfx_deploy_pulse',
                    p.px + Math.cos(ang) * 10,
                    p.py + Math.sin(ang) * 10,
                    Math.cos(ang) * 2,
                    Math.sin(ang) * 2,
                    18, 0.9, 0.9, 1);
            }

            a.shake = Math.max(a.shake, 4);
            AudioSys.play('thruster', 0.7);
        },

        // ═══════════════════════════════════════
        // UPDATE — animasi & aura
        // ═══════════════════════════════════════
        onUpdate: (s, a, spr, slot) => {
            spr.rotation += 0.005;

            const satCount = s.satellites.length;
            const pulse = 1 + Math.sin(a.simTicks * 0.1) * 0.05;
            slot.animScale.tX = pulse + satCount * 0.03;
            slot.animScale.tY = pulse + satCount * 0.03;

            const ab = slot.md.ability;
            if (satCount >= ab.maxSatellites) {
                spr.tint = (a.simTicks % 8 < 4) ? 0xffdd00 : 0xffffff;
            } else if (satCount > 0) {
                spr.tint = 0xffeedd;
            } else {
                spr.tint = 0xffffff;
            }

            // Aura trail di sekitar minit
            if (satCount > 0 && a.simTicks % 6 === 0) {
                const p = a.getPixelCoords(slot.log.x, slot.log.y);
                const ang = (a.simTicks * 0.05) % (Math.PI * 2);
                a.fxPool.spawnPhysics('minit_sentinel_vfx_bomb_drop',
                    p.px + Math.cos(ang) * 14,
                    p.py + Math.sin(ang) * 14,
                    0, 0, 12, 0.9, 0.9, 1);
            }

            // Trail aura di sekitar tiap satelit
            if (satCount > 0 && a.simTicks % 4 === 0) {
                for (const sat of s.satellites) {
                    if (!sat || !sat.active) continue;
                    const sp = a.getPixelCoords(sat.curX ?? sat.x, sat.curY ?? sat.y);
                    a.fxPool.spawnPhysics('minit_sentinel_vfx_satellite_aura',
                        sp.px, sp.py,
                        FastMath.randRange(-0.5, 0.5),
                        FastMath.randRange(-0.5, 0.5),
                        12, 0.92, 0.92, 1);
                }
            }

            if (a.simTicks % 30 === 0) {
                s.satellites = s.satellites.filter(x => x && x.active && !x.dead);
            }
        }
    };
})();