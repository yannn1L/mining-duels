(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder } = MD;

    MINIT_DB.bomber = {
        id: 'bomber',
        name: "BOMBER",
        color: 0xff6644,
        roam: 0.4,
        cd: 45,
        desc: "Drops heavy bombs and poisons enemies.",
        ability: {
            dmg: 400,
            radius: 3,
            fuse: 10,
            poisonDur: 300,
            poisonMag: 0.4
        },
        getStatsStr: (ab) => `DMG:${ab.dmg}/R:${ab.radius}`,

        textures: {
            base: (g, c) => {
                g.beginFill(0x333333).drawRect(-8, -6, 16, 12).endFill();
                g.beginFill(c).drawCircle(0, 0, 5).endFill();
                g.beginFill(0xffffff).drawRect(-2, -8, 4, 2).endFill();
            }
        },

        vfx: {
            smoke: (g, c) => {
                g.beginFill(0x666666, 0.8).drawCircle(0, 0, 3).endFill();
                g.beginFill(0xaaaaaa, 0.6).drawCircle(0, 0, 2).endFill();
            }
        },

        onInit: (s, a, slot) => {
            s.builder = new MinitBehaviorBuilder(slot.md, a);
            s.builder.setOwner(slot);
            s.triggerCount = 0;
        },

        onTrigger: (s, a, slot) => {
            const ab = slot.md.ability;
            s.triggerCount++;

            // Every 3rd trigger: debuff enemy
            if (s.triggerCount % 3 === 0) {
                const enemy = a.slots.find(x => x !== slot);
                if (enemy) {
                    enemy.addEffect('poison', {
                        duration: ab.poisonDur,
                        magnitude: ab.poisonMag,
                        source: slot
                    });
                    enemy.addEffect('slow', {
                        duration: 180,
                        magnitude: 0.3
                    });
                }
            }

            // Spawn bomb
            s.builder.spawn(
                BEHAVIORS.projectile.gravity({
                    dmg: ab.dmg,
                    radius: ab.radius,
                    fuse: ab.fuse,
                    color: slot.md.color,
                    expSound: 'nuke',
                    shockRad: 120
                }),
                { x: slot.log.x, y: slot.log.y }
            );

            // Visual
            const p = a.getPixelCoords(slot.log.x, slot.log.y);
            for (let i = 0; i < 6; i++) {
                a.fxPool.spawnPhysics('minit_bomber_vfx_smoke',
                    p.px + FastMath.randRange(-8, 8),
                    p.py + FastMath.randRange(-4, 4),
                    FastMath.randRange(-1, 1),
                    FastMath.randRange(-3, -1),
                    25, 0.9, 0.9, 1);
            }
            a.shake = Math.max(a.shake, 5);
            AudioSys.play('explosion', 0.4);
        },

        onUpdate: (s, a, spr, slot) => {
            // Pulsing visual
            if (slot.log.t >= slot.md.cd - 10) {
                spr.tint = 0xff8844;
            } else {
                spr.tint = 0xffffff;
            }
        }
    };
})();