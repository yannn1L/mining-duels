(function () {
    'use strict';
    const MD = window.MD;
    const MINIT_DB = MD.MINIT_DB;
    const { CFG, FastMath, AudioSys, BEHAVIORS, MinitBehaviorBuilder, Textures } = MD;

    MINIT_DB.lithos = {
        id: 'lithos', name: "LITHOS", color: 0x88aaff, roam: 0.2, cd: 5,
        desc: "infinity stone?",
        ability: {
            areaDmg: 50, areaRange: 7, areaDuration: 20, rareChance: 0.33,
            maxSlots: 5, snapRange: 7, snapDmg: 999, snapDelay: 5
        },
        getStatsStr: (ab) => `SNAP DMG:${ab.snapDmg}`,
        textures: {
            base: (g, c) => {
                g.beginFill(0x2a2a3a).drawRect(-7, -4, 14, 10).endFill()
                    .beginFill(0x4a4a5a).drawRect(-5, -7, 10, 14).endFill();
                g.beginFill(c).moveTo(0, -5).lineTo(4, 0).lineTo(0, 5).lineTo(-4, 0).endFill()
                    .beginFill(0xffffff).drawRect(-1, -1, 2, 2).endFill();
            }
        },
        vfx: {
            crystal_red: (g) => { g.beginFill(0xff6666).moveTo(0, -6).lineTo(4, 0).lineTo(2, 2).lineTo(0, 6).lineTo(-2, 2).lineTo(-4, 0).endFill(); g.beginFill(0xffaaaa).drawCircle(0, -1, 1.5).endFill(); },
            crystal_blue: (g) => { g.beginFill(0x66aaff).moveTo(0, -5).lineTo(5, 2).lineTo(2, 2).lineTo(0, 6).lineTo(-2, 2).lineTo(-5, 2).endFill(); g.beginFill(0xaaddff).drawRect(-1, -2, 2, 3).endFill(); },
            crystal_green: (g) => { g.beginFill(0x66ff88).drawEllipse(0, 0, 4, 6).endFill(); g.beginFill(0xaaffcc).drawEllipse(0, -1, 2, 3).endFill(); },
            crystal_purple: (g) => { g.beginFill(0xcc66ff).moveTo(0, -7).lineTo(3, -2).lineTo(5, 2).lineTo(2, 5).lineTo(-2, 5).lineTo(-5, 2).lineTo(-3, -2).endFill(); g.beginFill(0xeeaaff).drawCircle(0, 0, 2).endFill(); },
            crystal_gold: (g) => { g.beginFill(0xffcc44).drawRect(-4, -5, 8, 10).endFill(); g.beginFill(0xffdd88).drawRect(-2, -4, 4, 8).endFill(); g.lineStyle(1, 0xffaa00).moveTo(-4, 0).lineTo(4, 0); },
            crystal_sparkle: (g) => {
                g.beginFill(0xffffff, 0.9).drawCircle(0, 0, 2).endFill();
                g.lineStyle(1, 0xffaa44, 0.8);
                for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.moveTo(0, 0); g.lineTo(Math.cos(a) * 6, Math.sin(a) * 6); }
            },
            crystal_aura: (g, c) => {
                g.lineStyle(1, c, 0.5).drawCircle(0, 0, 18);
                g.lineStyle(1, 0xffffff, 0.3).drawCircle(0, 0, 22);
            },
            ult_ready_glow: (g, c) => {
                g.beginFill(0xffaa44, 0.9).drawCircle(0, 0, 4).endFill();
                g.beginFill(0xffdd88, 0.6).drawCircle(0, 0, 7).endFill();
                g.lineStyle(2, 0xffffff, 0.8);
                for (let i = 0; i < 4; i++) {
                    const a = i * Math.PI / 2;
                    g.moveTo(Math.cos(a) * 8, Math.sin(a) * 8);
                    g.lineTo(Math.cos(a) * 12, Math.sin(a) * 12);
                }
            }
        },
        onInit: (s, a, slot) => {
            const md = slot ? slot.md : a.md;
            s.crystals = []; s.buffDamage = 0; s.abilityActive = false;
            s.abilityTicksLeft = 0; s.ultimateReady = false; s.ultimateTriggered = false;
            s.ultimateFramesLeft = 0;
            s.crystalContainer = new PIXI.Container();
            s.crystalSprites = []; s.spawningCrystals = []; s.destroyingCrystals = [];
            s.builder = new MinitBehaviorBuilder(md, a);
            if (slot) s.builder.setOwner(slot);
            s.slot = slot;
            a.view.addChild(s.crystalContainer);
        },
        onUpdate: (s, a, spr, slot) => {
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            const log = slot ? slot.log : a.mLog;
            const p = a.getPixelCoords(log.x, log.y);
            s.crystalContainer.position.set(p.px - 10, p.py - 28);

            // Ambient aura
            if (s.crystals.length > 0 && a.simTicks % 8 === 0) {
                a.fxPool.spawnPhysics(`minit_${md.id}_vfx_crystal_aura`,
                    p.px, p.py, 0, 0, 20, 0.95, 0.95, true);
            }

            if (s.abilityTicksLeft > 0) {
                s.abilityTicksLeft--;
                if (s.abilityTicksLeft <= 0) s.abilityActive = false;
            }

            // Spawn animation with spin + pop
            if (s.spawningCrystals.length) {
                s.spawningCrystals = s.spawningCrystals.filter(anim => {
                    anim.step += 0.15;
                    const t = Math.min(1, anim.step * 1.25);
                    anim.cspr.scale.set(t);
                    anim.cspr.rotation = (1 - t) * Math.PI * 4;
                    return anim.step < 0.8;
                });
            }

            // Destroy animation
            if (s.destroyingCrystals.length) {
                s.destroyingCrystals = s.destroyingCrystals.filter(anim => {
                    anim.step += 0.1;
                    anim.cspr.x = anim.sx + (FastMath.rand() - 0.5) * anim.step * 6;
                    anim.cspr.y = anim.sy + anim.step * 10;
                    anim.cspr.alpha = 1 - anim.step;
                    if (anim.step >= 1) { if (anim.cspr.parent) anim.cspr.parent.removeChild(anim.cspr); return false; }
                    return true;
                });
            }

            if (s.ultimateFramesLeft > 0 && --s.ultimateFramesLeft === 0) s.ultimateTriggered = false;

            // Ult ready check
            if (s.crystals.length >= 5 && !s.ultimateReady && !s.ultimateTriggered) {
                s.ultimateReady = true; spr.tint = 0xffaa88; a.triggerFlash(0.2);
                for (const cs of s.crystalSprites) {
                    if (cs) {
                        a.fxPool.spawnPhysics(`minit_${md.id}_vfx_ult_ready_glow`,
                            s.crystalContainer.x + cs.x,
                            s.crystalContainer.y + cs.y - 5,
                            0, -1, 15, 0.95, 0.95, true);
                    }
                }
                a.spawnToast(p.px, p.py - 40, "ULT READY!", 0xffaa44);
            } else if (s.crystals.length < 5 && s.ultimateReady && !s.ultimateTriggered) {
                s.ultimateReady = false; spr.tint = 0xffffff;
            }

            // Idle float
            s.crystalSprites.forEach((cs, i) => {
                if (cs) {
                    cs.y = 5 + Math.sin(a.simTicks * 0.1 + i) * 3;
                    cs.rotation = Math.sin(a.simTicks * 0.15 + i) * 0.2;
                }
            });
        },
        onTrigger: (s, a, slot) => {
            if (s.abilityActive) return;
            const md = slot ? slot.md : a.md;
            const ab = md.ability;
            const P = md.id;
            const log = slot ? slot.log : a.mLog;

            const onRockDestroy = (x, y, arena, ownerSlot) => {
                if (s.ultimateTriggered) return;
                if (FastMath.rand() >= ab.rareChance) return;
                if (s.crystals.length >= ab.maxSlots) return;

                const types = ['red', 'blue', 'green', 'purple', 'gold'];
                const type = types[(FastMath.rand() * 5) | 0];
                s.crystals.push(type);
                AudioSys.play('bio_squish', 0.7); AudioSys.play('click', 0.4);
                const p = arena.getPixelCoords(x, y);
                arena.fxPool.spawnPhysics(`minit_${P}_vfx_crystal_sparkle`, p.px, p.py, 0, -2, 20, 0.95, 0.95, true);
                for (let i = 0; i < 5; i++) {
                    arena.fxPool.spawnPhysics('fx_flash',
                        p.px + FastMath.randRange(-8, 8), p.py + FastMath.randRange(-8, 8),
                        FastMath.randRange(-1, 1), FastMath.randRange(-3, -1), 15, 0.9, 0.9, true);
                }
                const cspr = new PIXI.Sprite(Textures[`minit_${P}_vfx_crystal_${type}`]);
                cspr.anchor.set(0.5);
                cspr.x = -((s.crystals.length - 1) * 12) / 2 + (s.crystals.length - 1) * 12;
                cspr.y = 5; cspr.scale.set(0);
                s.crystalContainer.addChild(cspr);
                s.crystalSprites.push(cspr);
                s.spawningCrystals.push({ cspr, step: 0 });

                const pm = arena.getPixelCoords(log.x, log.y);
                arena.fxPool.spawnPhysics(`minit_${P}_vfx_crystal_sparkle`, pm.px, pm.py - 20, 0, -3, 15, 0.95, 0.95, true);

                const old = s.buffDamage;
                s.buffDamage = s.crystals.length * 10;
                if (s.buffDamage > old) {
                    arena.triggerFlash(0.15);
                    arena.fxPool.spawnPhysics('fx_flash', pm.px, pm.py - 15, 0, -2, 10, 0.9, 0.9, true);
                }

                if (s.crystals.length >= ab.maxSlots && !s.ultimateTriggered) {
                    s.ultimateTriggered = true; s.ultimateReady = false; s.ultimateFramesLeft = 30;
                    AudioSys.play('snap', 1); arena.triggerFlash(0.5); arena.shake = 8;
                    for (let i = 0; i < 20; i++) {
                        const ang = FastMath.rand() * Math.PI * 2;
                        const rad = FastMath.randRange(15, 60);
                        arena.fxPool.spawnPhysics('fx_explosion',
                            pm.px + Math.cos(ang) * rad, pm.py + Math.sin(ang) * rad,
                            Math.cos(ang) * FastMath.randRange(1, 4), Math.sin(ang) * FastMath.randRange(1, 4),
                            25, 0.9, 0.9, true);
                    }
                    s.builder.spawn(
                        BEHAVIORS.ultimate.snap({ delay: ab.snapDelay, range: ab.snapRange, dmg: ab.snapDmg, color: 0xffaa44 }),
                        { x: log.x, y: log.y, owner: ownerSlot || slot }
                    );
                    for (const cs of s.crystalSprites) {
                        if (cs && cs.parent) s.destroyingCrystals.push({ cspr: cs, step: 0, sx: cs.x, sy: cs.y });
                    }
                    s.crystals = []; s.crystalSprites = []; s.buffDamage = 0;
                    if (slot) slot.spr.tint = 0xffffff; else arena.mSpr.tint = 0xffffff;
                }
            };

            s.abilityActive = true; s.abilityTicksLeft = ab.areaDuration;
            s.builder.spawn(
                BEHAVIORS.area.randomDamage({
                    range: ab.areaRange, dmg: ab.areaDmg + s.buffDamage,
                    color: md.color, targetsPerTick: 4,
                    life: ab.areaDuration, onDestroy: onRockDestroy
                }),
                { x: log.x, y: log.y, owner: slot }
            );
            AudioSys.play('quake', 0.8);
            const target = slot || a;
            if (target.animScale) { target.animScale.tX = 1.3; target.animScale.tY = 0.7; }
            const pm = a.getPixelCoords(log.x, log.y);
            a.fxPool.spawnShockwave(pm.px, pm.py, md.color, 100, 4);
        }
    };
})();