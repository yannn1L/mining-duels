// ==========================================
// EFFECTS — Buff/Debuff Presets
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[effects.js] namespace.js not loaded');

    /**
     * @typedef {Object} EffectDef
     * @property {string} id
     * @property {string} label
     * @property {number} color
     * @property {boolean} stackable
     * @property {number} [maxStacks]
     * @property {number} defaultDur
     * @property {function} [onApply]  (slot, eff) => void
     * @property {function} [onRemove] (slot, eff) => void
     * @property {function} [onTick]   (slot, eff) => void
     */

    /** @type {Object<string, EffectDef>} */
    const EFFECTS = {
        // ═══════════ DEBUFFS ═══════════
        slow: {
            id: 'slow', label: 'SLOW', color: 0xffaa00,
            stackable: true, maxStacks: 5, defaultDur: 180,
            onApply: (slot, eff) => { slot.modifiers.speedMul *= (1 - eff.magnitude); },
            onRemove: (slot, eff) => { slot.modifiers.speedMul /= (1 - eff.magnitude); },
            onTick: () => {}
        },
        poison: {
            id: 'poison', label: 'POISON', color: 0x88ff44,
            stackable: true, maxStacks: 3, defaultDur: 300,
            onApply: () => {},
            onRemove: () => {},
            onTick: (slot, eff) => {
                if ((eff.elapsed % 30) === 0) {
                    const a = slot.arena;
                    const x = slot.log.x, y = slot.log.y;
                    a.dmg(x, y + 1, eff.magnitude * 5, false, eff.color, slot);
                    a.fxPool.spawnPhysics('fx_acid',
                        x * MD.CFG.GRID.TS + MD.CFG.GRID.HALF_TS,
                        (y + 1 - a.camY) * MD.CFG.GRID.TS + MD.CFG.GRID.HALF_TS,
                        0, -1, 15, 0.92, 0.92, 1);
                }
            }
        },
        blind: {
            id: 'blind', label: 'BLIND', color: 0x552288,
            stackable: false, defaultDur: 180,
            onApply: (slot) => { slot.modifiers.blind = true; if (slot.spr) slot.spr.alpha = 0.4; },
            onRemove: (slot) => { slot.modifiers.blind = false; if (slot.spr) slot.spr.alpha = 1.0; },
            onTick: () => {}
        },

        // ═══════════ BUFFS ═══════════
        haste: {
            id: 'haste', label: 'HASTE', color: 0x00ccff,
            stackable: true, maxStacks: 3, defaultDur: 240,
            onApply: (slot, eff) => { slot.modifiers.speedMul *= (1 + eff.magnitude); },
            onRemove: (slot, eff) => { slot.modifiers.speedMul /= (1 + eff.magnitude); },
            onTick: () => {}
        },
        frenzy: {
            id: 'frenzy', label: 'FRENZY', color: 0xff2244,
            stackable: false, defaultDur: 300,
            onApply: (slot, eff) => { slot.modifiers.dmgMul *= eff.magnitude; },
            onRemove: (slot, eff) => { slot.modifiers.dmgMul /= eff.magnitude; },
            onTick: () => {}
        },
        shield: {
            id: 'shield', label: 'SHIELD', color: 0xffdd00,
            stackable: false, defaultDur: 400,
            onApply: (slot, eff) => { slot.modifiers.shieldCharges = eff.magnitude | 0; },
            onRemove: (slot) => { slot.modifiers.shieldCharges = 0; },
            onTick: () => {}
        },
        // ===== TAMBAHKAN KE EFFECTS di effects.js =====

        parasite: {
            id: 'parasite', label: 'PARASITE', color: 0x66ff66,
            stackable: true, maxStacks: 3, defaultDur: 240,
            onApply: () => {},
            onRemove: () => {},
            onTick: (slot, eff) => {
                // Efek infeksi: setiap 30 tick, damage ke blok bawah
                // dan spawn parasite mini
                if (eff.elapsed % 30 === 0) {
                    const a = slot.arena;
                    const x = slot.log.x, y = slot.log.y;
                    a.dmg(x, y + 1, eff.magnitude * 3, false, eff.color, slot);
                    const p = a.getPixelCoords(x, y + 1);
                    a.fxPool.spawnPhysics('fx_acid',
                        p.px, p.py,
                        MD.FastMath.randRange(-1, 1), MD.FastMath.randRange(-2, -0.5),
                        15, 0.94, 0.94, true);
                }
            }
        },
        
        momentum: {
            id: 'momentum', label: 'MOMENTUM', color: 0xff4422,
            stackable: false, defaultDur: 300,
            onApply: (slot, eff) => {
                // Momentum: setiap blok hancur, tambah damage bonus sementara
                slot.modifiers.dmgMul = (slot.modifiers.dmgMul || 1) * 1.5;
            },
            onRemove: (slot, eff) => {
                slot.modifiers.dmgMul /= 1.5;
            },
            onTick: () => {}
        }
    };

    MD.EFFECTS = EFFECTS;
    MD.EffectRegistry = {
        get(id) { return EFFECTS[id] || null; },
        all() { return Object.values(EFFECTS); },
        ids() { return Object.keys(EFFECTS); }
    };
})();