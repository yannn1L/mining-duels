// ==========================================
// UI STYLES — PIXI TextStyle presets
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD) throw new Error('[styles.js] namespace.js not loaded');
    if (!MD.PALETTE) throw new Error('[styles.js] config.js must load before styles.js');

    const { PALETTE } = MD;

    const FONT = '"Press Start 2P"';

    MD.UI_STYLE = {
        // ═══ Headers ═══
        H1: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 24, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 5, letterSpacing: 1
        }),
        H2: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 16, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 4, letterSpacing: 1
        }),
        H3: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 12, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 4
        }),

        // ═══ Body ═══
        STATS_LARGE: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 8, fill: PALETTE.TEXT,
            lineHeight: 16, stroke: '#000000', strokeThickness: 4
        }),
        DESC_LARGE: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 8, fill: PALETTE.TEXT,
            wordWrap: true, wordWrapWidth: 225, lineHeight: 12,
            stroke: '#000000', strokeThickness: 4
        }),
        DMG_POPUP: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 7, fill: '#ffffff',
            stroke: '#000000', strokeThickness: 4
        }),

        // ═══ New — mode minit manager ═══
        // Titles & labels
        MM_TITLE: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 18, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 4, letterSpacing: 1
        }),
        MM_AREA_NAME: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 16, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 4, letterSpacing: 1
        }),
        MM_SECTION: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 10, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 3, letterSpacing: 1
        }),
        MM_LABEL_TINY: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 6, fill: PALETTE.MUTED,
            stroke: '#000000', strokeThickness: 2
        }),
        MM_VALUE_MED: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 11, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 3
        }),

        // Buttons
        MM_BTN_PRIMARY: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 12, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 3, letterSpacing: 1
        }),
        MM_BTN_STANDARD: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 9, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 3, letterSpacing: 1
        }),
        MM_BTN_TINY: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 7, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 2, letterSpacing: 1
        }),

        // Info text
        MM_INFO: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 8, fill: PALETTE.TEXT,
            lineHeight: 14, stroke: '#000000', strokeThickness: 3
        }),
        MM_INFO_CENTERED: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 8, fill: PALETTE.TEXT,
            lineHeight: 14, stroke: '#000000', strokeThickness: 3,
            align: 'center', wordWrap: true, wordWrapWidth: 500
        }),
        MM_MODAL_TITLE: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 14, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 4, letterSpacing: 1
        }),
        MM_TOAST_TITLE: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 12, fill: PALETTE.NEON,
            stroke: '#000000', strokeThickness: 3, letterSpacing: 1
        }),
        MM_TOAST_BODY: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 10, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 3
        }),
        MM_TIMER: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 8, fill: PALETTE.TEXT,
            stroke: '#000000', strokeThickness: 3
        }),
        MM_UNLOCK_DESC: new PIXI.TextStyle({
            fontFamily: FONT, fontSize: 6, fill: PALETTE.MUTED,
            stroke: '#000000', strokeThickness: 2
        })
    };
})();