// ==========================================
// ABILITY STRATEGIES — registry
// ==========================================
// Hybrid (C2):
//   - Minit dengan `onTrigger` → pakai onTrigger (backward compat, VS mode)
//   - Minit tanpa `onTrigger` + ada `abilityStrategies` → loop strategies
//   - Minit bisa combine: onTrigger manual + strategies auto
//
// Strategy = { id, trigger(ctx) }.
// ctx = { slot, arena, builder, params }.
// ==========================================

(function() {
  'use strict';
  const MD = window.MD;
  if (!MD) throw new Error('[abilities.js] namespace.js not loaded');
  
  const { BEHAVIORS, FastMath, AudioSys } = MD;
  
  // ═══════════════════════════════════════════
  // STRATEGY REGISTRY
  // ═══════════════════════════════════════════
  const ABILITY_STRATEGIES = {
    // ═══ Laser strategies ═══
    beam_primary: {
      id: 'beam_primary',
      trigger(ctx) {
        const { slot, arena, builder } = ctx;
        const ab = slot.md.ability;
        builder.spawn(
          BEHAVIORS.beam.vertical({
            dmg: ab.dmg,
            length: ab.length,
            color: slot.md.color,
            duration: ab.duration,
            shake: ab.shake
          }), { x: slot.log.x, y: slot.log.y }
        );
      }
    },
    beam_burst: {
      id: 'beam_burst',
      trigger(ctx) {
        const { slot, arena, builder, params } = ctx;
        const ab = slot.md.ability;
        const count = (params && params.count) || ab.burstCount || 2;
        const extraDmg = ab.burstDmg || 0;
        for (let i = 1; i < count; i++) {
          setTimeout(() => {
            try {
              builder.spawn(
                BEHAVIORS.beam.vertical({
                  dmg: ab.dmg + extraDmg,
                  length: ab.length,
                  color: slot.md.color,
                  duration: ab.duration,
                  shake: ab.shake
                }), { x: slot.log.x, y: slot.log.y }
              );
            } catch (e) { /* fail-soft */ }
          }, i * 8 * 16); // ~128ms per burst
        }
      }
    },
    beam_pierce: {
      id: 'beam_pierce',
      trigger(ctx) {
        const { slot, arena, builder } = ctx;
        const ab = slot.md.ability;
        // Pierce = beam damage ×1.5 + extra depth
        builder.spawn(
          BEHAVIORS.beam.vertical({
            dmg: Math.floor(ab.dmg * 1.5),
            length: ab.length + 2,
            color: 0xff0088,
            duration: ab.duration
          }), { x: slot.log.x, y: slot.log.y }
        );
      }
    },
    
    // ═══ Moth strategies ═══
    moth_multi_spore: {
      id: 'moth_multi_spore',
      trigger(ctx) {
        const { slot, arena, builder } = ctx;
        const ab = slot.md.ability;
        const count = ab.sporeCount || 1;
        for (let i = 0; i < count; i++) {
          const tx = FastMath.randRange(3, arena.cols - 4) | 0;
          const ty = Math.min(slot.log.y + (FastMath.randRange(2, 7) | 0), arena.maxDepth - 1);
          builder.spawn(
            BEHAVIORS.projectile.targeted({
              dmg: ab.dmg,
              radius: ab.range,
              color: slot.md.color,
              shake: ab.shake,
              flash: ab.flash,
              trailTex: 'fx_acid',
              trailSwirl: true,
              tx,
              ty
            }), { x: slot.log.x + (i - count / 2) * 0.5, y: slot.log.y }
          );
        }
      }
    },
    moth_slow: {
      id: 'moth_slow',
      trigger(ctx) {
        // Add slow effect ke nearby enemies (future)
        // Untuk sekarang, hanya tint VFX
        const { slot, arena } = ctx;
        arena.triggerFlash(0.1);
      }
    },
    
    // ═══ Absorb strategies (dormant — absorb pakai onTrigger) ═══
    // ═══ Lithos strategies (dormant — lithos pakai onTrigger) ═══
  };
  
  // ═══════════════════════════════════════════
  // HELPER: Execute strategies for a slot
  // ═══════════════════════════════════════════
  function executeAbilityStrategies(slot, arena, builder) {
    const md = slot.md;
    const strategies = md.abilityStrategies || [];
    if (strategies.length === 0) return false;
    let anyExecuted = false;
    for (const stratId of strategies) {
      const strat = ABILITY_STRATEGIES[stratId];
      if (!strat) continue;
      const params = (slot.abilityParams && slot.abilityParams[stratId]) || null;
      try {
        strat.trigger({ slot, arena, builder, params });
        anyExecuted = true;
      } catch (e) {
        console.warn(`[AbilityStrategy:${stratId}] error:`, e);
      }
    }
    return anyExecuted;
  }
  
  // ═══════════════════════════════════════════
  // HOOK KE MINITSLOT
  // ═══════════════════════════════════════════
  // MinitSlot.patchTrigger() — dipanggil saat init
  // Kalau md punya onTrigger custom, itu yang jalan.
  // Kalau tidak, tapi punya abilityStrategies, loop strategies.
  // Kalau punya keduanya, onTrigger jalan dulu, baru strategies.
  // ═══════════════════════════════════════════
  const AbilityHook = {
    wrapMinitslot(MinitSlotClass) {
      const originalTick = MinitSlotClass.prototype._tickInternal;
      MinitSlotClass.prototype._tickInternal = function() {
        const ml = this.log,
          md = this.md,
          a = this.arena;
        this.moveStep();
        const effectiveCd = Math.max(1, Math.floor(md.cd / this.modifiers.speedMul));
        ml.t++;
        if (ml.t >= effectiveCd) {
          ml.t = 0;
          this.animScale.tX = 1.3;
          this.animScale.tY = 0.7;
          // Trigger: onTrigger custom (kalau ada) ATAU strategies
          let anyTriggered = false;
          if (md.onTrigger) {
            try { md.onTrigger(this.state, a, this);
              anyTriggered = true; }
            catch (e) { console.error(`[MinitSlot:${this.id}] onTrigger:`, e); }
          }
          // Extra strategies (hybrid)
          if (this.builder) {
            if (executeAbilityStrategies(this, a, this.builder)) anyTriggered = true;
          }
        }
        if (md.onUpdate) md.onUpdate(this.state, a, this.spr, this);
        if (MD.EffectManager) MD.EffectManager.tick(this);
        this.stats.maxDp = Math.max(this.stats.maxDp, ml.y);
        this._updateEffectsUI();
      };
    }
  };
  
  // ═══════════════════════════════════════════
  // EXPORT
  // ═══════════════════════════════════════════
  MD.ABILITY_STRATEGIES = ABILITY_STRATEGIES;
  MD.executeAbilityStrategies = executeAbilityStrategies;
  MD.AbilityHook = AbilityHook;
  
  // Auto-patch MinitSlot kalau sudah ter-load
  if (MD.MinitSlot) {
    AbilityHook.wrapMinitslot(MD.MinitSlot);
  } else {
    // Tunggu sampai MinitSlot loaded (defer)
    MD._abilityHookPending = true;
  }
})();