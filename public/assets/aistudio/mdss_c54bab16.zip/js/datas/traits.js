// ==========================================
// TRAITS — Pure mechanics. State di e._ts (namespace).
// ==========================================
(function () {
    'use strict';
    const MD = window.MD;
    if (!MD || !MD.CFG || !MD.AudioSys) throw new Error('[traits.js] deps not met');

    const { CFG, AudioSys, FastMath } = MD;   // ← tambah FastMath

    MD.TRAITS = {
        // ═══ RENDER ═══
        renderSprite: (e, a) => {
            if ((a.simTicks + (e.entId || 0)) % 2 !== 0) return;
            const p = a.getPixelCoords(e.curX ?? e.x, e.curY ?? e.y);
            a.fxPool.spawnPhysics(e.p.spriteTex, p.px, p.py, 0, 0, 3, 1, 1, 0);
        },

        // ═══ MOVEMENT ═══
        gravityFall: (e, a) => {
            if (!e.spinning && !e.pinned && (a.getHP(e.x | 0, e.y + 1) > 0 || e.y >= CFG.GRID.MAX_DEPTH - 1)) {
                e.hitGround = true;
            } else {
                e.y++;
            }
        },
        moveToTarget: (e, a) => {
            const pct = 1 - e.l / e.maxL;
            const t = e.p.targetRef || { x: e.tx, y: e.ty };
            
            // ═══ FIX: Clamp pct ke [0, 1] ═══
            const clampedPct = Math.max(0, Math.min(1, pct));
            
            e.curX = e.startX + (t.x - e.startX) * clampedPct;
            e.curY = e.startY + (t.y - e.startY) * clampedPct;
            
            // ═══ FIX: Snap ke target kalau sudah dekat/selesai ═══
            if (pct >= 1) {
                e.curX = t.x;
                e.curY = t.y;
            }
            
            e.x = e.curX | 0;
            e.y = e.curY | 0;
        },
        moveDirection: (e, a) => {
            e.curX += e.dx; e.curY += e.dy;
            e.x = e.curX | 0; e.y = e.curY | 0;
        },
        bounceX: (e, a) => {
            if (e.curX < 0 || e.curX >= CFG.GRID.COLS - 1) {
                e.curX = Math.max(0, Math.min(e.curX, CFG.GRID.COLS - 1));
                e.dx *= -1;
                AudioSys.play('hit', 0.5);
                a.shake = e.p.shake || 0;
            }
            e.x = e.curX | 0;
        },
        wanderDownSpread: (e, a) => {
            if (e.l % 2 === 0) {
                const d = (MD.FastMath.rand() < 0.5 ? CFG.VECTORS.DOWN : CFG.VECTORS.SPREAD)[(MD.FastMath.rand() * 3) | 0];
                e.curX += d[0]; e.curY += d[1];
                e.x = e.curX | 0; e.y = e.curY | 0;
            }
        },
        orbitAnchor: (e, a) => {
            if (!e.p.targetRef) return;
            e.ang = (e.ang || 0) + (e.p.orbitSpeed || 0.1);
            e.curX = e.p.targetRef.x + MD.FastMath.cos(e.ang) * (e.p.orbitRadius || 2.5);
            e.curY = e.p.targetRef.y + MD.FastMath.sin(e.ang) * (e.p.orbitRadius || 2.5);
            e.x = e.curX | 0; e.y = e.curY | 0;
        },

        // ═══ LIFECYCLE ═══
        ageLife: (e) => { if (--e.l <= 0) e.dead = true; },
        fuseTimer: (e) => { if (e.hitGround && --e.f <= 0) e.dead = true; },

        // ═══ DAMAGE (credit ke e.owner) ═══
        damageOnHit: (e, a) => {
            const hp = a.getHP(e.x, e.y);
            if (hp > 0 && hp !== 9999) {
                a.dmg(e.x, e.y, e.p.dmg, 1, e.p.color, e.owner);
                e.dead = true;
            }
        },
        damageTick: (e, a) => {
            a.dmg(e.x, e.y, e.p.dmg, 1, e.p.color, e.owner);
        },
        beamDamage: (e, a) => {
            for (let k = 1; k <= e.p.length; k++) {
                a.dmg(e.x, e.y + k, e.p.dmg, 1, e.p.color, e.owner);
            }
            const ps = a.getPixelCoords(e.x, e.y);
            const pe = a.getPixelCoords(e.x, e.y + e.p.length);
            a.fxPool.spawnLaser(ps.px, ps.py, pe.px, pe.py, e.p.color, 4, 2);
        },
        lightningDamage: (e, a) => {
            const endY = Math.min(e.y + e.p.length, CFG.GRID.MAX_DEPTH);
            const ps = a.getPixelCoords(e.x, e.y);
            const pe = a.getPixelCoords(e.x, endY);
            a.fxPool.spawnLaser(ps.px, ps.py, pe.px, pe.py, e.p.color || 0xffff00, 4, 10, 1);
            for (let y = e.y; y <= endY; y++) {
                const rx = a.clampX(e.x + (MD.FastMath.randRange(-1.5, 1.5) | 0));
                a.dmg(rx, y, e.p.dmg, 1, e.p.color || 0xffff00, e.owner);
                const pr = a.getPixelCoords(rx, y);
                a.fxPool.spawnPhysics('fx_flash', pr.px, pr.py,
                    MD.FastMath.randRange(-2, 2), MD.FastMath.randRange(-2, 2),
                    10, CFG.PHYSICS.DRAG_X, CFG.PHYSICS.DRAG_X, 1);
            }
        },
        randomAreaDamage: (e, a) => {
            e._ts.counter = (e._ts.counter || 0) + 1;
            if (e._ts.counter % 3 !== 0) return;
            const cx = e.x, cy = e.y;
            const range = e.p.range || 8;
            const cnt = Math.ceil((e.p.targetsPerTick || 3) * (a.vfxLod || 1));
            for (let i = 0; i < cnt; i++) {
                const rx = a.clampX(cx + (MD.FastMath.rand() * range * 2 - range) | 0);
                const ry = a.clampY(cy + (MD.FastMath.rand() * range * 2 - range) | 0);
                const hp = a.getHP(rx, ry);
                if (hp > 0 && hp !== 9999 && a.dmg(rx, ry, e.p.dmg, 1, e.p.color, e.owner) && e.p.onDestroy) {
                    e.p.onDestroy(rx, ry, a, e.owner);
                }
            }
            if (e._ts.counter % 6 === 0) {
                const pc = a.getPixelCoords(cx, cy);
                const c = Math.ceil(5 * (a.vfxLod || 1));
                for (let i = 0; i < c; i++) {
                    const ang = MD.FastMath.rand() * Math.PI * 2;
                    const rad = MD.FastMath.randRange(30, 100);
                    a.fxPool.spawnPhysics('fx_dust',
                        pc.px + Math.cos(ang) * rad,
                        pc.py + Math.sin(ang) * rad + MD.FastMath.randRange(-20, 20),
                        Math.cos(ang) * MD.FastMath.randRange(-1, 1),
                        MD.FastMath.randRange(-3, -1),
                        20, 0.9, 0.9, 1);
                }
            }
            if (--e.l <= 0) e.dead = true;
        },
        shockwaveExpand: (e, a) => {
            e._ts.radius = (e._ts.radius || 0) + e.p.speed;
            if (e._ts.radius >= e.p.maxRadius) { e.dead = true; return; }
            const r = Math.floor(e._ts.radius);
            const cx = e.x, cy = e.y;
            for (let dy = -r; dy <= r; dy++) {
                for (let dx = -r; dx <= r; dx++) {
                    const dist = Math.hypot(dx, dy);
                    if (dist <= r) {
                        const dmg = Math.floor(e.p.baseDmg / (dist + 1));
                        if (dmg > 0) a.dmg(cx + dx, cy + dy, dmg, 1, e.p.color, e.owner);
                    }
                }
            }
            const pc = a.getPixelCoords(cx, cy);
            a.fxPool.spawnShockwave(pc.px, pc.py, e.p.color, e._ts.radius * 20, 3);
            if (e._ts.radius % 2 === 0) {
                const cnt = Math.ceil(8 * a.vfxLod);
                for (let i = 0; i < cnt; i++) {
                    const ang = MD.FastMath.rand() * Math.PI * 2;
                    const rad = e._ts.radius * 16;
                    a.fxPool.spawnPhysics('fx_dust',
                        pc.px + Math.cos(ang) * rad,
                        pc.py + Math.sin(ang) * rad,
                        Math.cos(ang) * MD.FastMath.randRange(1, 3),
                        Math.sin(ang) * MD.FastMath.randRange(1, 3),
                        20, 0.9, 0.9, 1);
                }
            }
            if (e._ts.radius % 3 === 0) AudioSys.play('hit', 0.3);
        },
        ultimateSnap: (e, a) => {
            e._ts.counter = (e._ts.counter || 0) + 1;
            if (e._ts.counter < (e.p.delay || 10)) return;
            const cx = e.x, cy = e.y;
            const range = e.p.range || 4;
            const rocksInRange = [];
            for (let dy = -range; dy <= range; dy++) {
                for (let dx = -range; dx <= range; dx++) {
                    const rx = a.clampX(cx + dx);
                    const ry = a.clampY(cy + dy);
                    const hp = a.getHP(rx, ry);
                    if (hp > 0 && hp !== 9999) rocksInRange.push({ x: rx, y: ry });
                }
            }
            const toDestroy = Math.floor(rocksInRange.length * 0.6);
            for (let i = 0; i < toDestroy; i++) {
                if (rocksInRange.length === 0) break;
                const idx = MD.FastMath.rand() * rocksInRange.length | 0;
                const rock = rocksInRange[idx];
                a.dmg(rock.x, rock.y, e.p.dmg, true, e.p.color, e.owner);
                rocksInRange.splice(idx, 1);
            }
            AudioSys.play('bio_squish', 1.2);
            a.triggerFlash(e.p.flash ?? 0.6);
            a.shake = e.p.shake ?? 12;
            const pCenter = a.getPixelCoords(cx, cy);
            a.fxPool.spawnShockwave(pCenter.px, pCenter.py, e.p.color || 0xffaa44, 150, 8);
            const starCount = Math.ceil(20 * (a.vfxLod || 1));
            for (let i = 0; i < starCount; i++) {
                const ang = MD.FastMath.rand() * Math.PI * 2;
                const rad = MD.FastMath.randRange(30, 120);
                a.fxPool.spawnPhysics('fx_flash',
                    pCenter.px + Math.cos(ang) * rad,
                    pCenter.py + Math.sin(ang) * rad,
                    Math.cos(ang) * MD.FastMath.randRange(-2, 2),
                    Math.sin(ang) * MD.FastMath.randRange(-2, 2),
                    25, 0.9, 0.9, true);
            }
            e.dead = true;
        },

        // ═══ DEATH ═══
        explodeOnDeath: (e, a) => {
            if (!e.dead) return;
            AudioSys.play(e.p.expSound || 'explosion');
            a.shake = Math.max(a.shake, e.p.shake || 0);
            if (e.p.flash) a.triggerFlash(e.p.flash);
            a.dmgAoE(e.x, e.y, e.p.radius || 1, e.p.dmg, e.p.color, e.owner);
            const p = a.getPixelCoords(e.x, e.y);
            a.fxPool.spawnShockwave(p.px, p.py, e.p.color, e.p.shockRad || 100, 6);
            if (e.p.spawnOnDeath) {
                e.p.spawnOnDeath.forEach(sub => a.spawnEnt({
                    ...sub,
                    x: e.x + (sub.offsetX || 0),
                    y: e.y + (sub.offsetY || 0),
                    owner: e.owner
                }));
            }
        },

        // ═══ TRAIL ═══
        trailParticles: (e, a) => {
            const p = a.getPixelCoords(e.curX ?? e.x, e.curY ?? e.y);
            let vx = e.p.trailVx || 0;
            let vy = e.p.trailVy || 0;
            if (e.p.trailSwirl) {
                vx += MD.FastMath.sin(e.l) * 2;
                vy += MD.FastMath.cos(e.l) * 2;
            }
            if (e.p.trailTex) {
                const dragX = e.p.trailDragX ?? CFG.PHYSICS.DRAG_X;
                const dragY = e.p.trailDragY ?? CFG.PHYSICS.DRAG_Y;
                a.fxPool.spawnPhysics(e.p.trailTex, p.px, p.py, vx, vy, 10, dragX, dragY, 1);
            }
        },

        // ═══ CASTING ═══
        intervalCast: (e, a) => {
            e._ts.castTimer = (e._ts.castTimer || 0) + 1;
            if (e._ts.castTimer >= e.p.castInterval) {
                e._ts.castTimer = 0;
                if (e.p.castSound) AudioSys.play(e.p.castSound, 0.4);
                if (e.p.castPayload) {
                    a.spawnEnt({
                        ...e.p.castPayload,
                        x: e.x, y: e.y, curX: e.x, curY: e.y,
                        startX: e.x, startY: e.y,
                        owner: e.owner
                    });
                }
            }
        },
        intervalRandomCast: (e, a) => {
            e._ts.castTimer = (e._ts.castTimer || 0) + 1;
            if (e._ts.castTimer >= e.p.castInterval) {
                e._ts.castTimer = 0;
                if (e.p.castSound) AudioSys.play(e.p.castSound, 0.2);
                if (e.p.castPayload) {
                    a.spawnEnt({
                        ...e.p.castPayload,
                        x: e.x, y: e.y, curX: e.x, curY: e.y,
                        startX: e.x, startY: e.y,
                        dx: MD.FastMath.randRange(-1.5, 1.5),
                        dy: MD.FastMath.randRange(0.5, 2.0),
                        owner: e.owner
                    });
                }
            }
        },

        // ═══ SPREAD ═══
        spreadOnDestroy: (e, a) => {
            const hp = a.getHP(e.x, e.y);
            const p = a.getPixelCoords(e.x, e.y);
            if (hp <= 0 || hp === 9999) {
                e.y++;
                if (e.p.trailTex) {
                    a.fxPool.spawnPhysics(e.p.trailTex, p.px, p.py, 0, 2, 10,
                        CFG.PHYSICS.DRAG_X, CFG.PHYSICS.DRAG_X, 1);
                }
            } else {
                const broke = a.dmg(e.x, e.y, e.p.dmg, 1, e.p.color, e.owner);
                if (e.p.trailTex) {
                    a.fxPool.spawnPhysics(e.p.trailTex, p.px, p.py,
                        MD.FastMath.randRange(-2, 2), MD.FastMath.randRange(-3, 0),
                        10, CFG.PHYSICS.DRAG_X, CFG.PHYSICS.DRAG_X, 1);
                }
                if (broke) {
                    const nL = Math.max(10, e.l - (e.p.spreadLifeDecay || 5));
                    if (e.p.spreadOffsets) {
                        e.p.spreadOffsets.forEach(off => a.spawnEnt({
                            x: e.x + off[0], y: e.y + off[1],
                            l: nL, traits: e.traits, p: e.p, owner: e.owner
                        }));
                    }
                    if (e.p.spreadSound) AudioSys.play(e.p.spreadSound);
                    if (e.p.spawnOnDeath) {
                        e.p.spawnOnDeath.forEach(sub => {
                            if (!sub.spawnChance || MD.FastMath.rand() < sub.spawnChance) {
                                a.spawnEnt({
                                    ...sub,
                                    x: e.x + (sub.offsetX || 0),
                                    y: e.y + (sub.offsetY || 0),
                                    curX: e.x + (sub.offsetX || 0),
                                    curY: e.y + (sub.offsetY || 0),
                                    owner: e.owner
                                });
                            }
                        });
                    }
                    e.dead = true;
                }
            }
        },
        randomInfectArea: (e, a) => {
            e._ts.infectTimer = (e._ts.infectTimer || 0) + 1;
            if (e._ts.infectTimer >= (e.p.infectRate || 5)) {
                e._ts.infectTimer = 0;
                const rx = a.clampX(e.x + (MD.FastMath.randRange(-e.p.range, e.p.range) | 0));
                const ry = a.clampY(e.y + (MD.FastMath.randRange(-e.p.range, e.p.range) | 0));
                if (a.getHP(rx, ry) > 0 && a.getHP(rx, ry) !== 9999) {
                    a.spawnEnt({
                        x: rx, y: ry, curX: rx, curY: ry,
                        l: e.p.virusLife,
                        traits: ['spreadOnDestroy', 'ageLife', 'trailParticles'],
                        p: e.p.virusPayload, owner: e.owner
                    });
                    AudioSys.play('bio_squish', 0.5);
                }
            }
        },

        // ═══ TENDRILLASH — tentakel yang mengayun kiri/kanan, damage tile di sekitarnya ═══
        tendrilLash: (e, a) => {
            e._ts.ang = (e._ts.ang || 0) + (e.p.lashSpeed || 0.15);
            e._ts.life = (e._ts.life || 0) + 1;
            
            // Damage tile di kiri/kanan anchor (bergantian)
            const dir = Math.sin(e._ts.ang * 4) > 0 ? 1 : -1;
            const lashX = a.clampX(e.x + dir);
            const lashY = a.clampY(e.y - 1);
            const hp = a.getHP(lashX, lashY);
            
            if (hp > 0 && hp !== 9999) {
                const dmg = e.p.tendrilDmg || e.p.dmg || 20;
                a.dmg(lashX, lashY, dmg, false, e.p.tendrilColor || 0xff2244, e.owner);
            }
            
            // VFX tendril bergerak
            if (a.fxPool && e.p.trailTex && e._ts.life % 3 === 0) {
                const p = a.getPixelCoords(e.x, e.y - 1);
                a.fxPool.spawnPhysics(e.p.trailTex,
                    p.px + dir * 6,
                    p.py + FastMath.randRange(-3, 3),
                    dir * 0.5,
                    FastMath.randRange(-1, 0),
                    12, 0.92, 0.92, 1);
            }
        },
        
        // ═══ BOUNCE SPARK — VFX + sound saat entity menyentuh dinding ═══
        // Dipakai bareng bounceX. Cek transisi arah.
        bounceSpark: (e, a) => {
            const atWall = (e.curX <= 0.5 || e.curX >= CFG.GRID.COLS - 1.5);
            if (!atWall) { e._ts.wasAtWall = false; return; }
            if (e._ts.wasAtWall) return;
            e._ts.wasAtWall = true;
            
            // VFX spark
            if (a.fxPool && e.p.sparkTex) {
                const p = a.getPixelCoords(e.x, e.y);
                const dir = e.dx > 0 ? -1 : 1;
                for (let i = 0; i < 8; i++) {
                    a.fxPool.spawnPhysics(e.p.sparkTex,
                        p.px + dir * 4,
                        p.py + MD.FastMath.randRange(-6, 6),
                        dir * MD.FastMath.randRange(1, 3),
                        MD.FastMath.randRange(-2, 2),
                        15, 0.88, 0.9, 1);
                }
                a.shake = Math.max(a.shake, e.p.wallShake || 2);
            }
            if (e.p.bounceSound) AudioSys.play(e.p.bounceSound, 0.4);
        },
        
        // ═══ MULTICAST — cast N payload dengan spread sudut ═══
        // Generik: bisa dipakai minit apa saja (shotgun, fan, spread).
        multiCast: (e, a) => {
            e._ts.castTimer = (e._ts.castTimer || 0) + 1;
            if (e._ts.castTimer < (e.p.castInterval || 30)) return;
            e._ts.castTimer = 0;
        
            const count = e.p.castCount || 3;
            const spread = e.p.castSpread ?? 0.6;
            const baseAngle = e.p.castBaseAngle ?? Math.PI / 2;  // default ke bawah
            const speed = e.p.castSpeed ?? 1.5;
            const payload = e.p.castPayload;
        
            if (e.p.castSound) AudioSys.play(e.p.castSound, 0.4);
            if (!payload) return;
        
            for (let i = 0; i < count; i++) {
                const t = count === 1 ? 0 : (i / (count - 1) - 0.5);
                const angle = baseAngle + t * spread;
                const dx = Math.cos(angle) * speed;
                const dy = Math.sin(angle) * speed;
        
                a.spawnEnt({
                    ...payload,
                    x: e.x, y: e.y,
                    curX: e.x, curY: e.y,
                    startX: e.x, startY: e.y,
                    dx, dy,
                    owner: e.owner
                });
            }
        },
        
    };
})();